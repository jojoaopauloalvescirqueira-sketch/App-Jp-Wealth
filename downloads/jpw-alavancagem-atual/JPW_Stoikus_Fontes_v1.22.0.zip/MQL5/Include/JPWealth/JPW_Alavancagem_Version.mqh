#ifndef JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_PRODUCT_NAME "Stoikus"
#define JPW_PRODUCT_TAGLINE "Da origem da operação à leitura do risco."
#define JPW_NOCUDA_SHORTNAME "Stoikus · NoCuda Channels"
// Metadata only. Product revision does not homologate financial parameters.
#define JPW_PRODUCT_VERSION "1.22.0"
#define JPW_PRODUCT_MQL_VERSION "1.220"
#define JPW_CALCULATION_VERSION "1.9.0"
// Source identity. Exact artifacts remain linked by the external candidate
// fingerprint; this label never certifies native compilation or EX5 identity.
#define JPW_BUILD_ID "382db58b4cfde5e7c725088f15fe993261328ca742aee7fa6e6412a8a19cf45d"
#endif
