#ifndef JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_PRODUCT_NAME "Stoikus"
#define JPW_PRODUCT_TAGLINE "Da origem da operação à leitura do risco."
#define JPW_NOCUDA_SHORTNAME "Stoikus · NoCuda Channels"
// Metadata only. Product revision does not homologate financial parameters.
#define JPW_PRODUCT_VERSION "1.22.3"
#define JPW_PRODUCT_MQL_VERSION "1.223"
#define JPW_CALCULATION_VERSION "1.9.0"
// Source identity. Exact artifacts remain linked by the external candidate
// fingerprint; this label never certifies native compilation or EX5 identity.
#define JPW_BUILD_ID "45beb82e9366197542bfa5c7084a28bc05dd6b155f5a3777fdaa95f15b67239d"
#endif
