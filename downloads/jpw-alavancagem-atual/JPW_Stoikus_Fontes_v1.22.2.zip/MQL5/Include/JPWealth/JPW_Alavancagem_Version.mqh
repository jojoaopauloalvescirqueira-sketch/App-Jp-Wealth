#ifndef JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_ALAVANCAGEM_VERSION_MQH
#define JPW_PRODUCT_NAME "Stoikus"
#define JPW_PRODUCT_TAGLINE "Da origem da operação à leitura do risco."
#define JPW_NOCUDA_SHORTNAME "Stoikus · NoCuda Channels"
// Metadata only. Product revision does not homologate financial parameters.
#define JPW_PRODUCT_VERSION "1.22.2"
#define JPW_PRODUCT_MQL_VERSION "1.222"
#define JPW_CALCULATION_VERSION "1.9.0"
// Source identity. Exact artifacts remain linked by the external candidate
// fingerprint; this label never certifies native compilation or EX5 identity.
#define JPW_BUILD_ID "5a207fbd41e59c2d2544f94264105d45c69911518433d0d66176eb9c0c427a1b"
#endif
