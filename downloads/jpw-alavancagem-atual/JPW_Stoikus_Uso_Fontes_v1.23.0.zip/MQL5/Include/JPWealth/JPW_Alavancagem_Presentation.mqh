#ifndef JPW_ALAVANCAGEM_PRESENTATION_MQH
#define JPW_ALAVANCAGEM_PRESENTATION_MQH
#include <JPWealth/JPW_Stoikus_Brand.mqh>
#include <JPWealth/JPW_UI_Design.mqh>
// Indicator runtime component; included after its instance state.
void JPWRenderHUD();
int g_details_focus_route=-1;
bool g_cockpit_sections_open=false;
int g_cockpit_section_page=0;
const int JPW_FOCUS_SIGNAL_ROLE=-2000,JPW_FOCUS_SIGNAL_COPY=-2001;

// Private retained dialog inventory; fixed bounds avoid allocation during a draw.
// A failed pass cannot authorize pruning or reset a live editor.
string g_details_owned[1024],g_details_kept[1024];
int g_details_owned_count=0,g_details_kept_count=0;
bool g_details_frame_active=false,g_details_inventory_complete=true;
string g_details_render_reason="",g_details_layout_key="",g_details_content_key="";
string g_hud_render_reason="";
void JPWInvalidateDialogContent(const int route)
  { if(g_raiz_details_open && (route<0 || g_raiz_tab==route)) g_details_content_dirty=true; }
bool JPWPresentationDialogObject(const string name)
  { return(g_panel_prefix!="" && StringFind(name,g_panel_prefix+"RAIZ_UI_")==0 &&
           StringFind(name,g_panel_prefix+"RAIZ_UI_HUD_")!=0); }
bool JPWPresentationKeep(const string name)
  {
   if(!g_details_frame_active || !JPWPresentationDialogObject(name)) return(true);
   if(!g_details_inventory_complete) return(false);
   bool known=false;
   for(int i=0;i<g_details_owned_count;i++) if(g_details_owned[i]==name) { known=true; break; }
   if(!known)
     {
      if(g_details_owned_count>=1024) { g_details_inventory_complete=false; return(false); }
      g_details_owned[g_details_owned_count++]=name;
     }
   for(int i=0;i<g_details_kept_count;i++) if(g_details_kept[i]==name) return(true);
   if(g_details_kept_count>=1024) { g_details_inventory_complete=false; return(false); }
   g_details_kept[g_details_kept_count++]=name; return(true);
  }
bool JPWPresentationEnsure(const string name,const ENUM_OBJECT kind)
  {
   const bool already_incomplete=(g_details_frame_active && !g_details_inventory_complete && g_details_render_reason!="");
   if(!JPWPresentationKeep(name) || !JPWUIDesignEnsure(name,kind))
     {
      if(g_details_frame_active) g_details_inventory_complete=false;
      if(!already_incomplete)
         g_details_render_reason="Interface incompleta; controle não confirmado. Amplie ou reabra o painel.";
      return(false);
     }
   return(true);
  }
void JPWPresentationFailure(const string reason)
  {
   g_details_inventory_complete=false; g_details_content_dirty=true;
   g_details_render_reason=reason;
  }
bool JPWPresentationSetInteger(const string name,const ENUM_OBJECT_PROPERTY_INTEGER property,const long value)
  {
   if(JPWUIDesignSetInteger(name,property,value)) return(true);
   JPWPresentationFailure("Interface incompleta; posição ou estado do controle não confirmado.");
   return(false);
  }
bool JPWPresentationSetString(const string name,const ENUM_OBJECT_PROPERTY_STRING property,const string value)
  {
   if(JPWUIDesignSetString(name,property,value)) return(true);
   JPWPresentationFailure("Interface incompleta; conteúdo do controle não confirmado.");
   return(false);
  }
void JPWDialogFrameBegin()
  {
   g_details_frame_active=true; g_details_inventory_complete=true; g_details_kept_count=0;
   if(g_details_focus_route!=g_raiz_tab)
     { g_focus_action=-1; g_editing_field=false; g_details_focus_route=g_raiz_tab; }
   g_focus_count=0;
  }
void JPWDialogFrameEnd()
  {
   g_details_frame_active=false;
   if(!g_details_inventory_complete)
     {
      g_details_content_dirty=true; g_raiz_panel_built=false;
      if(g_details_render_reason=="") g_details_render_reason="Interface incompleta; controles e rascunho preservados.";
      const string title=g_panel_prefix+"RAIZ_UI_TITLE";
      if(ObjectFind(0,title)>=0) JPWPresentationSetString(title,OBJPROP_TEXT,"Conta · interface incompleta");
      return;
     }
   for(int i=0;i<g_details_owned_count;i++)
     {
      bool retained=false;
      for(int j=0;j<g_details_kept_count;j++) if(g_details_kept[j]==g_details_owned[i]) { retained=true; break; }
      if(!retained && !JPWUIDesignDelete(g_details_owned[i]))
         JPWPresentationFailure("Interface incompleta; remoção de controle não confirmada.");
     }
   if(!g_details_inventory_complete) { g_details_content_dirty=true; g_raiz_panel_built=false; return; }
   g_details_owned_count=g_details_kept_count;
   for(int i=0;i<g_details_kept_count;i++) g_details_owned[i]=g_details_kept[i];
   g_details_content_dirty=false; g_details_render_reason="";
  }
string JPWDialogKeyField(const string value)
  { return(IntegerToString(StringLen(value))+":"+value); }
string JPWDialogContentKey()
  {
   // Values, validity, quality, units, identity and provenance all matter. Equal
   // rounded numbers do not make different evidence envelopes interchangeable.
   string key=JPWDialogKeyField(g_sample_context)+"|"+JPWDialogKeyField(_Symbol)+"|"+IntegerToString(g_raiz_tab)+"|"+
      IntegerToString((int)g_cockpit_sections_open)+"|"+IntegerToString(g_cockpit_section_page)+"|"+IntegerToString(g_personal_picker)+"|"+IntegerToString(g_personal_picker_page)+"|"+IntegerToString((int)g_personal_job_active)+"|"+IntegerToString(g_raiz_page)+"|"+IntegerToString(g_cockpit_page)+"|"+JPWDialogKeyField(g_raiz_feedback);
   for(int i=0;i<JPW_COCKPIT_METRIC_COUNT;i++)
     {
      JPWCockpitMetric m=g_cockpit_snapshot.metric[i]; JPWMetricSample e=m.sample;
      key+="|"+JPWDialogKeyField(m.title)+"|"+JPWDialogKeyField(m.value)+"|"+JPWDialogKeyField(m.reason)+"|"+JPWDialogKeyField(m.detail)+"|"+IntegerToString((int)m.quality)+
         "|"+IntegerToString(e.id)+"|"+JPWDialogKeyField(e.context_key)+"|"+JPWDialogKeyField(e.unit)+"|"+JPWDialogKeyField(e.source)+"|"+
         IntegerToString(e.reason_code)+"|"+IntegerToString((int)e.valid)+"|"+
         IntegerToString((int)e.has_value)+"|"+IntegerToString(e.source_time_msc)+"|"+
         IntegerToString(e.observed_utc)+"|"+IntegerToString((long)e.valid_until_monotonic_ms);
     }
   key+="|"+JPWDialogKeyField(g_signal_notice)+"|"+JPWDialogKeyField(g_signal_message)+"|"+IntegerToString((int)g_signal_stage)+"|"+
      IntegerToString((int)g_signal_stale)+"|"+IntegerToString(g_signal_role_edit)+"|"+
      JPWDialogKeyField(g_genetrix_selected_cycle)+"|"+JPWDialogKeyField(g_genetrix_ledger_reason)+"|"+
      JPWDialogKeyField(g_personal_reason)+"|"+JPWDialogKeyField(g_personal_export_result)+"|"+IntegerToString((int)g_personal_available)+"|"+
      IntegerToString((long)g_personal_read_mono)+"|"+JPWDialogKeyField(g_personal_live_notice)+"|"+
      IntegerToString(g_personal_live_count)+"|"+IntegerToString(g_personal_live_state)+"|"+
      JPWDialogKeyField(g_diagnostic_summary)+"|"+JPWDialogKeyField(g_diagnostic_reason)+"|"+JPWDialogKeyField(g_export_preview)+"|"+JPWDialogKeyField(g_export_result);
   return(key);
  }

// Focus belongs to the last explicitly clicked component, not merely to an
// open window. This flag is transient and private to this indicator instance.
// A late ENDEDIT still reaches the existing field handler; it must not steal
// focus back after the user has clicked another indicator's editor.
bool JPWCockpitAcceptChartEvent(const int id,const long &lparam,
                                const double &dparam,const string &object_name)
  {
   static bool cockpit_focus_owner=false;
   static bool recent_object=false;
   static long object_x=0,object_y=0;
   static ulong object_ms=0;
   if(g_panel_prefix=="") { cockpit_focus_owner=false; recent_object=false; }
   const bool own=(g_panel_prefix!="" && StringFind(object_name,g_panel_prefix)==0);
   if(id==CHARTEVENT_OBJECT_CLICK)
     {
      cockpit_focus_owner=own;
      recent_object=MathIsValidNumber(dparam);
      object_x=lparam; object_y=(recent_object ? (long)dparam : 0);
      object_ms=GetTickCount64();
     }
   else if(id==CHARTEVENT_CLICK)
     {
      // MT5 may emit OBJECT_CLICK and CLICK for one gesture in either order.
      // Consume one matching pair; a separate bare chart click releases focus.
      const ulong now=GetTickCount64();
      const bool paired=(recent_object && now>=object_ms && now-object_ms<=1500 &&
         MathIsValidNumber(dparam) && MathAbs(lparam-object_x)<=4 &&
         MathAbs((long)dparam-object_y)<=4);
      if(!paired) cockpit_focus_owner=false;
      recent_object=false;
     }
   return(id!=CHARTEVENT_KEYDOWN || cockpit_focus_owner);
  }

string JPWFitText(const string text,const int available,const int font_size)
  {
   if(available<1) return("");
   if(!TextSetFont("Arial",-10*font_size,FW_NORMAL)) return("…");
   string shown=text;
   uint width=0,height=0;
   if(!TextGetSize(shown,width,height)) return("…");
   if((int)width<=available) return(shown);
   while(StringLen(shown)>1)
     {
      shown=StringSubstr(shown,0,StringLen(shown)-1);
      if(TextGetSize(shown+"…",width,height) && (int)width<=available) return(shown+"…");
     }
   return("…");
  }

void JPWViewMetric(const int index,const string title,const string value,
                   const string reason,const string detail,const JPW_VIEW_QUALITY quality)
  {
   g_cockpit_snapshot.metric[index].sample=g_metric_samples[index];
   g_cockpit_snapshot.metric[index].title=title;
   const bool envelope_current=JPWSampleDisplayValid(g_metric_samples[index],g_sample_context,GetTickCount64());
   g_cockpit_snapshot.metric[index].value=(envelope_current ? value : "N/A");
   g_cockpit_snapshot.metric[index].reason=(!envelope_current && quality!=JPW_VIEW_NA ?
      "Amostra inválida, vencida ou contexto alterado" : reason);
   g_cockpit_snapshot.metric[index].detail=detail;
   g_cockpit_snapshot.metric[index].quality=(envelope_current ? quality : JPW_VIEW_NA);
  }

string JPWStopRiskMoney(const double value)
  {
   if(!MathIsValidNumber(value) || value<0.0) return("N/A");
   if(value>0.0 && value<0.01) return("<0,01");
   string shown=StringFormat("%.2f",value);
   StringReplace(shown,".",",");
   return(shown);
  }

void JPWBuildPresentation(const string leverage_value,const string leverage_detail)
  {
   g_cockpit_snapshot.sequence=g_collection_sequence;
   g_cockpit_snapshot.symbol=_Symbol;
   g_cockpit_snapshot.account_key=g_sample_context;
   JPWViewMetric(0,"Leverage",leverage_value,g_leverage_reason,leverage_detail,g_leverage_quality);
   JPWViewMetric(1,"Floating P/L",g_floating_value,g_floating_reason,
                 g_floating_tooltip,g_floating_quality);
   JPWViewMetric(2,"Genesis SL",g_genesis_value,g_genesis_reason,
                 g_genesis_tooltip,g_genesis_quality);
   JPWViewMetric(3,"Raiz N 1W",g_raiz_value,g_raiz_reason,
                 g_raiz_tooltip,g_raiz_quality);
   JPWViewMetric(4,"Raiz N 2W",g_scale2_value,g_scale2_reason,
                 g_scale2_tooltip,g_scale2_quality);
   JPWViewMetric(5,"Stop risk",g_stop_value,g_stop_reason,
                 g_stop_detail,g_stop_quality);
   JPWGenetrixPresentMetric();
  }

// Localize only the denominator token in a copy; canonical producer values stay intact.
string JPWCockpitMetricValue(const int index,const string canonical)
  {
   string display=canonical;
   if(index==5) StringReplace(display,"% balance","% saldo");
   return(display);
  }
// Accepted StopRisk read-view only: never infer the attributed group from the chart symbol.
string JPWRiskDisplayScope()
  {
   const ulong now=GetTickCount64();
   const bool current=g_stop_ready && g_diagnostic_context!="" &&
      g_stop_sample.account_key==g_diagnostic_context && g_stop_sample.observed_mono_ms>0 &&
      now>=(ulong)g_stop_sample.observed_mono_ms && now-(ulong)g_stop_sample.observed_mono_ms<=30000;
   if(!current) return("Grupo indisponível");
   if(g_stop_scope_valid && g_stop_scope_symbol!="" && (g_stop_scope_side==1 || g_stop_scope_side==-1))
      return("Grupo "+g_stop_scope_symbol+" · "+(g_stop_scope_side==1 ? "Compra" : "Venda"));
   if(g_stop_quality==JPW_VIEW_CURRENT && g_stop_sample.row_count==0 && ArraySize(g_stop_rows)==0)
      return("Sem exposição confirmada");
   return("Grupo indisponível");
  }

void JPWStoikusHUDCleanup();
void JPWClearPanel()
  {
   JPWStoikusHUDCleanup();
   for(int i=0;i<g_panel_count;i++) JPWUIDesignDelete(g_panel_prefix+IntegerToString(i));
   JPWUIDesignDelete(g_panel_prefix+"RAIZ_DETAILS_BUTTON");
   JPWUIDesignDelete(g_panel_prefix+"HUD_BG");
   JPWUIDesignDelete(g_panel_prefix+"HUD_RISK_SCOPE");
   JPWUIDesignDelete(g_panel_prefix+"RAIZ_UI_HUD_LABEL");
   JPWUIDesignDeleteIcon(g_panel_prefix+"RAIZ_UI_HUD_ICON");
   g_panel_count=0;
  }

// Essential access can outlive an undersized financial summary. No metric is
// represented by this orientation-only label; the full reason remains in its tip.
void JPWHUDUnavailable(const string reason)
  {
   JPWClearPanel(); g_hud_summary=true; g_hud_summary_source=-1;
   const int chart_width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   const int chart_height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
   const int pad=JPWUIDesignPx(4);
   const int font=8;
   if(chart_width<=2*pad || chart_height<=2*pad || !TextSetFont("Arial",-10*font,FW_NORMAL)) return;
   string label="Conta · amplie o gráfico";
   uint w=0,h=0;
   if(!TextGetSize(label,w,h) || (int)w>chart_width-2*pad) label="Amplie";
   if(!TextGetSize(label,w,h) || (int)w>chart_width-2*pad || (int)h>chart_height-2*pad) return;
   const string name=g_panel_prefix+"RAIZ_UI_HUD_LABEL";
   if(!JPWPresentationEnsure(name,OBJ_LABEL)) return;
   JPWPresentationSetInteger(name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   JPWPresentationSetInteger(name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   JPWPresentationSetInteger(name,OBJPROP_XDISTANCE,pad);
   JPWPresentationSetInteger(name,OBJPROP_YDISTANCE,pad);
   JPWPresentationSetInteger(name,OBJPROP_FONTSIZE,font);
   JPWPresentationSetInteger(name,OBJPROP_COLOR,JPWPanelTextColor((color)ChartGetInteger(0,CHART_COLOR_BACKGROUND),InpFontColor));
   JPWPresentationSetInteger(name,OBJPROP_ZORDER,3);
   JPWPresentationSetInteger(name,OBJPROP_SELECTABLE,false);
   JPWPresentationSetInteger(name,OBJPROP_HIDDEN,true);
   JPWPresentationSetString(name,OBJPROP_FONT,"Arial");
   JPWPresentationSetString(name,OBJPROP_TEXT,label);
   JPWPresentationSetString(name,OBJPROP_TOOLTIP,"Stoikus · Conta · "+reason+" · amplie o gráfico.");
  }

#include <JPWealth/JPW_Stoikus_HUD.mqh>
#include <JPWealth/JPW_Stoikus_Window.mqh>
const int JPW_ACTION_MINIMIZE=161;
JPWStoikusWindowGesture g_account_window_gesture;
JPWPanelRect g_account_window_rect;
void JPWRenderHUDBody()
  { JPWStoikusHUDRender(); }

void JPWRenderCurrentDisplay()
  {
   // Pure presentation: no terminal financial reads, record reads or writers.
   if(g_panel_prefix=="") return;
   JPWBuildPresentation(g_panel_value,"Alavancagem = nocional bruto na moeda da conta / último equity informado pelo terminal. " + g_panel_status);
   JPWUIDesignBeginPass();
   JPWRenderHUD(); JPWRenderRaizDetails(); JPWUIDesignEndPass();
  }

void JPWRender(const string value,const string state="")
  {
   // Cached values only. Collection/persistence is owned by the coordinator.
   JPWRenderCurrentDisplay();
  }

string JPWGenesisFormatPoints(const double points)
  {
   if(points>0.0 && points<0.01) return("<0,01 pts");
   return(DoubleToString(points,2)+" pts");
  }

string JPWRaizPercentText(const double percent)
  {
   if(percent>0.0 && percent<0.01) return("<0,01%");
   string shown=DoubleToString(percent,2);
   StringReplace(shown,".",",");
   return(shown+"%");
  }

string JPWNoTouchPercentText(const double percent)
  {
   string shown=DoubleToString(percent,3);
   StringReplace(shown,".",",");
   return(shown+"%");
  }

string JPWRaizPriceText(const double price,const int digits)
  {
   const string shown=DoubleToString(price,digits);
   if(price>0.0 && StringToDouble(shown)==0.0)
      return(StringFormat("%.8g",price));
   return(shown);
  }

string JPWRaizUI(const string suffix)
  { return(g_panel_prefix+"RAIZ_UI_"+suffix); }

string JPWActionObject(const int action)
  { return(JPWRaizUI("BUTTON_"+IntegerToString(action))); }

// Ephemeral focus scope. Rebuilds may retain a valid action in the same route,
// but a reused numeric ID in another route never inherits keyboard authority.
void JPWRaizPanelDestroy()
  {
   if(g_panel_prefix=="") return;
   // Destroyed EDIT objects no longer own keyboard input; drafts are saved by the caller.
   g_editing_field=false;
   if(!g_raiz_details_open || g_details_focus_route!=g_raiz_tab)
     { g_focus_action=-1; g_details_focus_route=-1; }
   // Registration is cleared below: until redraw, even a retained same-route
   // ID is not a valid target because its graphical object no longer exists.
   // Delete every object owned by this dialog, including new tab/table
   // controls. Iterate backwards because ObjectDelete changes enumeration.
   const string owned=g_panel_prefix+"RAIZ_UI_";
   for(int i=ObjectsTotal(0,-1,-1)-1;i>=0;i--)
     {
      const string name=ObjectName(0,i,-1,-1);
      if(JPWPresentationDialogObject(name)) JPWUIDesignDelete(name);
     }
   g_raiz_panel_built=false; g_focus_count=0; g_details_owned_count=0;
   g_details_kept_count=0; g_details_content_dirty=true; g_details_layout_key=""; g_details_content_key="";
  }

bool JPWRaizCreateLabel(const string suffix,const string value,
                        const int x,const int y,const int font_size=0)
  {
   const string name=JPWRaizUI(suffix);
   if(!JPWPresentationEnsure(name,OBJ_LABEL)) return(false);
   const int font=(font_size>0 ? font_size : g_details_font+(suffix=="PH_TITLE" ? 1 : 0));
   const string shown=JPWFitText(value,g_details_rect.x+g_details_rect.width-g_details_pad-x,font);
   // Visual role is explicit in owned object names, never inferred from a
   // translated financial message or from the metric's numeric value.
   const color background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
   const bool secondary=(suffix=="PAGE" || suffix=="FEEDBACK" ||
      suffix=="STOP_PAGE" || suffix=="STOP_SCOPE" ||
      StringFind(suffix,"_REASON")>=0);
   const color ink=(secondary ? JPWPanelMutedText(background) :
      (StringFind(suffix,"_QUALITY")>=0 ? JPWPanelAccentColor(background) : g_details_text));
   return(JPWPresentationSetInteger(name,OBJPROP_CORNER,CORNER_LEFT_UPPER) &&
          JPWPresentationSetInteger(name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER) &&
          JPWPresentationSetInteger(name,OBJPROP_XDISTANCE,x) &&
          JPWPresentationSetInteger(name,OBJPROP_YDISTANCE,y) &&
          JPWPresentationSetInteger(name,OBJPROP_COLOR,ink) &&
          JPWPresentationSetInteger(name,OBJPROP_FONTSIZE,font) &&
          JPWPresentationSetInteger(name,OBJPROP_ZORDER,3) &&
          JPWPresentationSetInteger(name,OBJPROP_SELECTABLE,false) &&
          JPWPresentationSetInteger(name,OBJPROP_HIDDEN,true) &&
          JPWPresentationSetString(name,OBJPROP_FONT,"Arial") &&
          JPWPresentationSetString(name,OBJPROP_TEXT,shown) &&
          JPWPresentationSetString(name,OBJPROP_TOOLTIP,value));
  }

bool JPWCreateProtectedValue(const string suffix,const string value,const int x,
                              const int y,const int width,const int font_size=0)
  {
   const int font=(font_size>0 ? font_size : g_details_font);
   uint measured=0,height=0;
   if(!TextSetFont("Arial",-10*font,FW_NORMAL) ||
      !TextGetSize(value,measured,height)) return(false);
   const string shown=((int)measured<=width ? value : "Ver valor no detalhe");
   const bool made=JPWRaizCreateLabel(suffix,shown,x,y,font);
   if(made) JPWPresentationSetString(JPWRaizUI(suffix),OBJPROP_TOOLTIP,value);
   return(made);
  }

bool JPWRaizCreateSurface(const string suffix,const int x,const int y,
                          const int width,const int height,const color fill)
  {
   if(width<1 || height<1) return(false);
   const string name=JPWRaizUI(suffix);
   if(!JPWPresentationEnsure(name,OBJ_RECTANGLE_LABEL)) return(false);
   return(JPWPresentationSetInteger(name,OBJPROP_CORNER,CORNER_LEFT_UPPER) &&
          JPWPresentationSetInteger(name,OBJPROP_XDISTANCE,x) &&
          JPWPresentationSetInteger(name,OBJPROP_YDISTANCE,y) &&
          JPWPresentationSetInteger(name,OBJPROP_XSIZE,width) &&
          JPWPresentationSetInteger(name,OBJPROP_YSIZE,height) &&
          JPWPresentationSetInteger(name,OBJPROP_BGCOLOR,fill) &&
          JPWPresentationSetInteger(name,OBJPROP_COLOR,g_details_border) &&
          JPWPresentationSetInteger(name,OBJPROP_BORDER_TYPE,BORDER_FLAT) &&
          JPWPresentationSetInteger(name,OBJPROP_BACK,false) &&
          JPWPresentationSetInteger(name,OBJPROP_ZORDER,2) &&
          JPWPresentationSetInteger(name,OBJPROP_SELECTABLE,false) &&
          JPWPresentationSetInteger(name,OBJPROP_HIDDEN,true));
  }

void JPWRenderHUD()
  { JPWUIDesignBeginPass(); JPWRenderHUDBody(); JPWUIDesignEndPass(); }

void JPWFocusRegister(const int action);

bool JPWRaizCreateEdit(const int index,const int x,const int y,const int width)
  {
   const string name=JPWRaizUI("EDIT_"+IntegerToString(index));
   if(!JPWPresentationEnsure(name,OBJ_EDIT)) return(false);
   JPWFocusRegister(-1000-index);
   return(JPWPresentationSetInteger(name,OBJPROP_CORNER,CORNER_LEFT_UPPER) &&
          JPWPresentationSetInteger(name,OBJPROP_XDISTANCE,x) &&
          JPWPresentationSetInteger(name,OBJPROP_YDISTANCE,y) &&
          JPWPresentationSetInteger(name,OBJPROP_XSIZE,width) &&
          JPWPresentationSetInteger(name,OBJPROP_YSIZE,g_details_control) &&
          JPWPresentationSetInteger(name,OBJPROP_FONTSIZE,g_details_font) &&
          JPWPresentationSetInteger(name,OBJPROP_COLOR,g_details_text) &&
          JPWPresentationSetInteger(name,OBJPROP_BGCOLOR,g_details_surface) &&
          JPWPresentationSetInteger(name,OBJPROP_BORDER_COLOR,g_details_border) &&
          JPWPresentationSetInteger(name,OBJPROP_ZORDER,4) &&
          JPWPresentationSetInteger(name,OBJPROP_READONLY,false) &&
          JPWPresentationSetInteger(name,OBJPROP_SELECTABLE,true) &&
          JPWPresentationSetInteger(name,OBJPROP_HIDDEN,true) &&
          JPWPresentationSetString(name,OBJPROP_FONT,"Arial") &&
          (g_editing_field && g_focus_action==-1000-index ? true :
            JPWPresentationSetString(name,OBJPROP_TEXT,g_raiz_fields[index])));
  }

void JPWFocusRegister(const int action)
  {
   if(g_details_focus_route!=g_raiz_tab)
     {
      g_focus_action=-1; g_editing_field=false; g_focus_count=0;
      g_details_focus_route=g_raiz_tab;
     }
   for(int i=0;i<g_focus_count;i++) if(g_focus_actions[i]==action) return;
   if(g_focus_count<128) g_focus_actions[g_focus_count++]=action;
  }

string JPWFocusObject(const int action)
   { return(action==JPW_FOCUS_SIGNAL_ROLE ? JPWRaizUI("EDIT_SIGNAL_ROLE") :
      (action==JPW_FOCUS_SIGNAL_COPY ? JPWRaizUI("EDIT_SIGNAL_COPY") :
      (action<=-1000 ? JPWRaizUI("EDIT_"+IntegerToString(-1000-action)) :
       JPWRaizUI("BUTTON_"+IntegerToString(action))))); }

bool JPWFocusRegistered(const int action)
  {
   for(int i=0;i<g_focus_count;i++) if(g_focus_actions[i]==action) return(true);
   return(false);
  }

bool JPWFocusValid(const int action)
  {
   if(!g_raiz_details_open || action==-1 || g_details_focus_route!=g_raiz_tab ||
      !JPWFocusRegistered(action)) return(false);
   if(g_details_render_reason!="" && action!=JPW_ACTION_CLOSE &&
      action!=JPW_ACTION_HEADER_CLOSE && action!=JPW_ACTION_LEGACY_CANCEL) return(false);
   const string name=JPWFocusObject(action);
   if(ObjectFind(0,name)<0) return(false);
   return(ObjectGetInteger(0,name,OBJPROP_TYPE)==(action<=-1000 ? OBJ_EDIT : OBJ_BUTTON));
  }

void JPWFocusPaint()
  {
   for(int i=0;i<g_focus_count;i++)
     {
      const int action=g_focus_actions[i];
      const string name=JPWFocusObject(action);
      const bool focused=(action==g_focus_action && JPWFocusValid(action));
      if(action<=-1000)
         JPWPresentationSetInteger(name,OBJPROP_SELECTED,focused);
      const bool card_title=(g_focus_actions[i]>=JPW_ACTION_CARD_FIRST &&
                            g_focus_actions[i]<JPW_ACTION_CARD_FIRST+JPW_COCKPIT_METRIC_COUNT);
      JPWPresentationSetInteger(name,OBJPROP_BORDER_COLOR,
                       focused ?
                       JPWUIDesignFocusInk((color)ChartGetInteger(0,CHART_COLOR_BACKGROUND)) :
                       (card_title ? g_details_card : g_details_border));
     }
  }

void JPWFocusStep(const bool backward)
  {
   if(g_focus_count==0) return;
   JPWUIDesignBeginPass();
   int current=-1;
   if(JPWFocusValid(g_focus_action))
      for(int i=0;i<g_focus_count;i++) if(g_focus_actions[i]==g_focus_action) current=i;
   for(int step=0;step<g_focus_count;step++)
     {
      current=(current<0 ? (backward ? g_focus_count-1 : 0) :
               (current+(backward ? g_focus_count-1 : 1))%g_focus_count);
      if(!JPWFocusValid(g_focus_actions[current])) continue;
      g_focus_action=g_focus_actions[current];
      g_editing_field=(g_focus_action<=-1000);
      JPWFocusPaint(); JPWUIDesignEndPass(); return;
     }
   g_focus_action=-1; g_editing_field=false;
   JPWFocusPaint(); JPWUIDesignEndPass();
  }

bool JPWRaizCreateButton(const int index,const string value,
                          const int x,const int y,const int width)
  {
   const string name=JPWRaizUI("BUTTON_"+IntegerToString(index));
   if(!JPWPresentationEnsure(name,OBJ_BUTTON)) return(false);
   JPWFocusRegister(index);
   const color background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
   const bool primary=(index==JPW_ACTION_APPLY || index==JPW_ACTION_REFRESH ||
       index==JPW_SIGNAL_CONFIRM || index==JPW_SIGNAL_PREPARE || index==JPW_SIGNAL_SAVE || index==JPW_SIGNAL_ROLE_APPLY ||
      (index==JPW_ACTION_LEGACY_APPLY &&
       (g_raiz_tab==JPW_ROUTE_JUSTIFY || g_raiz_tab==JPW_ROUTE_BIND ||
        g_raiz_tab==JPW_ROUTE_LEGACY_NF || g_raiz_tab==JPW_ROUTE_FACTOR)) ||
      (index==JPW_ACTION_SECONDARY &&
       (g_raiz_tab==JPW_ROUTE_EXPORT || g_raiz_tab==JPW_ROUTE_PROVENANCE)));
   const bool selected_factor=(g_raiz_tab==JPW_ROUTE_FACTOR &&
      ((index==JPW_ACTION_FACTOR_15 && g_factor_draft==1.5) ||
       (index==JPW_ACTION_FACTOR_18 && g_factor_draft==1.8)));
   const color ink=(primary ? JPWUIDesignPrimaryInk(background) :
      (selected_factor ? JPWPanelAccentColor(background) : g_details_text));
   const color fill=(primary ? JPWUIDesignPrimaryFill(background) :
      (selected_factor ? JPWPanelSelectedSurface(background) : g_details_card));
   return(JPWPresentationSetInteger(name,OBJPROP_CORNER,CORNER_LEFT_UPPER) &&
          JPWPresentationSetInteger(name,OBJPROP_XDISTANCE,x) &&
          JPWPresentationSetInteger(name,OBJPROP_YDISTANCE,y) &&
          JPWPresentationSetInteger(name,OBJPROP_XSIZE,width) &&
          JPWPresentationSetInteger(name,OBJPROP_YSIZE,g_details_control) &&
          JPWPresentationSetInteger(name,OBJPROP_FONTSIZE,g_details_font) &&
          JPWPresentationSetInteger(name,OBJPROP_COLOR,ink) &&
          JPWPresentationSetInteger(name,OBJPROP_BGCOLOR,fill) &&
          JPWPresentationSetInteger(name,OBJPROP_BORDER_COLOR,g_details_border) &&
          JPWPresentationSetInteger(name,OBJPROP_ZORDER,4) &&
          JPWPresentationSetInteger(name,OBJPROP_HIDDEN,true) &&
          JPWPresentationSetString(name,OBJPROP_FONT,"Arial") &&
          JPWPresentationSetString(name,OBJPROP_TEXT,JPWFitText(value,width-2*JPWUIDesignPx(8),g_details_font)) &&
          JPWPresentationSetString(name,OBJPROP_TOOLTIP,value));
  }

void JPWDetailsAppendLine(const string row,string &lines[])
  {
   if(row=="" || (g_details_frame_active && !g_details_inventory_complete)) return;
   const int count=ArraySize(lines);
   if(ArrayResize(lines,count+1)!=count+1)
     { JPWPresentationFailure("Texto indisponível: memória insuficiente. Feche e reabra Conta."); return; }
   lines[count]=row;
  }

void JPWDetailsWrap(const string paragraph,const int width,string &lines[])
  {
   if(g_details_frame_active && !g_details_inventory_complete) return;
   string text=paragraph;
   StringReplace(text,"\n"," ");
   if(width<1 || !TextSetFont("Arial",-10*g_details_font,FW_NORMAL)) return;
   const int safe_width=(width>4 ? width-4 : width);
   string words[];
   const int count=StringSplit(text,' ',words);
   if(count<0)
     { JPWPresentationFailure("Texto indisponível: separação do conteúdo falhou. Feche e reabra Conta."); return; }
   string row="";
   uint measured=0,height=0;
   for(int i=0;i<count;i++)
     {
      if(words[i]=="") continue;
      const string joined=(row=="" ? words[i] : row+" "+words[i]);
      if(TextGetSize(joined,measured,height) && (int)measured<=safe_width)
        { row=joined; continue; }
      JPWDetailsAppendLine(row,lines);
      if(!g_details_inventory_complete) return;
      row="";
      if(TextGetSize(words[i],measured,height) && (int)measured<=safe_width)
        { row=words[i]; continue; }
      // Preserve entire long numeric/provenance tokens by breaking only those
      // that cannot fit on an otherwise empty line.
      string segment="";
      for(int j=0;j<StringLen(words[i]);j++)
        {
         const string next=segment+StringSubstr(words[i],j,1);
         if(segment!="" && TextGetSize(next,measured,height) &&
            (int)measured>safe_width)
           {
            JPWDetailsAppendLine(segment,lines);
            if(!g_details_inventory_complete) return;
            segment="";
           }
         segment+=StringSubstr(words[i],j,1);
        }
      row=segment;
     }
   JPWDetailsAppendLine(row,lines);
  }

bool JPWDetailsContextCurrent()
  {
   if(!g_raiz_draft_account_known || !g_account_known ||
      g_raiz_draft_symbol!=_Symbol || !JPWAccountsEqual(g_account,g_raiz_draft_account) ||
      g_cockpit_snapshot.symbol!=_Symbol || g_sample_context=="" ||
      g_cockpit_snapshot.account_key!=g_sample_context)
     {
      g_raiz_details_open=false; g_raiz_draft_account_known=false;
      g_raiz_draft_expected_id=""; JPWRaizPanelDestroy(); return(false);
     }
   return(true);
  }

string JPWPositionTicket(const ulong ticket)
  { return(StringFormat("%I64u",ticket)); }

string JPWPositionLeverageText(JPWPositionView &row)
  {
   if(!row.leverage_valid || row.quality==JPW_VIEW_NA) return("N/A");
   return((row.quality==JPW_VIEW_ESTIMATED ? "≈" : "")+JPWFormatLeverage(row.leverage));
  }

string JPWPositionRole(JPWPositionView &row)
  {
   if(g_positions_view.margin_mode!=ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      return("Net position");
   if(g_stop_genesis_identifier>0 && row.identifier==g_stop_genesis_identifier)
      return("Gênese · referência");
   if(g_stop_scope_valid && row.symbol==g_stop_scope_symbol &&
      (row.direction==POSITION_TYPE_BUY ? 1 : -1)==g_stop_scope_side)
     {
      int ordinal=1;
      for(int i=0;i<ArraySize(g_position_views);i++)
        {
         JPWPositionView other=g_position_views[i];
         if(other.identifier==row.identifier || other.symbol!=row.symbol || other.direction!=row.direction) continue;
         if(other.opened_msc==row.opened_msc) return("Posição · empate temporal");
         if(other.identifier==g_stop_genesis_identifier) continue;
         if(other.opened_msc<row.opened_msc ||
            (other.opened_msc==row.opened_msc && other.ticket<row.ticket)) ordinal++;
        }
      return("Defesa "+IntegerToString(ordinal)+" · inferida");
     }
   return("Posição");
  }

string JPWPositionRoleShort(JPWPositionView &row)
  {
   const string role=JPWPositionRole(row);
   if(StringFind(role,"Gênese")==0) return("Gênese");
   if(StringFind(role,"Defesa ")==0)
     {
      const int end=StringFind(role," ·");
      return("D"+StringSubstr(role,7,end-7));
     }
   if(StringFind(role,"Net")==0) return("Net");
   if(StringFind(role,"empate")>=0) return("Empate");
   return("Pos");
  }

bool JPWPositionRiskView(JPWPositionView &position,string &amount,string &percent,
                          string &state,string &reason)
  {
   amount="N/A"; percent="N/A"; state="N/A";
   reason="Sem amostra de Stops correspondente do observador";
   const bool historical=(!g_stop_ready && g_stop_last_ready);
   if(!g_stop_ready && !historical) return(false);
   JPWStopRiskSample sample;
   if(historical) sample=g_stop_last_sample; else sample=g_stop_sample;
   if(g_positions_view.context_key!=g_sample_context || sample.account_key!=g_positions_view.account_key)
     { reason="Contexto do observador diferente da leitura de posições"; return(false); }
   if(!position.entry_valid || !position.sl_valid)
     { reason="Entrada ou SL não conferido nesta leitura"; return(false); }
   const int count=(historical ? ArraySize(g_stop_last_rows) : ArraySize(g_stop_rows));
   for(int i=0;i<count;i++)
     {
      JPWStopRiskRow row;
      if(historical) row=g_stop_last_rows[i]; else row=g_stop_rows[i];
      if(row.kind!=JPW_STOP_RISK_POSITION || (ulong)row.ticket!=position.ticket ||
         row.identifier!=position.identifier || row.symbol!=position.symbol ||
         row.side!=(position.direction==POSITION_TYPE_BUY ? 1 : -1) ||
         row.volume!=position.volume || row.entry!=position.entry || row.sl!=position.sl) continue;
      state=(historical ? "LAST · NOT ACTIVE" : "Current");
      reason=row.reason;
      if(row.valid!=1 || !MathIsValidNumber(row.risk_money) || row.risk_money<0.0 ||
         !JPWFinitePositive(sample.balance))
        { if(!historical) state="N/A";
          if(reason=="") reason="Risco ou balance indisponível na amostra EA"; return(false); }
      amount=JPWStopRiskMoney(row.risk_money)+" "+sample.currency;
      percent=JPWFormatPercent(100.0*row.risk_money/sample.balance,false);
      return(true);
     }
   reason="Composição, entrada, volume ou SL divergem da amostra do observador";
   return(false);
  }

bool JPWPositionInView(JPWPositionView &row)
  {
   return(!g_positions_operation_only || (g_stop_scope_valid &&
      row.symbol==g_stop_scope_symbol &&
      (row.direction==POSITION_TYPE_BUY ? 1 : -1)==g_stop_scope_side));
  }

void JPWRenderPositionsTable(const int x,const int body_y,const int inner,
                              const int body_height,const int footer_y)
  {
   g_stop_button_count=0; g_positions_visible_rows=0; g_positions_total_rows=0;
   if(!JPWPositionsViewCurrent(g_sample_context,GetTickCount64()))
     {
      JPWRaizCreateLabel("POSITIONS_EMPTY","Posições: N/A · "+g_positions_view.reason,x,body_y);
      JPWPresentationSetString(JPWRaizUI("POSITIONS_EMPTY"),OBJPROP_TOOLTIP,
                      "O catálogo é independente do EA. Atualizar solicita uma nova leitura consistente.");
      return;
     }
   if(g_positions_operation_only && !g_stop_scope_valid)
     {
      JPWRaizCreateLabel("POSITIONS_EMPTY","Operação não atribuída; use Conta para ver todas as posições.",x,body_y);
      return;
     }
   int indexes[];
   for(int i=0;i<ArraySize(g_position_views);i++)
     {
      JPWPositionView row=g_position_views[i];
      if(!JPWPositionInView(row)) continue;
      const int count=ArraySize(indexes);
      if(ArrayResize(indexes,count+1)!=count+1)
        {
         JPWRaizCreateLabel("POSITIONS_EMPTY","Posições: N/A · memória insuficiente",x,body_y);
         JPWPresentationFailure("Posições indisponíveis: memória insuficiente. Feche e reabra Conta.");
         return;
        }
      int at=count;
      while(at>0 && (StringCompare(g_position_views[indexes[at-1]].symbol,row.symbol)>0 ||
            (g_position_views[indexes[at-1]].symbol==row.symbol &&
             (g_position_views[indexes[at-1]].direction>row.direction ||
              (g_position_views[indexes[at-1]].direction==row.direction &&
               (g_position_views[indexes[at-1]].opened_msc>row.opened_msc ||
                (g_position_views[indexes[at-1]].opened_msc==row.opened_msc &&
                 g_position_views[indexes[at-1]].ticket>row.ticket)))))))
        { indexes[at]=indexes[at-1]; at--; }
      indexes[at]=i;
     }
   g_positions_total_rows=ArraySize(indexes);
   if(g_positions_total_rows==0)
     {
      g_positions_scroll=0;
      JPWRaizCreateLabel("POSITIONS_EMPTY","Nenhuma posição informada pelo terminal nesta leitura.",x,body_y);
      return;
     }
   const int text_height=g_details_line-g_details_pad;
   const int gap=(text_height/12>2 ? text_height/12 : 2);
   // Measure every value before choosing columns; never truncate financial values.
   int widths[6]; for(int c=0;c<6;c++) widths[c]=0;
   const string headers[6]={"Ativo / papel","Ticket MT5","Lote","Leverage","Stop · EA","% saldo"};
   TextSetFont("Arial",-10*g_details_font,FW_NORMAL);
   for(int c=0;c<6;c++)
     { uint w=0,h=0; if(TextGetSize(headers[c],w,h)) widths[c]=(int)w+2*gap; }
   for(int i=0;i<ArraySize(indexes);i++)
     {
      JPWPositionView row=g_position_views[indexes[i]];
      string amount="",percent="",state="",reason="";
      JPWPositionRiskView(row,amount,percent,state,reason);
      string values[6];
      values[0]=row.symbol+" "+(row.direction==POSITION_TYPE_BUY ? "BUY" : "SELL");
      values[1]=JPWPositionTicket(row.ticket);
      values[2]=DoubleToString(row.volume,row.volume_digits);
      values[3]=JPWPositionLeverageText(row);
      values[4]=amount+(state=="LAST · NOT ACTIVE" ? " LAST" : ""); values[5]=percent;
      for(int c=0;c<6;c++)
        { uint w=0,h=0; if(TextGetSize(values[c],w,h) && (int)w+2*gap>widths[c]) widths[c]=(int)w+2*gap; }
     }
   // The name may abbreviate; ticket, volume, leverage and money may not.
   int numeric_width=0; for(int c=1;c<6;c++) numeric_width+=widths[c];
   const int name_min=6*text_height;
   const bool columns=(numeric_width+name_min<=inner);
   if(columns) widths[0]=inner-numeric_width;
   JPWPositionsLayout layout; JPWPanelPositionsLayout(body_height,text_height,columns,layout);
   // The entire row is a click target; text density cannot shrink its hit area.
   layout.row_height=MathMax(layout.row_height,g_details_control+gap);
   if(layout.table_offset+layout.row_height>body_height)
     { layout.summary_height=0; layout.header_height=0; layout.table_offset=0; }
   layout.visible_rows=JPWPanelClamp((body_height-layout.table_offset)/layout.row_height,0,16);
   g_positions_visible_rows=layout.visible_rows;
   const int maximum=(g_positions_total_rows>layout.visible_rows ? g_positions_total_rows-layout.visible_rows : 0);
   g_positions_scroll=JPWPanelClamp(g_positions_scroll,0,maximum);
   const string scope=(g_positions_operation_only ? "Grupo símbolo/direção" : "Conta inteira");
   const string risk_state=(g_stop_ready ? "Stops EA" : (g_stop_last_ready ? "Stops LAST · NOT ACTIVE" : "Stops: sem EA"));
   if(layout.summary_height>0)
     {
      const string summary=scope+" · "+IntegerToString(g_positions_total_rows)+" posições · "+
         JPWCockpitQualityText((JPW_VIEW_QUALITY)g_positions_view.quality)+" · "+risk_state;
      JPWRaizCreateLabel("POSITIONS_SUMMARY",JPWFitText(summary,inner,g_details_font),x,body_y);
      JPWPresentationSetString(JPWRaizUI("POSITIONS_SUMMARY"),OBJPROP_TOOLTIP,
         summary+". Leverage = nocional da posição / equity da conta; não é margem. "+
         "O consolidado Stop risk continua limitado à operação atribuída.");
     }
   if(layout.visible_rows<1)
     {
      if(body_height>=g_details_control)
        {
         g_positions_visible_rows=1;
         g_positions_scroll=JPWPanelClamp(g_positions_scroll,0,g_positions_total_rows-1);
         const int index=indexes[g_positions_scroll];
         const string ticket=JPWPositionTicket(g_position_views[index].ticket);
         JPWRaizCreateButton(JPW_ACTION_STOP_ROW_FIRST,"Posição · "+ticket+" · detalhe",x,body_y,inner);
         JPWPresentationSetString(JPWActionObject(JPW_ACTION_STOP_ROW_FIRST),OBJPROP_TOOLTIP,
            "Ticket "+ticket+". Texto ampliado: abra o detalhe ou role nesta mesma aba para outra posição.");
         g_position_button_row[0]=index;
         g_position_button_ticket[0]=g_position_views[index].ticket;
         g_position_button_identifier[0]=g_position_views[index].identifier; g_stop_button_count=1;
        }
      return;
     }
   int col_x[6]; col_x[0]=x; for(int c=1;c<6;c++) col_x[c]=col_x[c-1]+widths[c-1];
   const int header_y=body_y+layout.summary_height;
   if(columns && layout.header_height>0)
     {
      JPWRaizCreateSurface("POSITIONS_HEADER",x,header_y,inner,layout.header_height,g_details_chrome);
      for(int c=0;c<6;c++) JPWRaizCreateLabel("POSITIONS_HEAD_"+IntegerToString(c),headers[c],col_x[c]+gap,header_y);
     }
   const int table_y=body_y+layout.table_offset;
   for(int j=0;j<layout.visible_rows && g_positions_scroll+j<g_positions_total_rows;j++)
     {
      const int index=indexes[g_positions_scroll+j]; JPWPositionView row=g_position_views[index];
      const int y=table_y+j*layout.row_height;
      string amount="",percent="",state="",reason=""; JPWPositionRiskView(row,amount,percent,state,reason);
      const string ticket=JPWPositionTicket(row.ticket),volume=DoubleToString(row.volume,row.volume_digits);
      const string leverage=JPWPositionLeverageText(row);
      const string role=JPWPositionRole(row);
      const string tooltip=role+" · "+row.symbol+" "+(row.direction==POSITION_TYPE_BUY ? "BUY" : "SELL")+
         "; ticket "+ticket+"; volume "+volume+" lote; Leverage "+leverage+" · "+JPWCockpitQualityText((JPW_VIEW_QUALITY)row.quality)+
         "; "+row.reason+". Stop "+amount+" · "+percent+" saldo · "+state+". "+reason;
      JPWRaizCreateButton(JPW_ACTION_STOP_ROW_FIRST+j,"",x,y,inner);
      JPWPresentationSetInteger(JPWActionObject(JPW_ACTION_STOP_ROW_FIRST+j),OBJPROP_YSIZE,layout.row_height-gap);
      JPWPresentationSetInteger(JPWActionObject(JPW_ACTION_STOP_ROW_FIRST+j),OBJPROP_BGCOLOR,
                         j%2==0 ? g_details_card : g_details_chrome);
      JPWPresentationSetString(JPWActionObject(JPW_ACTION_STOP_ROW_FIRST+j),OBJPROP_TOOLTIP,tooltip);
      if(columns)
        {
         string values[6]; values[0]=JPWPositionRoleShort(row)+" · "+row.symbol+" "+(row.direction==POSITION_TYPE_BUY ? "B" : "S");
         values[1]=ticket; values[2]=volume; values[3]=leverage;
         values[4]=amount+(state=="LAST · NOT ACTIVE" ? " LAST" : ""); values[5]=percent;
         for(int c=0;c<6;c++)
           {
            const string suffix="POSITION_CELL_"+IntegerToString(j)+"_"+IntegerToString(c);
            JPWRaizCreateLabel(suffix,c==0 ? JPWFitText(values[c],widths[c]-2*gap,g_details_font) : values[c],
                               col_x[c]+gap,y);
            JPWPresentationSetInteger(JPWRaizUI(suffix),OBJPROP_ZORDER,5);
            JPWPresentationSetString(JPWRaizUI(suffix),OBJPROP_TOOLTIP,tooltip);
           }
        }
      else
        {
         string lines[4];
         lines[0]=role+" · "+row.symbol+" "+(row.direction==POSITION_TYPE_BUY ? "BUY" : "SELL");
         lines[1]="Ticket "+ticket; lines[2]="Lote "+volume+" · Leverage "+leverage;
         lines[3]="Stop "+amount+" · "+percent+" saldo"+(state=="LAST · NOT ACTIVE" ? " · LAST" : "");
         for(int l=0;l<4;l++)
           {
            const string suffix="POSITION_CELL_"+IntegerToString(j)+"_"+IntegerToString(l);
            if(l==0) JPWRaizCreateLabel(suffix,JPWFitText(lines[l],inner-2*gap,g_details_font),x+gap,y+l*(text_height+gap));
            else JPWCreateProtectedValue(suffix,lines[l],x+gap,y+l*(text_height+gap),inner-2*gap);
            JPWPresentationSetInteger(JPWRaizUI(suffix),OBJPROP_ZORDER,5);
            JPWPresentationSetString(JPWRaizUI(suffix),OBJPROP_TOOLTIP,tooltip);
           }
        }
      g_position_button_row[j]=index; g_position_button_ticket[j]=row.ticket;
      g_position_button_identifier[j]=row.identifier; g_stop_button_count++;
     }
   const string count_text="Posições "+IntegerToString(g_positions_scroll+1)+"–"+
      IntegerToString(MathMin(g_positions_total_rows,g_positions_scroll+layout.visible_rows))+" de "+IntegerToString(g_positions_total_rows)+
      " · mesma aba";
   JPWRaizCreateLabel("STOP_PAGE",count_text,x,footer_y-g_details_line);
  }

void JPWStopsTableMemoryFailure(const int x,const int y)
  {
   g_stop_button_count=0;
   // Prepare the notice before refusing this frame's retained-object inventory.
   JPWRaizCreateLabel("STOP_TOTAL","Stop risk: N/A · memória insuficiente",x,y);
   JPWPresentationFailure("Tabela de stops indisponível: memória insuficiente. Feche e reabra Conta.");
  }

void JPWRenderStopsTable(const int x,const int body_y,const int inner,
                         const int body_height,const int footer_y)
  {
   if(!g_stops_show_pending)
     { JPWRenderPositionsTable(x,body_y,inner,body_height,footer_y); return; }
   g_stop_button_count=0;
   JPWStopRiskSample sample;
   JPWStopRiskRow rows[];
   bool historical=false;
   if(g_stop_ready)
     {
      sample=g_stop_sample;
      if(ArrayResize(rows,ArraySize(g_stop_rows))!=ArraySize(g_stop_rows))
        { JPWStopsTableMemoryFailure(x,body_y); return; }
      for(int i=0;i<ArraySize(rows);i++) rows[i]=g_stop_rows[i];
     }
   else if(g_stop_last_ready)
     {
      historical=true; sample=g_stop_last_sample;
      if(ArrayResize(rows,ArraySize(g_stop_last_rows))!=ArraySize(g_stop_last_rows))
        { JPWStopsTableMemoryFailure(x,body_y); return; }
      for(int i=0;i<ArraySize(rows);i++) rows[i]=g_stop_last_rows[i];
     }
   else
     {
      // The absence of an EA sample is a data state, regardless of font/DPI.
      const string cause=(g_stop_reason=="" ? g_stop_last_reason : g_stop_reason);
      JPWRaizCreateLabel("STOP_EMPTY","Stop risk: N/A · "+cause,x,body_y);
      if(body_height>=2*g_details_line)
         JPWRaizCreateLabel("STOP_HINT",
            "No mesmo MT5: Expert Advisors > JPWealth > JPW_Stoikus_Monitor, em gráfico de apoio.",
            x,body_y+g_details_line);
      if(body_height>=3*g_details_line)
         JPWRaizCreateLabel("STOP_HINT_2",
            "Anexe a um gráfico e confira a aba Experts.",
            x,body_y+2*g_details_line);
      JPWPresentationSetString(JPWRaizUI("STOP_EMPTY"),OBJPROP_TOOLTIP,
                      g_stop_detail+" "+g_stop_last_reason);
      return;
     }
   const string inactive_reason=(historical ?
      (g_stop_reason=="" ? "Monitoramento não confirmado" : g_stop_reason) : "");
   g_stop_table_sample=sample; g_stop_table_historical=historical;
   if(ArrayResize(g_stop_table_rows,ArraySize(rows))!=ArraySize(rows))
     { JPWStopsTableMemoryFailure(x,body_y); return; }
   for(int i=0;i<ArraySize(rows);i++) g_stop_table_rows[i]=rows[i];
   if(sample.row_count==0 && ArraySize(rows)==0 &&
      sample.margin_mode==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING &&
      JPWFinitePositive(sample.balance))
     {
      JPWRaizCreateLabel("STOP_TOTAL","Stop risk: 0,00 "+sample.currency+
         " · 0,00% saldo · zero confirmado sem exposição"+(historical ? " · LAST · NOT ACTIVE" : " · Current"),x,body_y);
      if(body_height>=2*g_details_line)
         JPWRaizCreateLabel("STOP_HINT",
            (historical ? "Inactive: "+inactive_reason :
             "Nenhuma posição ou pendente na geração completa do EA."),
            x,body_y+g_details_line);
      if(historical)
         JPWPresentationSetString(JPWRaizUI("STOP_TOTAL"),OBJPROP_TOOLTIP,
                         "LAST · NOT ACTIVE. Motivo atual: "+inactive_reason);
      return;
     }
   string scope_symbol=(historical ? g_stop_last_scope_symbol : g_stop_scope_symbol);
   string provenance=(historical ? g_stop_last_provenance : g_stop_provenance);
   string reason=(historical ? g_stop_last_scope_reason : g_stop_reason);
   int scope_side=(historical ? g_stop_last_scope_side : g_stop_scope_side);
   const bool scope_ok=(historical ? g_stop_last_scope_valid : g_stop_scope_valid);
   const bool identity_stable=(g_account_known && g_sample_context!="");
   if(!scope_ok || !identity_stable)
     {
      if(!identity_stable) reason="Conta alterada durante a consulta";
      JPWRaizCreateLabel("STOP_EMPTY","Stop risk: N/A · atribuição indisponível",x,body_y);
      if(body_height>=2*g_details_line)
         JPWRaizCreateLabel("STOP_HINT",reason,x,body_y+g_details_line);
      if(identity_stable && g_stop_genesis_closed &&
         body_height>=2*g_details_line+g_details_control)
        {
         const string role="Gênese · "+(provenance=="Selected" ? "selected" :
                            "inferred")+" · closed";
         JPWRaizCreateButton(JPW_ACTION_STOP_ROW_FIRST,JPWFitText(role,inner-12,g_details_font),
                             x,body_y+2*g_details_line,inner);
         JPWPresentationSetString(JPWActionObject(JPW_ACTION_STOP_ROW_FIRST),OBJPROP_TOOLTIP,
                         "Referência encerrada; posições posteriores não foram atribuídas.");
         g_stop_button_row[0]=-2;
         g_stop_button_role[0]=role;
         g_stop_button_count=1;
        }
      return;
     }
   double total=0.0,pct=0.0,positions=0.0,pending=0.0,additional=0.0;
   const bool complete=JPWStopRiskAggregate(sample,rows,scope_symbol,scope_side,
                                             total,pct,positions,pending,additional,reason);
   const bool netting=(sample.margin_mode!=ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   const string data_state=(historical ? "LAST · NOT ACTIVE" :
                            (complete ? "Current" : "N/A"));
   const string total_text=(complete ? JPWStopRiskMoney(total)+" "+sample.currency+
                             " · "+JPWFormatPercent(pct,false)+" saldo" : "N/A");
   const string parts=(complete ? "Open "+JPWStopRiskMoney(positions)+
      " + Pending "+JPWStopRiskMoney(pending)+"; market→SL "+
      (additional>=0.0 ? JPWStopRiskMoney(additional) : "N/A")+" "+sample.currency :
      "Total recusado: "+reason);
   int excluded=0;
   for(int i=0;i<ArraySize(rows);i++)
      if(rows[i].symbol!=scope_symbol || rows[i].side!=scope_side) excluded++;
   const string scope=scope_symbol+" "+(scope_side>0 ? "BUY" : "SELL")+
      " · símbolo + direção inferidos · "+provenance+
      (excluded>0 ? " · "+IntegerToString(excluded)+
      " outro(s) símbolo/direção fora" : "");
   int indexes[];
   for(int i=0;i<ArraySize(rows);i++)
     {
      if(rows[i].symbol!=scope_symbol || rows[i].side!=scope_side ||
         rows[i].kind!=(g_stops_show_pending ? JPW_STOP_RISK_PENDING :
                                           JPW_STOP_RISK_POSITION)) continue;
      const int n=ArraySize(indexes);
      if(ArrayResize(indexes,n+1)!=n+1)
        { JPWStopsTableMemoryFailure(x,body_y); return; }
      int at=n;
      while(at>0 && (rows[indexes[at-1]].opened_msc>rows[i].opened_msc ||
            (rows[indexes[at-1]].opened_msc==rows[i].opened_msc &&
             rows[indexes[at-1]].ticket>rows[i].ticket)))
        { indexes[at]=indexes[at-1]; at--; }
      indexes[at]=i;
     }
   if(!g_stops_show_pending && !g_stop_genesis_closed && !netting)
      for(int i=0;i<ArraySize(indexes);i++)
         if(rows[indexes[i]].identifier==g_stop_genesis_identifier)
           {
            const int genesis=indexes[i];
            for(int j=i;j>0;j--) indexes[j]=indexes[j-1];
            indexes[0]=genesis;
            break;
           }
   const int closed_extra=(!g_stops_show_pending && g_stop_genesis_closed && !netting ? 1 : 0);
   const int count=ArraySize(indexes)+closed_extra;
   bool horizontal_values=(inner>2*g_details_control+g_details_pad);
   const int value_inset=(g_details_pad>4 ? g_details_pad : 4);
   const int value_width=(inner>2*value_inset ? inner-2*value_inset : inner);
   const int column_width=(value_width-g_details_pad)/2;
   if(!TextSetFont("Arial",-10*g_details_font,FW_NORMAL)) horizontal_values=false;
   for(int i=0;i<ArraySize(indexes) && horizontal_values;i++)
     {
      JPWStopRiskRow measured_row=rows[indexes[i]];
      string measured_amount="N/A",measured_percent="N/A saldo";
      if(measured_row.valid==1 && MathIsValidNumber(measured_row.risk_money) &&
         measured_row.risk_money>=0.0 && JPWFinitePositive(sample.balance))
        {
         measured_amount=JPWStopRiskMoney(measured_row.risk_money)+" "+sample.currency;
         measured_percent=JPWFormatPercent(100.0*measured_row.risk_money/
                                           sample.balance,false)+" saldo";
        }
      uint amount_width=0,percent_width=0,text_height=0;
      if(!TextGetSize(measured_amount,amount_width,text_height) ||
         !TextGetSize(measured_percent,percent_width,text_height) ||
         (int)amount_width>column_width || (int)percent_width>column_width)
         horizontal_values=false;
     }
   JPWStopsLayout layout;
   JPWPanelStopsLayout(body_height,g_details_line,g_details_control,
                       g_details_pad,horizontal_values,count>0,layout);
   if(layout.summary_lines>0)
     {
      JPWCreateProtectedValue("STOP_TOTAL","Stop risk: "+total_text+
         " · "+data_state,x,body_y,inner);
      JPWPresentationSetString(JPWRaizUI("STOP_TOTAL"),OBJPROP_TOOLTIP,
         "Stop risk: "+total_text+" · "+data_state+". "+reason);
     }
   if(layout.summary_lines>1)
     {
      JPWCreateProtectedValue("STOP_PARTS",parts,x,body_y+g_details_line,inner);
      JPWPresentationSetString(JPWRaizUI("STOP_PARTS"),OBJPROP_TOOLTIP,parts+
         ". Market→SL é separado e exclui pendentes.");
     }
   if(layout.summary_lines>2)
     {
      const string scope_line=(historical ? "Inactive: "+inactive_reason : scope);
      JPWRaizCreateLabel("STOP_SCOPE",
         JPWFitText(scope_line,inner,g_details_font),x,body_y+2*g_details_line);
      JPWPresentationSetString(JPWRaizUI("STOP_SCOPE"),OBJPROP_TOOLTIP,scope+
         (historical ? ". Motivo atual: "+inactive_reason : "")+
         ". Outra tese no mesmo par e direção pode estar incluída. " +
         "Antiguidade não certifica a tese nem a função de Defesa.");
     }
   const int table_y=body_y+layout.table_offset;
   if(count==0)
     {
      if(table_y+g_details_line<=body_y+body_height)
         JPWRaizCreateLabel("STOP_NO_ROWS",g_stops_show_pending ?
            "Nenhuma pendente atribuída; total só é zero se confirmado." :
            "Nenhuma posição aberta atribuída.",x,table_y);
      return;
     }
   if(layout.rows_per_page<1)
     {
      if(body_height>=g_details_control)
         JPWRaizCreateButton(JPW_ACTION_CARD_FIRST+5,"Stop risk · detalhe",
                             x,body_y,inner);
      return;
     }
   const int rows_per_page=layout.rows_per_page;
   const int row_height=layout.row_height;
   const int pages=JPWPanelPageCount(count,rows_per_page);
   g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
   for(int j=0;j<rows_per_page && g_cockpit_page*rows_per_page+j<count;j++)
     {
      const int ordinal=g_cockpit_page*rows_per_page+j;
      const int row_index=(ordinal<closed_extra ? -2 : indexes[ordinal-closed_extra]);
      string role="",amount="N/A",percent="N/A";
      if(row_index==-2)
        role="Gênese · "+(provenance=="Selected" ? "selected" : "inferred")+" · closed";
      else
        {
         JPWStopRiskRow row=rows[row_index];
         role=(g_stops_show_pending ? "Pending "+IntegerToString(ordinal+1) :
              (netting ? "Net position · aggregate" :
              (row.identifier==g_stop_genesis_identifier ?
               "Gênese · "+(provenance=="Selected" ? "selected" : "inferred") :
               "Defesa "+IntegerToString(ordinal)+" · inferred")));
         if(row.valid==1 && MathIsValidNumber(row.risk_money) &&
            row.risk_money>=0.0 && JPWFinitePositive(sample.balance))
           { amount=JPWStopRiskMoney(row.risk_money)+" "+sample.currency;
             percent=JPWFormatPercent(100.0*row.risk_money/sample.balance,false); }
        }
      const string caption=role+" · "+amount+" · "+percent;
      JPWRaizCreateButton(JPW_ACTION_STOP_ROW_FIRST+j,role,
                          x,table_y+j*row_height,inner);
      if(layout.value_lines>0)
        {
         const string row_surface="STOP_ROW_BG_"+IntegerToString(j);
         JPWRaizCreateSurface(row_surface,x,table_y+j*row_height+g_details_control,
                              inner,layout.value_lines*g_details_line,g_details_card);
         // Decorative row backgrounds must not steal the detail button's click.
         JPWPresentationSetInteger(JPWRaizUI(row_surface),OBJPROP_ZORDER,1);
        }
      if(layout.value_lines==1)
        {
         JPWCreateProtectedValue("STOP_AMOUNT_"+IntegerToString(j),amount,
            x+value_inset,table_y+j*row_height+g_details_control,column_width);
         JPWCreateProtectedValue("STOP_PERCENT_"+IntegerToString(j),percent+" saldo",
            x+value_inset+column_width+g_details_pad,
            table_y+j*row_height+g_details_control,column_width);
        }
      else if(layout.value_lines==2)
        {
         JPWCreateProtectedValue("STOP_AMOUNT_"+IntegerToString(j),amount,
            x+value_inset,table_y+j*row_height+g_details_control,value_width);
         JPWCreateProtectedValue("STOP_PERCENT_"+IntegerToString(j),percent+" saldo",
            x+value_inset,table_y+j*row_height+g_details_control+g_details_line,value_width);
        }
      JPWPresentationSetString(JPWRaizUI("BUTTON_"+IntegerToString(JPW_ACTION_STOP_ROW_FIRST+j)),
                      OBJPROP_TOOLTIP,caption+". Clique para origem, volume, entrada e SL.");
      g_stop_button_row[j]=row_index;
      g_stop_button_role[j]=role;
      g_stop_button_count++;
     }
   const string page_text=(g_stops_show_pending ? "Pendentes" : "Posições")+
                       " · "+IntegerToString(g_cockpit_page+1)+"/"+
                       IntegerToString(pages)+
                       (historical ? " · LAST · "+inactive_reason : "");
   JPWRaizCreateLabel("STOP_PAGE",JPWFitText(page_text,inner,g_details_font),
                      x,footer_y-g_details_line);
   if(historical)
      JPWPresentationSetString(JPWRaizUI("STOP_PAGE"),OBJPROP_TOOLTIP,
                      "Última amostra, não ativa. Motivo atual: "+inactive_reason);
  }

string JPWPersonalSectionName()
  { return(JPWPersonalCategoryLabel(g_personal_category)); }
string JPWPersonalRowCaption(JPWPersonalRow &row)
  {
   string caption="#"+IntegerToString(row.sequence)+" · "+TimeToString((datetime)row.wall,TIME_DATE|TIME_SECONDS)+" UTC";
   JPWPersonalEpisode episode; JPWPersonalPeak peak;
   if(row.category=="EPISODE" && JPWPersonalDecodeEpisode(row.payload,episode))
      caption+=" · "+episode.subject.symbol+" · "+(episode.subject.kind==JPW_PERSONAL_POSITION ? "posição " : "pendente ")+episode.subject.ticket+
         " · "+(episode.state==JPW_PERSONAL_ACTIVE ? "sem SL" : episode.resolution);
   else if(row.category=="PEAK" && JPWPersonalDecodePeak(row.payload,peak))
      caption+=" · "+(peak.quality==1 ? "Current " : "Estimated ")+DoubleToString(peak.leverage,8)+"x";
   else { int cut=StringFind(row.payload,"|"); caption+=" · "+(cut>=0 ? StringSubstr(row.payload,0,cut) : row.category); }
   return(caption);
  }
void JPWPersonalDetailLines(const int width,string &lines[])
  {
   if(!JPWPersonalUIReady() || g_personal_detail_seq<=0 || g_personal_detail.sequence!=g_personal_detail_seq)
     { JPWDetailsWrap("Detalhe em carregamento ou indisponível; nenhum registro anterior foi apresentado.",width,lines); return; }
   JPWPersonalRow row=g_personal_detail;
   JPWDetailsWrap(JPWPersonalRowCaption(row),width,lines);
   JPWDetailsWrap("Conta registrada: "+g_personal_scope+" · sequência "+IntegerToString(row.sequence)+" · SHA-256 "+row.digest,width,lines);
   JPWPersonalEpisode episode; JPWPersonalPeak peak;
   if(row.category=="EPISODE" && JPWPersonalDecodeEpisode(row.payload,episode))
     {
      JPWDetailsWrap("Identidade "+episode.subject.id+" · ticket observado "+episode.subject.ticket+" · "+
         (episode.subject.side==1 ? "Compra" : "Venda")+" · volume "+JPWPersonalNum(episode.subject.volume)+
         " · SL "+(episode.subject.sl_readable ? JPWPersonalNum(episode.subject.sl) : "indisponível")+" · TP "+JPWPersonalNum(episode.subject.tp),width,lines);
      JPWDetailsWrap("Primeira observação: "+TimeToString((datetime)episode.first_wall,TIME_DATE|TIME_SECONDS)+" UTC · última: "+
         TimeToString((datetime)episode.last_wall,TIME_DATE|TIME_SECONDS)+" UTC · solicitações: "+IntegerToString(episode.requested_count),width,lines);
      JPWDetailsWrap("Último aviso solicitado: "+(episode.last_requested_wall>0 ?
         TimeToString((datetime)episode.last_requested_wall,TIME_DATE|TIME_SECONDS)+" UTC" : "nenhum registrado")+
         " · próximo prazo: "+(episode.next_wall>0 ? TimeToString((datetime)episode.next_wall,TIME_DATE|TIME_SECONDS)+" UTC" : "indisponível")+
         " · vínculo demonstrado: "+(episode.subject.link_id=="" ? "indisponível" : episode.subject.link_id),width,lines);
      JPWDetailsWrap("Resolução: "+(episode.resolution=="" ? "episódio ativo" : episode.resolution)+". Sem SL registrado na corretora não certifica infração nem avalia stop virtual.",width,lines);
     }
   else if(row.category=="PEAK" && JPWPersonalDecodePeak(row.payload,peak))
     {
      JPWDetailsWrap("Fotografia íntegra do recorde observado · "+(peak.quality==1 ? "Current" : "Estimated")+
         " · início/fim da captura "+IntegerToString(peak.started_msc)+" / "+IntegerToString(peak.finished_msc)+" ms",width,lines);
      JPWDetailsWrap(peak.snapshot,width,lines);
     }
   else
     {
      const int split=StringFind(row.payload,"|"); string decoded="";
      if(split>=0 && JPWPersonalUnhex(StringSubstr(row.payload,split+1),decoded))
         JPWDetailsWrap(StringSubstr(row.payload,0,split)+" · "+decoded,width,lines);
      else JPWDetailsWrap(row.payload,width,lines);
      JPWDetailsWrap("Uma chamada de Alert/PlaySound não comprova que o operador viu ou ouviu o aviso. Estágios ausentes têm entrega incerta.",width,lines);
     }
  }
void JPWPersonalRenderBody(const int x,const int body_y,const int inner,const int body_height,const int footer_y)
  {
   g_personal_button_count=0;
   const int half=(inner-g_details_pad)/2;
   if(body_height<2*g_details_control+g_details_line)
     { JPWRaizCreateLabel("PH_SMALL","Amplie o gráfico para consultar o histórico",x,body_y); return; }
   JPWRaizCreateButton(JPW_ACTION_HISTORY_ACCOUNT,(g_personal_account_index>=0 ?
      "Escolher conta ("+IntegerToString(ArraySize(g_personal_accounts))+")" :
      "Escolher conta"),x,body_y,half);
   JPWRaizCreateButton(JPW_ACTION_HISTORY_REFRESH,"Atualizar consulta",x+half+g_details_pad,body_y,half);
   if(g_personal_picker!=0)
     {
      g_personal_choice_count=0;
      const int total=(g_personal_picker==1 ? ArraySize(g_personal_accounts) : 7);
      const int capacity=MathMin(8,MathMax(1,(body_height-g_details_control-g_details_pad)/(g_details_control+g_details_pad)));
      const int pages=JPWPanelPageCount(total,capacity);
      g_personal_picker_page=JPWPanelClamp(g_personal_picker_page,0,pages-1);
      for(int j=0;j<capacity && g_personal_picker_page*capacity+j<total;j++)
        {
         const int index=g_personal_picker_page*capacity+j;
         g_personal_choice_index[j]=index; g_personal_choice_count++;
         const string key=(g_personal_picker==1 ? g_personal_accounts[index] : JPWPersonalCategoryKey(index));
         const string label=(g_personal_picker==1 ?
            "#"+IntegerToString(index+1)+" "+(key==g_personal_operating_key ? "Atual · " : "Histórica · ")+key : JPWPersonalCategoryLabel(key));
         JPWRaizCreateButton(JPW_ACTION_HISTORY_CHOICE_FIRST+j,label,x,
            body_y+(j+1)*(g_details_control+g_details_pad),inner);
        }
      if(total==0) JPWRaizCreateLabel("PH_EMPTY","Catálogo local vazio · atualize a consulta",x,body_y+g_details_control+g_details_pad);
      JPWRaizCreateLabel("PAGE","Escolha explícita · "+IntegerToString(g_personal_picker_page+1)+"/"+IntegerToString(pages),x,footer_y-g_details_line);
      return;
     }
   int y=body_y+g_details_control+g_details_pad;
   const int room=body_height-g_details_control-g_details_pad-g_details_line;
   string lines[];
   const string title=(g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL ? "Detalhe do registro #"+IntegerToString(g_personal_detail_seq) :
      (g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT ? "Exportar histórico" : JPWPersonalSectionName()));
   JPWRaizCreateLabel("PH_TITLE",title,x,y); y+=g_details_line;
   JPWDetailsWrap(JPWPersonalScopeLabel()+" · "+(g_personal_scope=="" ? "identidade indisponível" : StringSubstr(g_personal_scope,0,12)+"…"),inner,lines);
   if(g_personal_scope==g_personal_operating_key && g_personal_operating_key!="")
      JPWDetailsWrap("Monitoramento agora: "+g_personal_live_notice,inner,lines);
   if(!JPWPersonalUIReady())
     {
      JPWDetailsWrap((JPWPersonalUIReadState()+" · ")+g_personal_reason,inner,lines);
      JPWDetailsWrap((g_personal_read_requested || g_personal_job_active) ? "A conta e a seleção foram preservadas; as ações sobre registros aguardam a leitura." :
         "Use Atualizar consulta para tentar novamente. Ausência de dados não significa zero.",inner,lines);
     }
   else if(g_personal_read_wall>0)
      JPWDetailsWrap("Consulta concluída: "+TimeToString((datetime)g_personal_read_wall,TIME_DATE|TIME_SECONDS)+" UTC · registro local",inner,lines);
   else JPWDetailsWrap("Horário da consulta indisponível",inner,lines);
   if(!JPWPersonalUIReady()) { /* Keep the loading/error message, no prior content. */ }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT)
     {
      JPWDetailsWrap("Exportação da conta selecionada, sem trocar a conta ativa. CSV para consulta; JSON versionado para backup integral, com sequência e integridade.",inner,lines);
      JPWDetailsWrap("Destino local: MQL5/Files/JPWealth/Genetrix/PersonalHistory. O arquivo contém dados financeiros; guarde uma cópia fora do terminal. Nenhuma restauração automática será feita.",inner,lines);
      JPWDetailsWrap(g_personal_export_result,inner,lines);
     }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL && g_personal_detail_seq>0) JPWPersonalDetailLines(inner,lines);
   else if(g_personal_category=="SUMMARY")
     {
      JPWDetailsWrap("Maior alavancagem observada desde "+(g_personal_summary.started_wall>0 ?
         TimeToString((datetime)g_personal_summary.started_wall,TIME_DATE|TIME_SECONDS)+" UTC" : "início indisponível"),inner,lines);
      JPWDetailsWrap("Máximo observado · Atual",inner,lines);
      JPWDetailsWrap(JPWPersonalPeakLabel(g_personal_summary.current),inner,lines);
      JPWDetailsWrap("Estimado · registro separado",inner,lines);
      JPWDetailsWrap(JPWPersonalPeakLabel(g_personal_summary.estimated),inner,lines);
      JPWDetailsWrap("Nocional bruto aberto / equity. Pendentes ficam na fotografia e não entram na alavancagem utilizada.",inner,lines);
      JPWDetailsWrap("Ocorrências: "+IntegerToString(g_personal_summary.active_episodes)+" episódios ativos / "+
         IntegerToString(g_personal_summary.total_episodes)+" episódios registrados · interrupções conhecidas: "+
         IntegerToString(g_personal_summary.gaps)+" · sequência: "+IntegerToString(g_personal_summary.sequence),inner,lines);
      JPWDetailsWrap("Cobertura começa na ativação deste componente; não reconstrói períodos antigos e pode perder picos entre observações. Registro não prova fase, conformidade ou estado psicológico.",inner,lines);
     }
   else
     {
      JPWDetailsWrap("Mais recentes primeiro · selecione uma linha para consultar sua evidência.",inner,lines);
      if(ArraySize(g_personal_rows)==0) JPWDetailsWrap("Consulta concluída · nenhum registro nesta seção/página.",inner,lines);
     }
   const bool list=(JPWPersonalUIReady() && g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY &&
      g_personal_category!="SUMMARY" && ArraySize(g_personal_rows)>0);
   int rows=MathMax(1,room/g_details_line);
   if(list)
     {
      const int heading=MathMin(ArraySize(lines),MathMax(1,rows/2));
      for(int i=0;i<heading;i++) JPWRaizCreateLabel("PH_HEAD_"+IntegerToString(i),lines[i],x,y+i*g_details_line);
      y+=heading*g_details_line+g_details_pad;
      const int capacity=MathMax(0,(body_y+body_height-y)/(g_details_control+g_details_pad));
      for(int i=0;i<capacity && i<ArraySize(g_personal_rows) && i<8;i++)
        {
         g_personal_button_seq[i]=g_personal_rows[i].sequence; g_personal_button_count++;
         JPWRaizCreateButton(JPW_ACTION_HISTORY_ROW_FIRST+i,JPWPersonalRowCaption(g_personal_rows[i]),x,
            y+i*(g_details_control+g_details_pad),inner);
        }
      // The next cursor must follow the LAST VISIBLE row, never skip hidden records.
      JPWRaizCreateLabel("PAGE",JPWPersonalSectionName()+" · página "+IntegerToString(g_personal_cursor_page+1),x,footer_y-g_details_line);
     }
   else
     {
      const int pages=JPWPanelPageCount(ArraySize(lines),rows);
      g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
      for(int i=0;i<rows && i<60 && g_cockpit_page*rows+i<ArraySize(lines);i++)
         JPWRaizCreateLabel("PH_TEXT_"+IntegerToString(i),lines[g_cockpit_page*rows+i],x,y+i*g_details_line);
      JPWRaizCreateLabel("PAGE",(!JPWPersonalUIReady() ? JPWPersonalUIReadState()+" · " : "")+
         "Página "+IntegerToString(g_cockpit_page+1)+"/"+IntegerToString(pages),x,footer_y-g_details_line);
     }
  }

void JPWMonitorAppendModule(const string label,JPWMonitorModuleStatus &module,
                            const bool present,const ulong now_ms,const int inner,
                            string &lines[],const bool accounting=false,const bool technical=false)
  {
   JPWDetailsWrap(label+": "+JPWMonitorUIStage(module,present,now_ms),inner,lines);
   JPWDetailsWrap("Motivo: "+(module.reason=="" ? "não informado" : module.reason),inner,lines);
   JPWDetailsWrap("Ação: "+JPWMonitorUIGuidance(module,present,accounting),inner,lines);
   if(module.state==JPW_MONITOR_PREPARING)
      JPWDetailsWrap("Preparação desta tentativa: "+IntegerToString(module.progress)+"% · não é cobertura histórica.",inner,lines);
   if(technical) JPWDetailsWrap("Detalhe da origem: qualidade literal "+module.quality+" · última captura "+
      JPWMonitorUITime(module.observed_utc,module.observed_mono_ms,now_ms)+". Presença, qualidade e cobertura são evidências distintas.",inner,lines);
  }

void JPWMonitorAppendComponents(const int inner,string &lines[],const bool technical=false)
  {
   // All producer diagnostics were accepted by Coordinator, never read on paint.
   // Presence is independent of every financial metric and of historical coverage.
   JPWDetailsWrap("Componentes da conta",inner,lines);
   JPWDetailsWrap("Stoikus · Núcleo da conta reúne monitoramento e contabilidade; observa a conta inteira desta instalação, a partir de um gráfico de apoio dedicado.",inner,lines);
   if(!g_monitor_ui_available || g_monitor_ui_context=="" || g_monitor_ui_context!=g_diagnostic_context)
     {
      JPWDetailsWrap("Núcleo ausente ou indisponível · "+g_monitor_ui_reason,inner,lines);
      JPWDetailsWrap("Confira JPW_Stoikus_Monitor no gráfico de apoio e a aba Experts. Um diagnóstico ausente não prova que todos os produtores estejam desligados; confira também as métricas e instâncias legadas.",inner,lines);
     }
   else
     {
      JPWMonitorSnapshot status=g_monitor_ui;
      const ulong now_ms=GetTickCount64();
      const bool present=status.live && status.active && status.heartbeat_mono_ms>0 &&
         now_ms>=(ulong)status.heartbeat_mono_ms &&
         now_ms-(ulong)status.heartbeat_mono_ms<=JPW_MONITOR_STATUS_MAX_AGE_MS;
      JPWDetailsWrap("Presença: "+(present ? "sinal recente com lease compatível" : "atual não confirmada; registro anterior")+
         " na última consulta. Heartbeat: "+JPWMonitorUITime(status.heartbeat_utc,status.heartbeat_mono_ms,now_ms)+
         ". Heartbeat não renova capturas nem prova atividade contínua.",inner,lines);
      if(status.product_version!=JPW_PRODUCT_VERSION)
         JPWDetailsWrap("Versão do produtor diferente da interface. Confira manifesto e compatibilidade; não misture arquivos para forçar funcionamento.",inner,lines);
      if(status.role=="Legacy Observer")
         JPWDetailsWrap("Produtor legado identificado. Não o mantenha ativo junto ao novo Monitor; faça a troca preservando os registros.",inner,lines);
      JPWMonitorAppendModule("Monitoramento · risco dos stops",status.stop_risk,present,now_ms,inner,lines,false,technical);
      JPWMonitorAppendModule("Monitoramento · Histórico Pessoal e avisos",status.personal,present,now_ms,inner,lines,false,technical);
      JPWMonitorAppendModule("Contabilidade · ciclos e compensado",status.ledger,present,now_ms,inner,lines,true,technical);
      JPWMonitorAppendModule("Monitoramento · snapshots Raiz N de execução",status.raiz,present,now_ms,inner,lines,false,technical);
      if(technical)
        {
      JPWDetailsWrap("Função declarada: "+status.role+" · produto "+status.product_version+
         " · build "+status.build_id,inner,lines);
      JPWDetailsWrap("Gráfico produtor: "+IntegerToString(status.chart_id)+" · owner "+
         StringSubstr(status.publisher_token,0,12)+"… · contexto "+StringSubstr(status.account_key,0,12)+"…",inner,lines);
      JPWDetailsWrap("Ciclo técnico: "+IntegerToString(status.last_cycle_ms)+" ms; ultrapassagens registradas "+
         IntegerToString(status.overruns)+". Timer solicitado não garante despacho pontual.",inner,lines);
        }
     }
   JPWDetailsWrap("Instalação padrão: um JPW_Stoikus_Monitor no gráfico de apoio; retire Observer e Accountant legados normalmente. Não precisa habilitar negociação. Fechar o Cockpit mantém o EA; fechar ou substituir o gráfico do EA interrompe o acompanhamento.",inner,lines);
   JPWDetailsWrap("Supervisor 7x é separado e opcional; não é requisito das sete métricas. Estado salvo não comprova executor ativo ou armamento atual. A interface não o instala, arma ou negocia.",inner,lines);
  }


void JPWCockpitFooterContract(int &actions[],string &labels[])
  {
   actions[0]=JPW_ACTION_PRIMARY; actions[1]=JPW_ACTION_SECONDARY; actions[2]=JPW_ACTION_CLOSE;
   labels[0]="Posições e stops"; labels[1]="Preparar mensagem"; labels[2]="Fechar";
   if(g_raiz_tab==JPW_SIGNAL_ROUTE)
     { labels[0]="Conferir e gerar prévia"; labels[1]="Salvar texto local"; }
   else if(g_raiz_tab==JPW_ROUTE_SETTINGS)
     { actions[0]=JPW_ACTION_APPLY; actions[1]=JPW_ACTION_CANCEL; actions[2]=JPW_ACTION_RESET;
       labels[0]="Aplicar"; labels[1]="Cancelar"; labels[2]="Restaurar"; }
   else if(g_raiz_tab==JPW_ROUTE_METRIC)
     { labels[0]="Visão geral"; labels[1]=(g_cockpit_selected==6 ? "Selecionar ciclo" : "Proveniência"); }
   else if(g_raiz_tab==JPW_ROUTE_LEDGER_CYCLES) { labels[0]="Compensado"; labels[1]="Visão geral"; }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY) { labels[0]=(g_personal_picker!=0 ? "Cancelar seleção" : "Escolher seção"); labels[1]="Exportar…"; }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL) { labels[0]="Voltar"; labels[1]="Atualizar"; }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT) { labels[0]="Salvar CSV"; labels[1]="Backup JSON"; }
   else if(g_raiz_tab==JPW_ROUTE_PROVENANCE) { labels[0]="Sistema"; labels[1]="Atualizar"; }
   else if(g_raiz_tab==JPW_ROUTE_STOP_ROW) { labels[0]="Preparar mensagem"; labels[1]="Pendentes"; }
   else if(g_raiz_tab==JPW_ROUTE_STOPS)
     { labels[0]=(g_stops_show_pending ? "Posições" : (g_positions_operation_only ? "Ver Conta" : "Ver grupo")); labels[1]="Pendentes"; }
   else if(g_raiz_tab==JPW_ROUTE_RAIZN) { labels[0]="F 1,5/1,8"; labels[1]="Avançado"; }
   else if(g_raiz_tab==JPW_ROUTE_SYSTEM) { labels[0]="Ver detalhes"; labels[1]="Exportar…"; }
   else if(g_raiz_tab==JPW_ROUTE_EXPORT) { labels[0]="Voltar"; labels[1]="Salvar exportação"; }
   if(g_personal_picker!=0 && (g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY || g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL || g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT))
     { labels[0]="Cancelar seleção"; labels[1]="Escolha uma opção"; }
  }
int JPWDialogFooterMinimum(string &labels[],const int count)
  {
   int minimum=0;
   for(int i=0;i<count;i++) minimum=MathMax(minimum,JPWUIDesignButtonWidth(labels[i],g_details_font));
   return(minimum);
  }
void JPWDialogFooterButtons(int &actions[],string &labels[],const int count,
                           const int x,const int footer,const int width)
  {
   const int columns=JPWUIDesignNavColumns(labels,count,width,g_details_font,g_details_pad);
   const int cell=(width-(columns-1)*g_details_pad)/columns;
   for(int i=0;i<count;i++)
      JPWRaizCreateButton(actions[i],labels[i],x+(i%columns)*(cell+g_details_pad),
                          footer+(i/columns)*(g_details_control+g_details_pad),cell);
  }

void JPWDialogPager(const int x,const int y,const int inner,const int previous,const int next)
  {
   const string page=JPWRaizUI("PAGE");
   const int arrow=JPWUIDesignPx(36),gap=JPWUIDesignPx(8);
   const int budget=MathMax(1,inner-2*arrow-2*gap);
   const string text=(ObjectFind(0,page)>=0 ? JPWFitText(ObjectGetString(0,page,OBJPROP_TEXT),budget,g_details_font) : "Página");
   const int label=MathMin(budget,JPWUIDesignTextWidth(text,g_details_font));
   const int start=x+MathMax(0,(inner-2*arrow-2*gap-label)/2);
   JPWRaizCreateButton(previous,"‹",start,y,arrow);
   JPWRaizCreateLabel("PAGE",text,start+arrow+gap,y+MathMax(0,(g_details_control-g_details_line+g_details_pad)/2));
   JPWRaizCreateButton(next,"›",start+arrow+2*gap+label,y,arrow);
   string notices[2]={"FEEDBACK","PH_NOTICE"};
   for(int i=0;i<2;i++)
      if(ObjectFind(0,JPWRaizUI(notices[i]))>=0)
         JPWPresentationSetInteger(JPWRaizUI(notices[i]),OBJPROP_YDISTANCE,y-g_details_line-g_details_pad);
  }

void JPWRenderCockpit()
  {
   g_stop_button_count=0;
   const int chart_width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   const int chart_height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
   g_details_font=InpCockpitFontSize;
   uint text_width=0,text_height=0;
   if(!TextSetFont("Arial",-10*g_details_font,FW_NORMAL) ||
      !TextGetSize("Mg",text_width,text_height) || text_height==0 ||
      !JPWPanelAccount(chart_width,chart_height,JPWUIDesignScale(),g_details_rect))
     { JPWPresentationFailure("Interface indisponível; medida de fonte ou área gráfica não confirmada."); return; }
   if(g_account_window_gesture.active) g_details_rect=g_account_window_rect;
   else if(g_stoikus_visual.account_positioned)
     {
      g_details_rect.x=(int)MathRound(g_stoikus_visual.account_x*JPWUIDesignScale());
      g_details_rect.y=(int)MathRound(g_stoikus_visual.account_y*JPWUIDesignScale());
      g_details_rect.width=JPWUIDesignPx(g_stoikus_visual.account_width);
      g_details_rect.height=JPWUIDesignPx(g_stoikus_visual.account_height);
     }
   JPWStoikusWindowBounds(g_details_rect,chart_width,chart_height);
   g_details_pad=((int)text_height/2>JPWUIDesignPx(8) ? (int)text_height/2 : JPWUIDesignPx(8));
   g_details_line=(int)text_height+g_details_pad;
   g_details_control=JPWUIDesignControlHeight((int)text_height);
   const int header_height=(g_details_control>g_details_line ? g_details_control : g_details_line);
   const color chart_background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
   g_details_text=JPWPanelInk(chart_background);
   g_details_surface=JPWPanelWindowSurface(chart_background);
   g_details_chrome=JPWPanelChromeSurface(chart_background);
   g_details_card=JPWPanelCardSurface(chart_background);
   g_details_border=JPWPanelBorderColor(chart_background);
   const int left=g_details_rect.x,top=g_details_rect.y;
   const int x=left+g_details_pad,inner=g_details_rect.width-2*g_details_pad;
   const string bg=JPWRaizUI("BG");
   if(!JPWPresentationEnsure(bg,OBJ_RECTANGLE_LABEL)) return;
   JPWPresentationSetInteger(bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   JPWPresentationSetInteger(bg,OBJPROP_XDISTANCE,left);
   JPWPresentationSetInteger(bg,OBJPROP_YDISTANCE,top);
   JPWPresentationSetInteger(bg,OBJPROP_XSIZE,g_details_rect.width);
   JPWPresentationSetInteger(bg,OBJPROP_YSIZE,g_details_rect.height);
   JPWPresentationSetInteger(bg,OBJPROP_BGCOLOR,g_details_surface);
   JPWPresentationSetInteger(bg,OBJPROP_COLOR,g_details_border);
   JPWPresentationSetInteger(bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   JPWPresentationSetInteger(bg,OBJPROP_BACK,false);
   JPWPresentationSetInteger(bg,OBJPROP_ZORDER,1);
   JPWPresentationSetInteger(bg,OBJPROP_SELECTABLE,false);
   JPWPresentationSetInteger(bg,OBJPROP_HIDDEN,true);
   const int min_structure=2*g_details_control+header_height+4*g_details_pad;
   if(g_details_rect.height<min_structure || inner<JPWUIDesignPx(110))
     {
      const int room=g_details_rect.height-2*g_details_pad;
      const int close_height=(room<g_details_control ? room : g_details_control);
      if(room>g_details_control+g_details_line)
         JPWRaizCreateLabel("TITLE","Conta · amplie o gráfico",x,top+g_details_pad);
      const int close_width=(inner<g_details_control ? inner : g_details_control);
      if(close_height>0 && close_width>0)
        {
         JPWRaizCreateButton(JPW_ACTION_CLOSE,"×",x,
            top+g_details_rect.height-g_details_pad-close_height,close_width);
         JPWPresentationSetInteger(JPWActionObject(JPW_ACTION_CLOSE),OBJPROP_YSIZE,close_height);
         JPWPresentationSetString(JPWActionObject(JPW_ACTION_CLOSE),OBJPROP_TOOLTIP,"Fechar · amplie o gráfico para visualizar o conteúdo.");
        }
      g_raiz_panel_built=true;
      return;
     }
   // Stable visual regions separate orientation, content and actions. They are
   // presentation objects only; all metric values still come from the snapshot.
   JPWRaizCreateSurface("HEADER",left+1,top+1,g_details_rect.width-2,
                         header_height+2*g_details_pad-2,g_details_chrome);
   const string section=((g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY || g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL || g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT) ? "Histórico Pessoal" :
      (g_raiz_tab==JPW_SIGNAL_ROUTE ? "Preparar mensagem" :
      (g_raiz_tab==JPW_ROUTE_OVERVIEW ? "Visão geral" :
      (g_raiz_tab==JPW_ROUTE_METRIC ? g_cockpit_snapshot.metric[g_cockpit_selected].title :
      (g_raiz_tab==JPW_ROUTE_LEDGER_CYCLES ? "Ciclos contábeis" :
      (g_raiz_tab==JPW_ROUTE_PROVENANCE ? "Estado dos dados" :
      (g_raiz_tab==JPW_ROUTE_SETTINGS ? "Ajustes" :
      (g_raiz_tab==JPW_ROUTE_STOPS || g_raiz_tab==JPW_ROUTE_STOP_ROW ? "Posições e stops" :
      (g_raiz_tab==JPW_ROUTE_RAIZN ? "Raiz N" : "Sistema")))))))));
   JPWPresentationKeep(JPWRaizUI("BRAND_LOGO")); JPWPresentationKeep(JPWRaizUI("TITLE"));
   JPWGenetrixHeader(JPWRaizUI("BRAND_LOGO"),JPWRaizUI("TITLE"),
      x,top+g_details_pad,inner-2*g_details_control-2*g_details_pad,header_height,
      g_details_font+2,g_details_text,JPWPanelDarkBackground(chart_background),"Conta · "+section+" · "+_Symbol,4);
   const int nav_y=top+2*g_details_pad+header_height;
   string tabs[6]={"Visão geral","Posições e stops","Raiz N","Sistema","Ajustes","Histórico Pessoal"};
   const int tab_actions[6]={JPW_ACTION_TAB_FIRST,JPW_ACTION_TAB_STOPS,JPW_ACTION_TAB_RAIZN,
      JPW_ACTION_TAB_SYSTEM,JPW_ACTION_TAB_SETTINGS,JPW_ACTION_TAB_HISTORY};
   const int measured_columns=JPWUIDesignNavColumns(tabs,6,inner,g_details_font,g_details_pad);
   const bool compact_nav=(measured_columns==1);
   if(!compact_nav) g_cockpit_sections_open=false; // Resize must not leave a hidden menu consuming body events.
   const int nav_columns=measured_columns;
   const int nav_rows=(compact_nav ? 1 : (6+nav_columns-1)/nav_columns);
   const int nav_width=(inner-(nav_columns-1)*g_details_pad)/nav_columns;
   const int close_size=g_details_control;
   // Header actions occupy their own row before any navigation is drawn.
   JPWRaizCreateButton(JPW_ACTION_HEADER_CLOSE,"×",left+g_details_rect.width-g_details_pad-close_size,
                       top+g_details_pad,close_size);
   JPWPresentationSetString(JPWActionObject(JPW_ACTION_HEADER_CLOSE),OBJPROP_TOOLTIP,
      "Fechar cockpit · Esc. Não interrompe o núcleo Monitor quando ativo.");
   JPWRaizCreateButton(JPW_ACTION_MINIMIZE,"−",left+g_details_rect.width-2*g_details_pad-2*close_size,
                       top+g_details_pad,close_size);
   JPWPresentationSetString(JPWActionObject(JPW_ACTION_MINIMIZE),OBJPROP_TOOLTIP,"Minimizar · preserva rascunho e consulta em andamento");
   const int nav_end=nav_y+nav_rows*(g_details_control+g_details_pad);
   if((!compact_nav && JPWDialogFooterMinimum(tabs,6)>inner) ||
      nav_end+g_details_control+2*g_details_pad>top+g_details_rect.height)
     {
      const int exit_y=top+g_details_rect.height-g_details_pad-g_details_control;
      if(nav_y+g_details_line+g_details_pad<exit_y)
         JPWRaizCreateLabel("FEEDBACK","Amplie o gráfico para ver as seis seções",x,nav_y);
      JPWRaizCreateButton(JPW_ACTION_CLOSE,"Fechar",x,exit_y,inner);
      g_raiz_panel_built=true; JPWFocusPaint();
      return;
     }
   if(compact_nav) JPWRaizCreateButton(JPW_ACTION_SECTIONS,(g_cockpit_sections_open ? "Cancelar seleção de seção" : "Seção: "+section+" · escolher"),x,nav_y,inner);
   for(int i=0;i<6 && !compact_nav;i++)
     {
      const int col=i%nav_columns,row=i/nav_columns;
      const int width=nav_width,nav_x=x+col*(nav_width+g_details_pad);
      JPWRaizCreateButton(tab_actions[i],tabs[i],
                          nav_x,nav_y+row*(g_details_control+g_details_pad),width);
      const bool active=(i==0 ? (g_raiz_tab==JPW_ROUTE_OVERVIEW || g_raiz_tab==JPW_ROUTE_METRIC) :
         (i==1 ? (g_raiz_tab==JPW_ROUTE_STOPS || g_raiz_tab==JPW_ROUTE_STOP_ROW) :
         (i==2 ? g_raiz_tab==JPW_ROUTE_RAIZN :
         (i==3 ? (g_raiz_tab==JPW_ROUTE_SYSTEM || g_raiz_tab==JPW_ROUTE_PROVENANCE ||
                   g_raiz_tab==JPW_ROUTE_EXPORT) :
         (i==4 ? g_raiz_tab==JPW_ROUTE_SETTINGS :
         (g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY || g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL ||
          g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT))))));
      if(active)
        {
         const string tab_button=JPWActionObject(tab_actions[i]);
         JPWPresentationSetInteger(tab_button,OBJPROP_BGCOLOR,JPWPanelSelectedSurface(chart_background));
         JPWPresentationSetInteger(tab_button,OBJPROP_COLOR,JPWPanelAccentColor(chart_background));
         const int tab_y=nav_y+row*(g_details_control+g_details_pad);
         const int marker_height=(g_details_pad/2>2 ? g_details_pad/2 : 2);
         JPWRaizCreateSurface("NAV_ACTIVE",nav_x,tab_y+g_details_control-marker_height,
                              width,marker_height,JPWPanelAccentColor(chart_background));
         JPWPresentationSetInteger(JPWRaizUI("NAV_ACTIVE"),OBJPROP_COLOR,JPWPanelAccentColor(chart_background));
         JPWPresentationSetInteger(JPWRaizUI("NAV_ACTIVE"),OBJPROP_ZORDER,1);
        }
     }
   if(!compact_nav) JPWPresentationSetString(JPWActionObject(JPW_ACTION_TAB_FIRST),OBJPROP_TOOLTIP,
                   "Teclas 1–7: cartões; setas: páginas; Esc: fechar.");
   const int body_y=nav_y+nav_rows*(g_details_control+g_details_pad);
   int footer_actions[3]; string footer_labels[3]; JPWCockpitFooterContract(footer_actions,footer_labels);
   const int footer_columns=JPWUIDesignNavColumns(footer_labels,3,inner,g_details_font,g_details_pad);
   const int footer_rows=(3+footer_columns-1)/footer_columns;
   const int footer_height=footer_rows*g_details_control+(footer_rows-1)*g_details_pad;
   const int footer_y=top+g_details_rect.height-g_details_pad-footer_height;
   const bool signal_pager_stacked=(g_raiz_tab==JPW_SIGNAL_ROUTE &&
      inner<JPWUIDesignButtonWidth("Estado · 999/999",g_details_font)+2*JPWUIDesignPx(48)+2*g_details_pad);
   const int paging_height=(signal_pager_stacked ? 2*g_details_control+2*g_details_pad :
      MathMax(g_details_control+g_details_pad,g_details_line));
   const int reserved=(g_raiz_tab==JPW_ROUTE_SETTINGS || (g_raiz_tab==JPW_ROUTE_OVERVIEW && (g_cockpit_pref_invalid || g_personal_live_count>0 || g_personal_live_state==3)) ?
                       paging_height+2*g_details_line : paging_height);
   const int body_height=footer_y-g_details_pad-body_y-reserved;
   const int footer_button=(inner-(footer_columns-1)*g_details_pad)/footer_columns;
   JPWRaizCreateSurface("FOOTER",left+1,footer_y-paging_height-g_details_pad/2,
                         g_details_rect.width-2,
                         g_details_rect.y+g_details_rect.height-footer_y+
                         paging_height+g_details_pad/2-2,g_details_chrome);
   if(body_height<g_details_control || footer_button<JPWUIDesignPx(32) ||
      JPWDialogFooterMinimum(footer_labels,3)>inner)
     {
      if(body_y+g_details_line<footer_y)
         JPWRaizCreateLabel("FEEDBACK","Amplie o gráfico para ver o cockpit",x,body_y);
      JPWRaizCreateButton(JPW_ACTION_CLOSE,"Fechar",x,footer_y,inner);
      g_raiz_panel_built=true;
      return;
     }
   if(compact_nav && g_cockpit_sections_open)
     {
      const int capacity=MathMax(1,body_height/(g_details_control+g_details_pad));
      const int pages=JPWPanelPageCount(6,capacity);
      g_cockpit_section_page=JPWPanelClamp(g_cockpit_section_page,0,pages-1);
      for(int j=0;j<capacity && g_cockpit_section_page*capacity+j<6;j++)
        { const int index=g_cockpit_section_page*capacity+j;
          JPWRaizCreateButton(tab_actions[index],tabs[index],x,body_y+j*(g_details_control+g_details_pad),inner); }
      JPWRaizCreateLabel("PAGE","Seções · "+IntegerToString(g_cockpit_section_page+1)+"/"+IntegerToString(pages),x,footer_y-g_details_line);
      JPWDialogPager(x,footer_y-paging_height,inner,JPW_ACTION_PREVIOUS,JPW_ACTION_NEXT);
      JPWRaizCreateButton(JPW_ACTION_CLOSE,"Fechar",x+inner-JPWUIDesignButtonWidth("Fechar",g_details_font),footer_y,JPWUIDesignButtonWidth("Fechar",g_details_font));
      g_raiz_panel_built=true; JPWFocusPaint(); return;
     }
   if(g_raiz_tab==JPW_SIGNAL_ROUTE)
     {
      JPWSignalRenderBody(x,body_y,inner,body_height,footer_y);
      g_raiz_panel_built=true; JPWFocusPaint(); return;
     }
   if(g_raiz_tab==JPW_ROUTE_OVERVIEW)
     {
      const int columns=(inner>=JPWUIDesignPx(640) ? 2 : 1);
      const int card_width=(inner-(columns-1)*g_details_pad)/columns;
      uint value_width=0,value_height=0;
      TextSetFont("Arial",-10*(g_details_font+2),FW_NORMAL);TextGetSize("Ag",value_width,value_height);
      const int value_line=MathMax(g_details_line,(int)value_height+g_details_pad);
      const int card_height=g_details_control+value_line+3*g_details_line+2*g_details_pad;
      const int card_stride=card_height+g_details_pad;
      const int card_inset=(g_details_pad>4 ? g_details_pad : 4);
      const int card_inner=card_width-2*card_inset;
      const int rows=(body_height+g_details_pad)/card_stride;
      const int capacity=(rows>0 ? rows*columns : 1);
      const int pages=(JPW_COCKPIT_METRIC_COUNT+capacity-1)/capacity;
      g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
      for(int j=0;j<capacity && g_cockpit_page*capacity+j<JPW_COCKPIT_METRIC_COUNT;j++)
        {
         const int i=JPWCockpitPresentationIndex(g_cockpit_page*capacity+j);
         const int cx=x+(j%columns)*(card_width+g_details_pad);
         const int y=body_y+(j/columns)*card_stride;
         JPWCockpitMetric metric=g_cockpit_snapshot.metric[i];
         if(rows>0)
            JPWRaizCreateSurface("CARD_BG_"+IntegerToString(i),cx,y,
                                 card_width,card_height,g_details_card);
         JPWRaizCreateButton(JPW_ACTION_CARD_FIRST+i,
                             (rows>0 ? "" : JPWCockpitMetricTitle(i,metric.title)+" · Ver detalhes"),
                             (rows>0 ? cx+card_inset : cx),
                             (rows>0 ? y+card_inset : y),
                             (rows>0 ? card_inner : card_width));
         if(rows==0)
           {
            if(body_height>=g_details_control+g_details_line)
               JPWRaizCreateLabel("SMALL_CARD","Amplie para ver o cartão completo",cx,y+g_details_control);
            continue;
           }
         const string suffix="CARD_"+IntegerToString(i);
         JPWRaizCreateLabel(suffix+"_TITLE",JPWFitText(JPWCockpitMetricTitle(i,metric.title)+" · Ver detalhes",card_inner,g_details_font),
            cx+card_inset,y+card_inset+MathMax(0,(g_details_control-(g_details_line-g_details_pad))/2));
         JPWPresentationSetInteger(JPWRaizUI(suffix+"_TITLE"),OBJPROP_ZORDER,5);
         const int value_y=y+g_details_control+card_inset+g_details_pad/2;
         const int state_y=value_y+value_line;
         JPWCreateProtectedValue(suffix+"_VALUE",JPWCockpitMetricValue(i,metric.value),cx+card_inset,
                                  value_y,card_inner,g_details_font+2);
         const string quality=JPWCockpitQualityLabel(JPWGenetrixMetricQuality(i,metric.quality));
         const int badge_width=MathMin(card_inner,JPWUIDesignTextWidth(quality,g_details_font)+g_details_pad);
         JPWRaizCreateSurface(suffix+"_STATE_BG",cx+card_inset,state_y,
                              badge_width,g_details_line,g_details_chrome);
         // Keep the existing CARD_BG / QUALITY click routes in precedence.
         JPWPresentationSetInteger(JPWRaizUI(suffix+"_STATE_BG"),OBJPROP_ZORDER,1);
         JPWRaizCreateLabel(suffix+"_QUALITY",JPWCockpitQualityLabel(JPWGenetrixMetricQuality(i,metric.quality)),
                              cx+card_inset,state_y);
         string reasons[];JPWDetailsWrap((i==0 ? "Conta inteira · " : (i==5 ? JPWRiskDisplayScope()+" · " : ""))+metric.reason,card_inner,reasons);
         for(int line=0;line<2 && line<ArraySize(reasons);line++)
            JPWRaizCreateLabel(suffix+(line==0 ? "_REASON" : "_REASON2"),reasons[line],
                              cx+card_inset,state_y+(line+1)*g_details_line);
         JPWPresentationSetString(JPWRaizUI("BUTTON_"+IntegerToString(JPW_ACTION_CARD_FIRST+i)),
                         OBJPROP_TOOLTIP,"Fórmula, insumos, proveniência e limites desta métrica.");
        }
      JPWRaizCreateLabel("PAGE","Cartões "+IntegerToString(g_cockpit_page+1)+"/"+
                          IntegerToString(pages),x,footer_y-g_details_line);
      if(!g_cockpit_pref_invalid && (g_personal_live_count>0 || g_personal_live_state==3))
         JPWRaizCreateLabel("PH_NOTICE",JPWFitText(g_personal_live_notice,inner,g_details_font),x,footer_y-2*g_details_line);
      if(g_cockpit_pref_invalid)
         JPWRaizCreateLabel("FEEDBACK","Preferência visual inválida · abra Ajustes",
                            x,footer_y-2*g_details_line);
     }
   else if(g_raiz_tab==JPW_ROUTE_PERSONAL_HISTORY || g_raiz_tab==JPW_ROUTE_PERSONAL_DETAIL || g_raiz_tab==JPW_ROUTE_PERSONAL_EXPORT)
     {
      JPWPersonalRenderBody(x,body_y,inner,body_height,footer_y);
     }
   else if(g_raiz_tab==JPW_ROUTE_STOPS)
     {
      JPWRenderStopsTable(x,body_y,inner,body_height,footer_y);
     }
   else if(g_raiz_tab==JPW_ROUTE_LEDGER_CYCLES)
     {
      g_genetrix_cycle_button_count=0;
      const int stride=g_details_control+2*g_details_line+g_details_pad;
      const int rows=JPWPanelClamp(body_height/stride,1,16);
      const int total=(g_genetrix_ledger_available ? ArraySize(g_genetrix_cycles) : 0);
      const int pages=JPWPanelPageCount(total,rows);
      g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
      if(total==0)
         JPWRaizCreateLabel("LEDGER_EMPTY",JPWFitText("Ciclos indisponíveis · "+g_genetrix_ledger_reason,inner,g_details_font),x,body_y);
      for(int j=0;j<rows && g_cockpit_page*rows+j<total;j++)
        {
         const int i=g_cockpit_page*rows+j;
         JPWLedgerCycle cycle=g_genetrix_cycles[i];
         const int y=body_y+j*stride;
         g_genetrix_cycle_button_id[j]=cycle.cycle_id;
         g_genetrix_cycle_button_count=j+1;
         const string caption=(cycle.cycle_id==g_genetrix_selected_cycle ? "✓ " : "")+
            JPWGenetrixCycleScope(cycle)+" · "+(cycle.started_msc>0 ?
            TimeToString((datetime)(cycle.started_msc/1000),TIME_DATE|TIME_MINUTES) : "origem sem horário");
         JPWRaizCreateButton(JPW_ACTION_LEDGER_CYCLE_FIRST+j,caption,x,y,inner);
         if(body_height>=stride)
           {
            JPWRaizCreateLabel("LEDGER_STATE_"+IntegerToString(j),JPWFitText(JPWGenetrixCycleState(cycle)+" · "+
               JPWGenetrixCycleQuality(g_genetrix_view,cycle,GetTickCount64()),inner,g_details_font),x,y+g_details_control);
            JPWRaizCreateLabel("LEDGER_SCOPE_"+IntegerToString(j),JPWFitText("Gênese "+
               JPWGenetrixGenesisLabel(cycle)+" · "+
               IntegerToString(cycle.open_positions)+" posições / "+IntegerToString(cycle.pending_orders)+
               " pendentes",inner,g_details_font),x,y+g_details_control+g_details_line);
           }
        }
      JPWRaizCreateLabel("PAGE","Ciclos "+IntegerToString(g_cockpit_page+1)+"/"+IntegerToString(pages)+
         " · seleção visual",x,footer_y-g_details_line);
     }
   else if(g_raiz_tab==JPW_ROUTE_SETTINGS)
     {
      string names[JPW_COCKPIT_METRIC_COUNT]={"Leverage","Floating P/L","Genesis SL","Raiz N 1W","Raiz N 2W","Stop risk","Flutuante compensado"};
      const int row_height=g_details_control+g_details_pad;
      const int total=JPW_COCKPIT_METRIC_COUNT+2;
      const int rows=(body_height/row_height>0 ? body_height/row_height : 1);
      const int pages=(total+rows-1)/rows;
      g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
      for(int j=0;j<rows && g_cockpit_page*rows+j<total;j++)
        {
         const int item=g_cockpit_page*rows+j;
         string caption="";
         int button_id=0;
         if(item<JPW_COCKPIT_METRIC_COUNT)
           { button_id=60+item; caption=(JPWCockpitVisible(g_cockpit_draft,item) ? "✓ " : "○ ")+names[item]; }
         else if(item==JPW_COCKPIT_METRIC_COUNT)
           { button_id=30; caption="Canto: "+JPWCockpitCornerName(g_cockpit_draft.corner); }
         else
           { button_id=31; caption="Densidade: "+(g_cockpit_draft.density==0 ? "Compacta" : "Normal"); }
         JPWRaizCreateButton(button_id,caption,x,body_y+j*row_height,inner);
        }
      const string notice=(g_cockpit_pref_invalid ? g_cockpit_pref_notice :
         "Prévia imediata no gráfico. Aplicar salva neste gráfico; Cancelar restaura.");
      JPWRaizCreateLabel("FEEDBACK",notice,x,footer_y-2*g_details_line);
      JPWRaizCreateLabel("PAGE","Opções "+IntegerToString(g_cockpit_page+1)+"/"+
                          IntegerToString(pages),
                          x,footer_y-g_details_line);
     }
   else
     {
      string lines[];
      if(g_raiz_tab==JPW_ROUTE_METRIC)
        {
         const int i=g_cockpit_selected;
         JPWCockpitMetric metric=g_cockpit_snapshot.metric[i];
         JPWDetailsWrap(JPWCockpitMetricTitle(i,metric.title)+": "+JPWCockpitMetricValue(i,metric.value)+" · "+JPWCockpitQualityLabel(JPWGenetrixMetricQuality(i,metric.quality)),inner,lines);
         JPWDetailsWrap("Estado: "+metric.reason,inner,lines);
         if(i==0) JPWDetailsWrap("Escopo: conta inteira; alavancagem não se limita ao símbolo ou à tese selecionada.",inner,lines);
         if(i==5) JPWDetailsWrap(JPWRiskDisplayScope()+". Escopo: grupo atribuído de símbolo/direção; não demonstra isolamento exclusivo de tese. Seleção (Selected) ou inferência (Inferred) permanece indicada na origem. Denominador: saldo da amostra.",inner,lines);
         JPWDetailsWrap("Nome canônico: "+metric.title+" · "+JPWGenetrixMetricQuality(i,metric.quality),inner,lines);
         JPWDetailsWrap("Amostra "+IntegerToString(metric.sample.id)+" · "+metric.sample.source+
            " · unidade "+metric.sample.unit+" · código "+IntegerToString((int)metric.sample.reason_code)+
            ". Observada em "+TimeToString((datetime)metric.sample.observed_utc,TIME_DATE|TIME_SECONDS)+
            " UTC (computador). Redesenhar não cria outra amostra.",inner,lines);
         string formulas[JPW_COCKPIT_METRIC_COUNT]={"Nocional bruto de todas as posições / último equity informado pelo terminal.",
           "100 × lucro flutuante / saldo.","Distância da cotação Bid (compra) ou Ask (venda) ao SL local da referência; percentual do preço.",
           "100 × ATR(55,H4) × √N(1W) × F / preço médio do mesmo tick.",
           "100 × ATR(55,H4) × √N(2W) × F / preço médio do mesmo tick.",
           "Soma do risco de posições abertas (execução até SL, piso zero) e reservas de pendentes ampliadoras atribuídas. Percentual informativo sobre saldo atual.",
           "NET realizado desde a origem inferida + flutuante NET remanescente, incluindo custos atribuíveis sem duplicação. 100 × compensado / saldo da amostra."};
         JPWDetailsWrap("Fórmula: "+formulas[i],inner,lines);
         JPWDetailsWrap("Insumos, origem e horário: "+metric.detail,inner,lines);
         if(i==3 || i==4)
            JPWDetailsWrap("Limite: escala diagnóstica; Current qualifica os dados, não homologa P-21 nem decide stop, lote ou entrada.",inner,lines);
         if(i==2)
            JPWDetailsWrap("Limite: SL local sem confirmação de execução; referência inferida não certifica a Gênese.",inner,lines);
         if(i==5)
            JPWDetailsWrap("Limite: não é Risco Comprometido, limite de fase ou perda máxima garantida. Custos, perdas realizadas, gaps e slippage ficam fora.",inner,lines);
         if(i==6)
           {
            const int selected=JPWGenetrixSelectedIndex();
            if(selected>=0 && g_genetrix_ledger_available)
              {
               JPWLedgerCycle cycle=g_genetrix_cycles[selected];
               const string currency=g_genetrix_view.currency;
               const bool known=cycle.amount_valid;
               const bool partial=(cycle.partial || !cycle.history_complete || !cycle.costs_complete ||
                  !g_genetrix_view.history_complete || !g_genetrix_view.costs_complete);
               JPWDetailsWrap("Escopo: "+JPWGenetrixCycleScope(cycle)+" · "+JPWGenetrixCycleState(cycle)+
                  ". Seleção apenas visual; nenhuma conta operacional é trocada.",inner,lines);
               JPWDetailsWrap("Origem contábil "+JPWGenetrixGenesisLabel(cycle)+
                  "; não certifica tese, flag GÊNESE ou dupla confirmação. O ciclo subsiste com pendentes mesmo sem posições.",inner,lines);
               JPWDetailsWrap((partial ? "Subtotal conhecido · PARCIAL: " : "Snapshot datado: ")+
                  (known ? JPWGenetrixMoney(cycle.compensated,currency) : "N/A")+
                  "; percentual "+(known && cycle.percent_valid ? JPWGenetrixSignedNumber(cycle.percent)+"%" : "N/A")+
                  " sobre saldo da amostra "+JPWGenetrixMoney(g_genetrix_view.balance,currency)+
                  ", observada "+TimeToString((datetime)g_genetrix_view.observed_utc,TIME_DATE|TIME_SECONDS)+
                  " UTC. Histórico não é flutuante atual nem saldo no encerramento.",inner,lines);
               JPWDetailsWrap("Componentes "+(partial ? "CONHECIDOS · PARCIAIS" : "da leitura")+
                  ": realizado preço "+(known ? JPWGenetrixMoney(cycle.realized_price,currency) : "N/A")+
                  "; swap realizado "+(known ? JPWGenetrixMoney(cycle.realized_swap,currency) : "N/A")+
                  "; comissões "+(known ? JPWGenetrixMoney(cycle.commissions,currency) : "N/A")+
                  "; taxas "+(known ? JPWGenetrixMoney(cycle.fees,currency) : "N/A")+".",inner,lines);
               JPWDetailsWrap("Remanescente: preço "+(known ? JPWGenetrixMoney(cycle.unrealized_price,currency) : "N/A")+
                  "; swap "+(known ? JPWGenetrixMoney(cycle.unrealized_swap,currency) : "N/A")+
                  ". Valores projetados do ledger; a UI não soma parcelas nem presume custos ausentes iguais a zero.",inner,lines);
               JPWDetailsWrap("Histórico: "+(cycle.history_complete ? "completo declarado" : "incompleto")+
                  "; custos: "+(cycle.costs_complete ? "completos declarados" : "incompletos")+
                  "; "+IntegerToString(cycle.open_positions)+" posições / "+IntegerToString(cycle.pending_orders)+
                  " pendentes. "+cycle.reason,inner,lines);
               string member_ids[];
               const bool members_known=JPWGenetrixMemberIdentifiers(cycle,member_ids);
               JPWDetailsWrap("Membros da geração "+IntegerToString(g_genetrix_view.generation)+
                  ", observada "+TimeToString((datetime)g_genetrix_view.observed_utc,TIME_DATE|TIME_SECONDS)+
                  " UTC. Identificadores observados das posições, incluindo encerradas; não são tickets atuais.",inner,lines);
               if(!members_known)
                  JPWDetailsWrap("Membros indisponíveis nesta publicação; ausência da lista não comprova zero membros.",inner,lines);
               else if(ArraySize(member_ids)==0)
                  JPWDetailsWrap("Ciclo provisório antes da primeira execução; nenhum identificador de posição atribuído nesta geração.",inner,lines);
               else
                 {
                  JPWDetailsWrap("Lista observada: "+IntegerToString(ArraySize(member_ids))+
                     " identificadores. Cobertura histórica "+(cycle.history_complete ?
                     "completa declarada; não verificada automaticamente." :
                     "incompleta; a lista não comprova todos os membros desde a origem."),inner,lines);
                  for(int member=0;member<ArraySize(member_ids);member++)
                     JPWDetailsWrap("Membro "+IntegerToString(member+1)+
                        ": POSITION_IDENTIFIER "+member_ids[member],inner,lines);
                 }
              }
            JPWDetailsWrap(JPWGenetrixLedgerHealth(),inner,lines);
            JPWDetailsWrap("Limite: métrica contábil, distinta do Floating P/L global. Resultado positivo não abate perdas/custos negativos no RC nem financia ampliação de risco.",inner,lines);
           }
        }
      else if(g_raiz_tab==JPW_ROUTE_STOP_ROW)
        {
         if(g_position_detail_open)
           {
            const int index=JPWPositionsViewFind(g_position_detail_ticket,g_position_detail_identifier);
            if(index<0 || !JPWPositionsViewCurrent(g_sample_context,GetTickCount64()))
               JPWDetailsWrap("Posição indisponível nesta leitura; volte à tabela e atualize.",inner,lines);
            else
              {
               JPWPositionView row=g_position_views[index];
               JPWDetailsWrap(JPWPositionRole(row)+" · "+row.symbol+" · "+
                  (row.direction==POSITION_TYPE_BUY ? "BUY" : "SELL")+
                  " · ticket MT5 "+JPWPositionTicket(row.ticket),inner,lines);
               JPWDetailsWrap("Volume remanescente: "+DoubleToString(row.volume,row.volume_digits)+" lote.",inner,lines);
               JPWDetailsWrap("Leverage individual: "+JPWPositionLeverageText(row)+
                  " · "+JPWCockpitQualityText((JPW_VIEW_QUALITY)row.quality)+". "+row.reason,inner,lines);
               JPWDetailsWrap("Fórmula: nocional desta posição / último equity aceito da conta. "+
                  "Mesmos preços, conversões e escala contratual da leitura da conta; não é margem nem leverage da corretora.",inner,lines);
               JPWDetailsWrap("Amostra "+IntegerToString(g_positions_view.sample_id)+"; observada "+
                  TimeToString((datetime)g_positions_view.observed_utc,TIME_DATE|TIME_SECONDS)+" UTC (computador).",inner,lines);
               JPWDetailsWrap("Entrada: "+(row.entry_valid ? DoubleToString(row.entry,8) : "N/A")+
                  "; SL: "+(row.sl_valid ? (row.sl>0.0 ? DoubleToString(row.sl,8) : "Sem SL") : "N/A")+
                  "; TP: "+(row.tp_valid ? (row.tp>0.0 ? DoubleToString(row.tp,8) : "Sem TP") : "N/A")+".",inner,lines);
               string amount="",percent="",state="",reason=""; JPWPositionRiskView(row,amount,percent,state,reason);
               JPWDetailsWrap("Stop EA: "+amount+" · "+percent+" saldo · "+state+". "+reason,inner,lines);
               JPWDetailsWrap("Risco EA e leverage têm origens/horários independentes. "+
                  "LAST · NOT ACTIVE não é risco atual. Conta lista todas as posições; o consolidado Stop risk preserva a operação atribuída.",inner,lines);
              }
           }
         else
           {
         JPWDetailsWrap(g_stop_selected_role+
            (g_stop_selected_row==-2 ? " · referência encerrada, memória" :
            (g_stop_table_historical ? " · última amostra, não atual" :
                                       " · amostra atual")),inner,lines);
         if(g_stop_selected_row==-2)
           {
            JPWDetailsWrap("Referência Gênese encerrada: ticket de origem "+
               IntegerToString(g_stop_genesis_ticket)+", identificador "+
               IntegerToString(g_stop_genesis_identifier)+". Nenhuma sucessora foi promovida.",inner,lines);
            JPWDetailsWrap("A linha é memória da referência; não soma risco aberto.",inner,lines);
           }
         else if(g_stop_selected_row>=0 &&
                 g_stop_selected_row<ArraySize(g_stop_table_rows))
           {
            JPWStopRiskRow row=g_stop_table_rows[g_stop_selected_row];
            JPWDetailsWrap((row.kind==JPW_STOP_RISK_PENDING ? "Pendente" : "Posição")+
               " · "+row.symbol+" · "+(row.side>0 ? "BUY" : "SELL")+
               " · ticket "+IntegerToString(row.ticket)+
               " · identificador "+IntegerToString(row.identifier),inner,lines);
            JPWDetailsWrap("Abertura/criação: "+
               TimeToString((datetime)(row.opened_msc/1000),TIME_DATE|TIME_SECONDS)+
               " (servidor). Volume remanescente: "+DoubleToString(row.volume,4),inner,lines);
            JPWDetailsWrap("Preço de execução/planejado: "+DoubleToString(row.entry,8)+
               "; SL vigente: "+DoubleToString(row.sl,8)+".",inner,lines);
            if(row.valid==1 && JPWFinitePositive(g_stop_table_sample.balance))
               JPWDetailsWrap("Stop aberto: "+JPWStopRiskMoney(row.risk_money)+" "+
                  g_stop_table_sample.currency+" · "+
                  JPWFormatPercent(100.0*row.risk_money/g_stop_table_sample.balance,false)+
                  " do saldo atual.",inner,lines);
            else JPWDetailsWrap("Stop aberto: N/A · "+row.reason,inner,lines);
            if(row.kind==JPW_STOP_RISK_POSITION)
               JPWDetailsWrap("Preço atual→SL (medida separada): "+
                  (row.additional_valid==1 ? JPWStopRiskMoney(row.additional_money)+
                   " "+g_stop_table_sample.currency : "N/A · "+row.additional_reason),
                   inner,lines);
            JPWDetailsWrap(g_stop_table_sample.margin_mode==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING ?
               "Origem: produtor de monitoramento (Monitor/Observer legado); OrderCalcProfit em moeda da conta. Papel Gênese/Defesa inferido por identidade/antiguidade; tese não certificada no MT5." :
               "Posição netting agregada: MT5 não preserva risco individual por ordem com piso zero; consolidado Gênese/Defesa N/A.",
               inner,lines);
            JPWDetailsWrap("Estado: "+row.reason,inner,lines);
           }
           }
        }
      else if(g_raiz_tab==JPW_ROUTE_RAIZN)
        {
         JPWDetailsWrap("Raiz N diagnóstica: horizontes móveis de 7 e 14 dias civis do servidor.",inner,lines);
         JPWDetailsWrap("1W: "+g_cockpit_snapshot.metric[3].value+" · "+JPWCockpitQualityText(g_cockpit_snapshot.metric[3].quality)+". "+g_cockpit_snapshot.metric[3].reason,inner,lines);
         JPWDetailsWrap("2W: "+g_cockpit_snapshot.metric[4].value+" · "+JPWCockpitQualityText(g_cockpit_snapshot.metric[4].quality)+". "+g_cockpit_snapshot.metric[4].reason,inner,lines);
         JPWDetailsWrap("Insumos da última apuração (consulte o estado atual acima): P0, ATR, N, F e horários: "+g_raiz_tooltip+" "+g_scale2_tooltip,inner,lines);
         JPWDetailsWrap("F diagnóstico: "+(g_factor_state==JPW_RAIZN_VALID ?
                        DoubleToString(g_factor_preference.factor,1)+" salvo" :
                        (g_factor_state==JPW_RAIZN_ABSENT ? "1,5 padrão" : "N/A: "+g_factor_reason))+
                        ". P-21 estatutário permanece PENDING.",inner,lines);
         JPWDetailsWrap("A probabilidade teórica de primeiro não toque usa barreira hipotética fixa e premissas brownianas. Não mede o SL real, lucro ou cobertura empírica.",inner,lines);
        }
      else if(g_raiz_tab==JPW_ROUTE_EXPORT)
        {
         JPWDetailsWrap("Prévia de exportação técnica local. Não contém login, ticket, credenciais ou valores financeiros. Somente eventos essenciais, versões, códigos e contexto opaco.",inner,lines);
         JPWDetailsWrap(g_export_preview=="" ? "Aguardando prévia no próximo timer." : g_export_preview,inner,lines);
         JPWDetailsWrap(g_export_result,inner,lines);
        }
      else if(g_raiz_tab==JPW_ROUTE_SYSTEM)
        {
         JPWMonitorAppendComponents(inner,lines);

        }
      else
        {
         JPWMonitorAppendComponents(inner,lines,true);
         JPWDetailsWrap(JPWGenetrixLedgerHealth(),inner,lines);
         JPWDetailsWrap(JPWGenetrixRiskSummary(),inner,lines);
         JPWDetailsWrap(JPW_PRODUCT_NAME+" "+JPW_PRODUCT_VERSION+" · cálculo "+JPW_CALCULATION_VERSION+
                         " · build "+JPW_BUILD_ID,inner,lines);
         JPWDetailsWrap(JPW_PRODUCT_TAGLINE,inner,lines);
         const ulong evidence_now=GetTickCount64();
         // Publisher evidence is independent of the financial total: a recent
         // verified generation may legitimately report N/A (e.g. missing SL).
         const bool observer_recent=g_stop_ready &&
            g_stop_sample.account_key==g_diagnostic_context &&
            g_stop_sample.observed_mono_ms>0 &&
            evidence_now>=(ulong)g_stop_sample.observed_mono_ms &&
            evidence_now-(ulong)g_stop_sample.observed_mono_ms<=30000;
         const JPW_TECHNICAL_HEALTH health=JPWTechnicalHealthEvaluate(g_sample_context!="",
            g_diagnostic_state==JPW_STORE_VALID,
            g_diagnostic_write_state==JPW_STORE_VALID,ArraySize(g_diagnostic_pending),
            g_diagnostic_queue_lost,observer_recent,g_last_cycle_duration_ms>=500 || g_refresh_requested);
         JPWDetailsWrap("Saúde técnica: "+(health==JPW_HEALTH_UNAVAILABLE ? "indisponível — contexto inválido" :
            (health==JPW_HEALTH_ATTENTION ? "atenção — armazenamento, fila, orçamento ou evidência do monitoramento" :
             "normal nas evidências atuais"))+". Qualidade das métricas é independente; cobertura histórica permanece desconhecida ou incompleta.",inner,lines);
         JPWDetailsWrap("Eventos aguardando persistência: "+IntegerToString(ArraySize(g_diagnostic_pending))+
            (g_diagnostic_queue_lost ? "; lacuna da fila pendente" : "")+". Evidência recente do produtor de monitoramento: "+
            (observer_recent ? "presente" : "não confirmada")+"; não prova atividade contínua.",inner,lines);
         string observer_state="sem sinal recente compatível";
         if(g_stop_observer_presence==JPW_OBSERVER_WAITING)
            observer_state="presente; aguardando primeira amostra";
         else if(g_stop_observer_presence==JPW_OBSERVER_FAILED)
            observer_state="presente; publicação falhou";
         else if(g_stop_observer_presence==JPW_OBSERVER_PUBLISHED)
            observer_state="presente; publicação sinalizada";
         JPWDetailsWrap("Sinal do monitoramento (Monitor/Observer legado): "+observer_state+
            ". Amostra financeira Stop risk: "+
            (g_stop_quality==JPW_VIEW_CURRENT ? "Current" : "N/A · "+g_stop_reason)+
            ". Um sinal não valida o total nem prova cobertura contínua.",inner,lines);
         JPWDetailsWrap("Ativação do núcleo nesta instalação: Expert Advisors > JPWealth > JPW_Stoikus_Monitor, em gráfico de apoio dedicado. Não inicie Observer ou Accountant legados junto dele; confira o motivo de cada módulo e a aba Experts.",inner,lines);
         JPWDetailsWrap("Trilha técnica: "+(g_diagnostic_state==JPW_STORE_VALID ? "acessível" :
            (g_diagnostic_state==JPW_STORE_ABSENT ? "ainda ausente" : "indisponível/atenção"))+
            ". "+g_diagnostic_summary+" "+g_diagnostic_reason,inner,lines);
         JPWDetailsWrap("Último ciclo observado: "+IntegerToString((long)g_last_cycle_duration_ms)+
            " ms. Timer solicitado não garante despacho. Compilação/integração nativas destes bytes exigem recibo separado.",inner,lines);
         JPWDetailsWrap("Registros locais pertencem à instalação e à conta. Nenhum histórico completo é inferido de uma amostra.",inner,lines);
         JPWDetailsWrap(g_mdd_summary+". "+g_mdd_context,inner,lines);
         JPWDetailsWrap(g_observer_summary+". "+g_observer_context,inner,lines);
         JPWDetailsWrap("A última captura do núcleo Monitor não prova que ele esteja ativo neste instante.",inner,lines);
         JPWDetailsWrap("Preferências visuais ficam no objeto deste gráfico; o modelo MT5 é salvo manualmente pelo usuário.",inner,lines);
         JPWDetailsWrap("Amostra do cockpit: "+_Symbol+" · sequência "+IntegerToString(g_cockpit_snapshot.sequence),inner,lines);
         JPWDetailsWrap("Cadência: solicitada "+IntegerToString(InpUpdateSeconds)+
            " s; leitura completa no máximo a cada 30 s por frescor, Stop risk verificado no máximo a cada 5 s. O timer não garante intervalos exatos.",inner,lines);
         JPWDetailsWrap("Cotação: "+(g_live_sample.quote_time_msc>0 ?
            TimeToString((datetime)(g_live_sample.quote_time_msc/1000),TIME_DATE|TIME_SECONDS)+" (servidor)" :
            "indisponível")+". "+g_live_sample.reason,inner,lines);
         JPWDetailsWrap("ATR: "+(g_live_sample.atr>0.0 ? DoubleToString(g_live_sample.atr,8) : "N/A")+
            " · H4 encerrado "+(g_live_sample.bar_time>0 ?
               TimeToString(g_live_sample.bar_time,TIME_DATE|TIME_SECONDS)+" (servidor)" :
               "indisponível")+".",inner,lines);
         JPWDetailsWrap("Calendário: "+g_horizon_result.source+". 1W: "+g_horizon_result.reason_1w+
            ". 2W: "+g_horizon_result.reason_2w,inner,lines);
         JPWDetailsWrap("F: "+(g_factor_state==JPW_RAIZN_VALID ?
            DoubleToString(g_factor_preference.factor,1)+" gravado" :
            (g_factor_state==JPW_RAIZN_ABSENT ? "1,5 padrão não gravado" : "indisponível: "+g_factor_reason))+
            ". P-21 PENDING.",inner,lines);
         JPWDetailsWrap("DD atual: "+g_dd_line+". "+g_dd_tooltip,inner,lines);
         JPWDetailsWrap("MDD local: "+g_mdd_summary+". "+g_mdd_context,inner,lines);
         JPWDetailsWrap("Monitoramento (Monitor/Observer legado): "+g_observer_summary+". "+g_observer_context+
            " Última captura conhecida não prova que o EA esteja ativo agora.",inner,lines);
        }
      const int rows=(body_height/g_details_line>0 ? body_height/g_details_line : 1);
      const int pages=JPWPanelPageCount(ArraySize(lines),rows);
      g_cockpit_page=JPWPanelClamp(g_cockpit_page,0,pages-1);
      for(int j=0;j<rows && g_cockpit_page*rows+j<ArraySize(lines) && j<60;j++)
        {
         const string suffix="TEXT_"+IntegerToString(j);
         JPWRaizCreateLabel(suffix,lines[g_cockpit_page*rows+j],x,body_y+j*g_details_line);
         JPWPresentationSetString(JPWRaizUI(suffix),OBJPROP_TOOLTIP,"\n");
        }
      JPWRaizCreateLabel("PAGE","Página "+IntegerToString(g_cockpit_page+1)+"/"+
                          IntegerToString(pages),x,footer_y-g_details_line);
     }
   JPWDialogFooterButtons(footer_actions,footer_labels,3,x,footer_y,inner);
   // Paging is visible on every screen; disabled end clicks are harmless.
   const bool position_scroll=(g_raiz_tab==JPW_ROUTE_STOPS && !g_stops_show_pending);
   const int previous_action=(position_scroll ? JPW_ACTION_POSITIONS_UP : JPW_ACTION_PREVIOUS);
   const int next_action=(position_scroll ? JPW_ACTION_POSITIONS_DOWN : JPW_ACTION_NEXT);
   JPWDialogPager(x,footer_y-paging_height,inner,previous_action,next_action);
   g_raiz_panel_built=true; JPWFocusPaint();
  }

void JPWRenderRaizDetailsBody()
  {
   if(!g_raiz_details_open || !JPWDetailsContextCurrent()) return;
   if(g_raiz_tab>=JPW_ROUTE_OVERVIEW) { JPWRenderCockpit(); return; }
   const color background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
   g_details_text=JPWPanelInk(background); g_details_surface=JPWPanelWindowSurface(background);
   g_details_chrome=JPWPanelChromeSurface(background);
   g_details_card=JPWPanelCardSurface(background);
   g_details_border=JPWPanelBorderColor(background);
   const int chart_width=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   const int chart_height=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
   g_details_font=InpCockpitFontSize;
   uint text_width=0,text_height=0;
   if(!TextSetFont("Arial",-10*g_details_font,FW_NORMAL) ||
      !TextGetSize("Mg",text_width,text_height) || text_height==0)
     { JPWPresentationFailure("Interface indisponível; medida de fonte não confirmada."); return; }
   int content_y=0,content_height=0,footer_y=0;
   if(!JPWPanelDialog(chart_width,chart_height,(int)text_height,(int)text_width/2,
                     g_details_rect,g_details_pad,g_details_line,g_details_control,
                     content_y,content_height,footer_y))
     { JPWPresentationFailure("Interface indisponível; área gráfica não confirmada."); return; }
   if(!JPWPanelAccount(chart_width,chart_height,JPWUIDesignScale(),g_details_rect)) return;
   if(g_account_window_gesture.active) g_details_rect=g_account_window_rect;
   else if(g_stoikus_visual.account_positioned)
     {
      g_details_rect.x=(int)MathRound(g_stoikus_visual.account_x*JPWUIDesignScale());
      g_details_rect.y=(int)MathRound(g_stoikus_visual.account_y*JPWUIDesignScale());
      g_details_rect.width=JPWUIDesignPx(g_stoikus_visual.account_width);
      g_details_rect.height=JPWUIDesignPx(g_stoikus_visual.account_height);
     }
   JPWStoikusWindowBounds(g_details_rect,chart_width,chart_height);

   g_details_pad=((int)text_height/2>JPWUIDesignPx(8) ? (int)text_height/2 : JPWUIDesignPx(8));
   g_details_line=(int)text_height+g_details_pad;
   g_details_control=JPWUIDesignControlHeight((int)text_height);
   const int header_height=(g_details_control>g_details_line ? g_details_control : g_details_line);
   const int left=g_details_rect.x,top=g_details_rect.y,width=g_details_rect.width;
   const int x=left+g_details_pad,inner=width-2*g_details_pad;
   string legacy_footer_labels[4]={"Cancelar","‹","›","Vincular"};
   const int legacy_footer_columns=JPWUIDesignNavColumns(legacy_footer_labels,4,inner,g_details_font,g_details_pad);
   const int legacy_footer_rows=(4+legacy_footer_columns-1)/legacy_footer_columns;
   footer_y=top+g_details_rect.height-g_details_pad-
      legacy_footer_rows*g_details_control-(legacy_footer_rows-1)*g_details_pad;
   const string bg=JPWRaizUI("BG");
   if(!JPWPresentationEnsure(bg,OBJ_RECTANGLE_LABEL)) return;
   JPWPresentationSetInteger(bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   JPWPresentationSetInteger(bg,OBJPROP_XDISTANCE,left);
   JPWPresentationSetInteger(bg,OBJPROP_YDISTANCE,top);
   JPWPresentationSetInteger(bg,OBJPROP_XSIZE,width);
   JPWPresentationSetInteger(bg,OBJPROP_YSIZE,g_details_rect.height);
   JPWPresentationSetInteger(bg,OBJPROP_BGCOLOR,g_details_surface);
   JPWPresentationSetInteger(bg,OBJPROP_COLOR,g_details_border);
   JPWPresentationSetInteger(bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   JPWPresentationSetInteger(bg,OBJPROP_SELECTABLE,false);
   JPWPresentationSetInteger(bg,OBJPROP_BACK,false);
   JPWPresentationSetInteger(bg,OBJPROP_ZORDER,1);
   JPWPresentationSetInteger(bg,OBJPROP_HIDDEN,true);
   if(g_details_rect.height<2*g_details_control+header_height+4*g_details_pad ||
      inner<JPWUIDesignPx(110))
     {
      const int room=g_details_rect.height-2*g_details_pad;
      const int close_height=(room<g_details_control ? room : g_details_control);
      const int close_width=(inner<g_details_control ? inner : g_details_control);
      if(room>g_details_control+g_details_line)
         JPWRaizCreateLabel("TITLE","Conta · amplie o gráfico",x,top+g_details_pad);
      if(close_height>0 && close_width>0)
        {
         JPWRaizCreateButton(JPW_ACTION_HEADER_CLOSE,"×",x,
            top+g_details_rect.height-g_details_pad-close_height,close_width);
         JPWPresentationSetInteger(JPWActionObject(JPW_ACTION_HEADER_CLOSE),OBJPROP_YSIZE,close_height);
        }
      g_raiz_panel_built=true;
      return;
     }
   JPWRaizCreateSurface("HEADER",left+1,top+1,width-2,
                        header_height+2*g_details_pad-2,g_details_chrome);
   JPWRaizCreateSurface("FOOTER",left+1,footer_y-g_details_line,
                        width-2,top+g_details_rect.height-footer_y+g_details_line-2,
                        g_details_chrome);
   const int close_size=g_details_control;
   const string legacy_title="Conta · "+
      (g_raiz_tab==JPW_ROUTE_LEGACY_SUMMARY ? "Resumo" : (g_raiz_tab==JPW_ROUTE_LEGACY_NF ? "N/F legado" :
       (g_raiz_tab==JPW_ROUTE_FACTOR ? "F diagnóstico" : "Cenários avançados")))+" · "+_Symbol;
   JPWPresentationKeep(JPWRaizUI("BRAND_LOGO")); JPWPresentationKeep(JPWRaizUI("TITLE"));
   JPWGenetrixHeader(JPWRaizUI("BRAND_LOGO"),JPWRaizUI("TITLE"),x,top+g_details_pad,
      inner-2*close_size-2*g_details_pad,header_height,g_details_font,g_details_text,
      JPWPanelDarkBackground(background),legacy_title,4);
   JPWRaizCreateButton(JPW_ACTION_HEADER_CLOSE,"×",
                       left+width-g_details_pad-close_size,top+g_details_pad,close_size);
   JPWPresentationSetString(JPWActionObject(JPW_ACTION_HEADER_CLOSE),OBJPROP_TOOLTIP,"Fechar cockpit sem aplicar alterações");
   JPWRaizCreateButton(JPW_ACTION_MINIMIZE,"−",left+width-2*g_details_pad-2*close_size,top+g_details_pad,close_size);
   const int nav_y=top+2*g_details_pad+header_height;
   string legacy_nav[4]={"← Cockpit","F 1,5/1,8","N/F legado","Avançado"};
   string legacy_actions[3]={"Declarar","Vincular","Comparar"};
   const bool compact_actions=(g_details_rect.compact && g_raiz_tab<=JPW_ROUTE_BIND);
   const int nav_count=(compact_actions ? 3 : 4);
   const int nav_columns=(compact_actions ?
      JPWUIDesignNavColumns(legacy_actions,3,inner,g_details_font,g_details_pad) :
      JPWUIDesignNavColumns(legacy_nav,4,inner,g_details_font,g_details_pad));
   const int navigation_minimum=(compact_actions ?
      JPWDialogFooterMinimum(legacy_actions,3) : JPWDialogFooterMinimum(legacy_nav,4));
   if(navigation_minimum>inner)
     {
      const int exit_y=top+g_details_rect.height-g_details_pad-g_details_control;
      if(nav_y+g_details_line+g_details_pad<exit_y)
         JPWRaizCreateLabel("FEEDBACK","Amplie o gráfico para ver as ações",x,nav_y);
      JPWRaizCreateButton(JPW_ACTION_LEGACY_CANCEL,"Fechar",x,exit_y,inner);
      g_raiz_panel_built=true; JPWFocusPaint(); return;
     }
   const int nav_rows=(nav_count+nav_columns-1)/nav_columns;
   const int nav_width=(inner-(nav_columns-1)*g_details_pad)/nav_columns;
   const int action_width=(inner-2*g_details_pad)/3;
   content_y=nav_y+nav_rows*(g_details_control+g_details_pad)+
      (g_details_rect.compact ? 0 : g_details_control+g_details_pad);
   content_height=footer_y-g_details_pad-(g_details_rect.compact ? 0 : g_details_control+g_details_pad+2*g_details_line)-content_y;
   if(nav_width>0 && content_height>0)
     {
      if(g_details_rect.compact && g_raiz_tab<=JPW_ROUTE_BIND)
        {
         const int actions[3]={JPW_ACTION_DECLARE,JPW_ACTION_BIND,JPW_ACTION_COMPARE};
         for(int i=0;i<3;i++)
            JPWRaizCreateButton(actions[i],legacy_actions[i],
               x+(i%nav_columns)*(nav_width+g_details_pad),
               nav_y+(i/nav_columns)*(g_details_control+g_details_pad),nav_width);
        }
      else
        {
         const int actions[4]={JPW_ACTION_HOME,JPW_ACTION_FACTOR,JPW_ACTION_LEGACY_NF,JPW_ACTION_ADVANCED};
         for(int i=0;i<4;i++)
            JPWRaizCreateButton(actions[i],legacy_nav[i],
               x+(i%nav_columns)*(nav_width+g_details_pad),
               nav_y+(i/nav_columns)*(g_details_control+g_details_pad),nav_width);
        }
      const int action_y=nav_y+nav_rows*(g_details_control+g_details_pad);
      if(!g_details_rect.compact && g_raiz_tab<=JPW_ROUTE_BIND)
        {
         JPWRaizCreateButton(JPW_ACTION_DECLARE,"Declarar",x,action_y,action_width);
         JPWRaizCreateButton(JPW_ACTION_BIND,"Vincular",x+action_width+g_details_pad,action_y,action_width);
         JPWRaizCreateButton(JPW_ACTION_COMPARE,"Comparar",x+2*(action_width+g_details_pad),action_y,action_width);
        }
      else if(!g_details_rect.compact && g_raiz_tab==JPW_ROUTE_FACTOR)
        {
         const int choice_width=(inner-g_details_pad)/2;
         JPWRaizCreateButton(JPW_ACTION_FACTOR_15,(g_factor_draft==1.5 ? "✓ F 1,5" : "F 1,5"),
                              x,action_y,choice_width);
         JPWRaizCreateButton(JPW_ACTION_FACTOR_18,(g_factor_draft==1.8 ? "✓ F 1,8" : "F 1,8"),
                              x+choice_width+g_details_pad,action_y,choice_width);
        }
      else if(!g_details_rect.compact)
         JPWRaizCreateButton(JPW_ACTION_REFRESH,"Atualizar resumo",x,action_y,inner);
     }
   if(g_raiz_tab==JPW_ROUTE_FACTOR && g_details_rect.compact &&
      content_height>=g_details_control+g_details_pad)
     {
      const int choice_width=(inner-g_details_pad)/2;
      JPWRaizCreateButton(JPW_ACTION_FACTOR_15,(g_factor_draft==1.5 ? "✓ F 1,5" : "F 1,5"),
                           x,content_y,choice_width);
      JPWRaizCreateButton(JPW_ACTION_FACTOR_18,(g_factor_draft==1.8 ? "✓ F 1,8" : "F 1,8"),
                           x+choice_width+g_details_pad,content_y,choice_width);
      content_y+=g_details_control+g_details_pad;
      content_height-=g_details_control+g_details_pad;
     }
   if(g_details_rect.compact && g_raiz_feedback!="" && content_height>g_details_line)
     {
      JPWRaizCreateLabel("FEEDBACK",g_raiz_feedback,x,content_y);
      content_y+=g_details_line; content_height-=g_details_line;
     }
   string captions[21]={"P0 (preço)","Origem do P0","Decisão: AAAA.MM.DD HH:MM:SS (servidor)",
       "ATR: MT5 ou DECLARED","ATR declarado (>0)","Fonte do ATR","Variante do ATR",
       "Início H4 já encerrado: AAAA.MM.DD HH:MM:SS","N (candles H4)","Justificativa N",
       "F (>0)","F: DECLARED / ILLUSTRATIVE / SOURCED","Fonte de F","Justificativa F",
       "Lado: 1 BUY / -1 SELL / 0 sem lado","Motivo da revisão (obrigatório ao revisar)","Ticket aberto do símbolo exato",
       "N: horizonte em candles H4 (inteiro >0)","Justificativa do horizonte N",
       "F: fator diagnóstico (>0, use ponto decimal)","Justificativa de F (sem valor universal)"};
   const bool editing=(g_raiz_tab==JPW_ROUTE_DECLARE || g_raiz_tab==JPW_ROUTE_JUSTIFY || g_raiz_tab==JPW_ROUTE_BIND || g_raiz_tab==JPW_ROUTE_LEGACY_NF);
   int first=0,total=0,rows=0;
   string text_lines[];
   if(editing)
     {
      first=(g_raiz_tab==JPW_ROUTE_DECLARE ? 0 : (g_raiz_tab==JPW_ROUTE_JUSTIFY ? 8 : (g_raiz_tab==JPW_ROUTE_BIND ? 16 : 17)));
      total=(g_raiz_tab==JPW_ROUTE_BIND ? 1 : (g_raiz_tab==JPW_ROUTE_LEGACY_NF ? 4 : 8));
      rows=JPWPanelPageRows(content_height,g_details_line+g_details_control+g_details_pad);
     }
   else
     {
      if(g_raiz_tab==JPW_ROUTE_LEGACY_SUMMARY)
        {
         JPWDetailsWrap("Valores da abertura/atualização deste resumo. Use Atualizar resumo para uma nova consulta.",inner,text_lines);
         JPWDetailsWrap("Leverage: "+g_panel_value+"; "+g_panel_status,inner,text_lines);
         JPWDetailsWrap(g_floating_line+". "+g_floating_tooltip,inner,text_lines);
         JPWDetailsWrap(g_dd_line+". "+g_dd_tooltip,inner,text_lines);
         JPWDetailsWrap(g_mdd_summary+". "+g_mdd_context,inner,text_lines);
         JPWDetailsWrap(g_genesis_line+". "+g_genesis_tooltip,inner,text_lines);
         JPWDetailsWrap(g_raiz_line+". "+g_raiz_tooltip,inner,text_lines);
         JPWDetailsWrap(g_scale2_line+". "+g_scale2_tooltip,inner,text_lines);
         if(g_factor_state==JPW_RAIZN_VALID || g_factor_state==JPW_RAIZN_ABSENT)
           {
            const double active_factor=(g_factor_state==JPW_RAIZN_VALID ?
                                        g_factor_preference.factor : JPW_RAIZN_FACTOR_DEFAULT);
            double probability=0.0;
            if(JPWRaizNNoTouchProbability(active_factor,probability))
              JPWDetailsWrap("Primeiro não toque teórico de barreira adversa fixa: "+
                 JPWNoTouchPercentText(probability)+" para 1W e 2W com F "+
                 (active_factor==1.8 ? "1,8" : "1,5")+
                 ". A igualdade decorre de cada distância escalar com √N; os preços das barreiras diferem.",inner,text_lines);
            else JPWDetailsWrap("Primeiro não toque teórico: N/A; cálculo inválido.",inner,text_lines);
            JPWDetailsWrap((g_factor_state==JPW_RAIZN_ABSENT ?
               "F 1,5 é o padrão ainda não gravado." : "F escolhido foi gravado nesta instalação.")+
               " Aprovação de uso diagnóstico pelo proprietário; P-21 canônico permanece PENDING.",inner,text_lines);
           }
         else JPWDetailsWrap("F indisponível: "+g_factor_reason+
            " Registro preservado; não aplicamos F 1,5 por fallback.",inner,text_lines);
         JPWDetailsWrap("Referência browniana ideal sem drift e com volatilidade constante, aproximada pelo ATR. Não é a probabilidade remanescente de um SL real, chance de lucro ou cobertura empírica; não recomenda stop, lote ou entrada.",inner,text_lines);
         JPWDetailsWrap(g_observer_summary+". "+g_observer_context,inner,text_lines);
         if(g_live_config_state==JPW_RAIZN_VALID)
            JPWDetailsWrap("Configuração manual legada do símbolo: N="+
              IntegerToString(g_live_config.n)+", F="+
              DoubleToString(g_live_config.f,-16)+
              ". Declarada para diagnóstico anterior; NÃO aplicada às escalas 1W/2W.",inner,text_lines);
        }
      else if(g_raiz_tab==JPW_ROUTE_FACTOR)
        {
         if(g_factor_state==JPW_RAIZN_VALID || g_factor_state==JPW_RAIZN_ABSENT)
           {
            JPWDetailsWrap("Selecione F 1,5 ou F 1,8 acima. Aplicar grava apenas este fator para a conta, instalação e símbolo exato; Cancelar descarta o rascunho.",inner,text_lines);
            JPWDetailsWrap("F em rascunho: "+(g_factor_draft==1.8 ? "1,8" : "1,5")+
               (g_factor_state==JPW_RAIZN_ABSENT ?
                "; padrão inicial 1,5 ainda não gravado." :
                "; preferência gravada tem geração "+IntegerToString(g_factor_preference.generation)+"."),
               inner,text_lines);
            double probability=0.0;
            if(JPWRaizNNoTouchProbability(g_factor_draft,probability))
              JPWDetailsWrap("Prévia: primeiro não toque teórico de barreira adversa fixa = "+
                 JPWNoTouchPercentText(probability)+" para 1W e 2W. O mesmo F dá a mesma referência teórica porque cada distância usa √N; as distâncias em preço são diferentes.",inner,text_lines);
            else JPWDetailsWrap("Prévia de não toque teórico: N/A; cálculo inválido.",inner,text_lines);
           }
         else JPWDetailsWrap("Preferência de F indisponível: "+g_factor_reason+
            ". Não há fallback nem reparo automático; Aplicar fica bloqueado.",inner,text_lines);
         JPWDetailsWrap("Modelo browniano ideal: sem drift, volatilidade constante e aproximação ATR→dispersão. Isto não mede chance de lucro, cobertura observada ou probabilidade de o SL atual não ser tocado.",inner,text_lines);
         JPWDetailsWrap("F 1,5 é o padrão diagnóstico aprovado pelo proprietário; F 1,8 é alternativa selecionável. P-21 permanece PENDING e nenhum F homologa stop ou regra do Estatuto.",inner,text_lines);
        }
      else
        {
         JPWDetailsWrap("Cenários declarados 1.4: independentes do cálculo corrente, sem sobrescrita automática.",inner,text_lines);
         JPWDetailsWrap(g_saved_raiz_line+". "+g_saved_raiz_tooltip,inner,text_lines);
         JPWDetailsWrap(g_raiz_comparison,inner,text_lines);
         if(g_raiz_store_state==JPW_RAIZN_VALID)
           {
            double distance=0.0,percent=0.0;
            if(JPWRaizNCalculate(g_raiz_scenario.p0,g_raiz_scenario.atr,g_raiz_scenario.n_h4,g_raiz_scenario.factor,distance,percent)==JPW_RAIZN_OK)
               JPWDetailsWrap("Níveis aritméticos P0 ± D: "+DoubleToString(g_raiz_scenario.p0-distance,8)+
                  " / "+DoubleToString(g_raiz_scenario.p0+distance,8)+". Não são ordem ou novo SL.",inner,text_lines);
           }
         JPWDetailsWrap("Declarar/revisar preserva o cenário inicial. Vincular exige ticket explícito e direção coerente. Comparar grava recibo próprio; não altera o SL.",inner,text_lines);
        }
      total=ArraySize(text_lines); rows=JPWPanelPageRows(content_height,g_details_line);
     }
   // Destruction accounts for every visible row, including wrapped summaries.
   if(rows>60) rows=60;
   g_raiz_pages=JPWPanelPageCount(total,rows);
   g_raiz_page=JPWPanelClamp(g_raiz_page,0,g_raiz_pages-1);
   if(rows>0)
     {
      for(int j=0;j<rows && g_raiz_page*rows+j<total;j++)
        {
         const int item=g_raiz_page*rows+j;
         if(editing)
           {
            const int field=first+item,y=content_y+j*(g_details_line+g_details_control+g_details_pad);
            JPWRaizCreateLabel("LABEL_"+IntegerToString(field),captions[field],x,y);
            JPWRaizCreateEdit(field,x,y+g_details_line,inner);
           }
         else
           {
            const string suffix="TEXT_"+IntegerToString(j);
            JPWRaizCreateLabel(suffix,text_lines[item],x,content_y+j*g_details_line);
            // Full summary text is already wrapped and paged. A long hover
            // tooltip previously covered the dialog while the mouse moved.
            JPWPresentationSetString(JPWRaizUI(suffix),OBJPROP_TOOLTIP,"\n");
           }
        }
     }
   if(content_height>0 && !g_details_rect.compact)
     {
      JPWRaizCreateLabel("FEEDBACK",g_raiz_feedback,x,footer_y-2*g_details_line);
      JPWRaizCreateLabel("PAGE","Página "+IntegerToString(g_raiz_page+1)+"/"+IntegerToString(g_raiz_pages)+
        (rows==0 ? " · Amplie o gráfico para editar" : ""),x,footer_y-g_details_line);
     }
   if(g_details_rect.compact)
     {
      JPWPresentationKeep(JPWRaizUI("BRAND_LOGO")); JPWPresentationKeep(JPWRaizUI("TITLE"));
      JPWGenetrixHeader(JPWRaizUI("BRAND_LOGO"),JPWRaizUI("TITLE"),x,top+g_details_pad,
         inner-close_size-g_details_pad,g_details_line,g_details_font,g_details_text,
         JPWPanelDarkBackground(background),legacy_title+" · "+IntegerToString(g_raiz_page+1)+"/"+IntegerToString(g_raiz_pages),4);
     }
   // Measured actions reflow before any label would be truncated.
   int legacy_footer_actions[4]={JPW_ACTION_LEGACY_CANCEL,JPW_ACTION_LEGACY_PREVIOUS,
      JPW_ACTION_LEGACY_NEXT,JPW_ACTION_LEGACY_APPLY};
   legacy_footer_labels[0]=(editing || g_raiz_tab==JPW_ROUTE_FACTOR ? "Cancelar" : "Fechar");
   legacy_footer_labels[3]=(g_raiz_tab==JPW_ROUTE_DECLARE ? "Justif." :
      (g_raiz_tab==JPW_ROUTE_JUSTIFY || g_raiz_tab==JPW_ROUTE_LEGACY_NF || g_raiz_tab==JPW_ROUTE_FACTOR ? "Aplicar" :
       (g_raiz_tab==JPW_ROUTE_BIND ? "Vincular" : "F")));
   if(rows>0 && JPWDialogFooterMinimum(legacy_footer_labels,4)<=inner)
     {
      int actions[2]={legacy_footer_actions[0],legacy_footer_actions[3]};
      string labels[2]={legacy_footer_labels[0],legacy_footer_labels[3]};
      JPWDialogFooterButtons(actions,labels,2,x,footer_y,inner);
      JPWDialogPager(x,footer_y-g_details_control-g_details_pad,inner,JPW_ACTION_LEGACY_PREVIOUS,JPW_ACTION_LEGACY_NEXT);
     }
   else JPWRaizCreateButton(JPW_ACTION_LEGACY_CANCEL,"Fechar",x,
      top+g_details_rect.height-g_details_pad-g_details_control,inner);
   g_raiz_panel_built=true; JPWFocusPaint();
  }

void JPWRenderRaizDetails()
  {
   if(!g_raiz_details_open || !JPWDetailsContextCurrent()) return;
   const string layout=IntegerToString((long)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS))+"|"+
      IntegerToString((long)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS))+"|"+
      IntegerToString((long)ChartGetInteger(0,CHART_COLOR_BACKGROUND))+"|"+
      DoubleToString(JPWUIDesignScale(),6)+"|"+IntegerToString(InpCockpitFontSize)+"|"+IntegerToString(g_raiz_tab)+"|"+JPWStoikusVisualEncode(g_stoikus_visual);
   const string content=JPWDialogContentKey();
   const bool layout_changed=(layout!=g_details_layout_key);
   if(g_raiz_panel_built && !g_details_content_dirty && !layout_changed && content==g_details_content_key) return;
   // Capture existing editor values before geometry or route reconstruction.
   // Content updates retain the same objects and do not reset a native caret.
   if(g_raiz_panel_built || g_details_owned_count>0) JPWRaizSaveVisibleFields();
   JPWUIDesignBeginPass(); JPWDialogFrameBegin();
   JPWRenderRaizDetailsBody(); JPWDialogFrameEnd(); JPWUIDesignEndPass();
   if(g_details_inventory_complete)
     { g_details_layout_key=layout; g_details_content_key=content; }
  }
#endif
