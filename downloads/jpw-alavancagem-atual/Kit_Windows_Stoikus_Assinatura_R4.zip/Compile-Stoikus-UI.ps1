#Requires -Version 5.1
# Stoikus 1.22.3-interface R4 candidate, compilation only.
# Run with Windows powershell.exe -NoProfile -STA -File this-script.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
# Exact R4 source freeze. Any subsequent source change requires a new seal.
$PinnedZipSha256='0b3d6b2ba9897a04262baf703282dfe84abdeb19ab26e39c3da21bf31e5855ef'
$PinnedCoreSha256='2dba568c184e31f1e28814c706d3e6a9459fe4e45524e33b52db14c0776ed542'
$PinnedFreezeSha256='8e43e6dc0e574083d9f3043f80b8aff3e4b87a99e38dd1c8d8217fb612ebdb6f'
$PinnedMqlFingerprint='b2b0afc9535816685decb8d5860a90fee35642b1ea3e6720523ecd8145c00d81'
$PinnedInterfaceFingerprint='ee9105007b390c05c51ca7165b86e4418662c062642063b65958bd454106349e'
$PinnedRuntimeBuildId='45beb82e9366197542bfa5c7084a28bc05dd6b155f5a3777fdaa95f15b67239d'
$expectedPrograms=@(
'MQL5/Experts/JPWealth/JPW_Stoikus_Monitor.mq5',
'MQL5/Indicators/JPWealth/JPW_Alavancagem_Atual.mq5',
'MQL5/Indicators/JPWealth/JPW_NoCuda_Channels.mq5',
'MQL5/Scripts/JPWealth/JPW_Stoikus_Abrir_Paineis.mq5'
)
$runRoot=$null;$resultDir=$null
$receipt=[ordered]@{
schema_version=1;candidate_version='1.22.3-interface';scope='COMPILE_ONLY_FOUR_DAILY_PROGRAMS'
started_utc=[DateTime]::UtcNow.ToString('o');finished_utc=$null
compilation_status='INCONCLUSIVE';installation_status='NAO_INSTALADO';runtime_status='NOT_RUN'
acceptance_status='NOT_RUN';independent_windows_x64='NOT_RUN'
run_root=$runRoot;origin=$null;os=$null;compiler=$null;terminal=$null
zip_validation=$null;standard_sources=@();programs=@();unchanged_inputs='NOT_CHECKED'
error=$null;results_zip_status='NOT_CREATED';destination_validation='NO_SAFE_STAGE_CREATED';rejected_destination=$null
}
$standard=[Collections.Generic.List[object]]::new()
$programResults=[Collections.Generic.List[object]]::new()
$payload=$null;$identity=$null;$payloadRoot=$null;$coreLoaded=$false
$compiler=$null;$terminal=$null;$compilerBefore=$null;$terminalBefore=$null
function Select-File([string]$Title,[string]$Filter,[string]$Initial,[string]$Name=''){
    $dialog=[Windows.Forms.OpenFileDialog]::new()
    try{
        $dialog.Title=$Title;$dialog.Filter=$Filter;$dialog.InitialDirectory=$Initial
        $dialog.FileName=$Name;$dialog.CheckFileExists=$true;$dialog.Multiselect=$false
        if($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){throw [OperationCanceledException]::new('Selecao cancelada; nenhum arquivo do terminal foi alterado.')}
        return [IO.Path]::GetFullPath($dialog.FileName)
    }finally{$dialog.Dispose()}
}
function Select-Mql5Folder{
    $dialog=[Windows.Forms.FolderBrowserDialog]::new()
    try{
        $dialog.Description='Escolha a pasta MQL5 JA EXISTENTE do terminal. Somente Include sera lido.'
        $dialog.ShowNewFolderButton=$false
        if($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){throw [OperationCanceledException]::new('Selecao de MQL5 cancelada.')}
        return [IO.Path]::GetFullPath($dialog.SelectedPath).TrimEnd([char]'\')
    }finally{$dialog.Dispose()}
}
try{
    if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'Windows required. No Windows/native result can be produced on this host.'}
    if([Threading.Thread]::CurrentThread.ApartmentState -ne [Threading.ApartmentState]::STA){throw 'Use powershell.exe -NoProfile -STA -File .\Compile-Stoikus-UI.ps1'}
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if($PSScriptRoot -notmatch '^[A-Za-z]:\\' -or ([IO.DriveInfo]::new([IO.Path]::GetPathRoot($PSScriptRoot))).DriveType -notin @([IO.DriveType]::Fixed,[IO.DriveType]::Removable)){throw 'Copy the complete kit to a local Windows folder before running. Network/UNC kit paths are not used.'}
    # Bootstrap is read-only. Never source an unpinned helper to validate TEMP.
    $corePath=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'NativeKit.Core.ps1'))
    $bootstrapPath=$corePath
    while($bootstrapPath){
        if(Test-Path -LiteralPath $bootstrapPath){
            if(((Get-Item -LiteralPath $bootstrapPath -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Bootstrap kit/helper has a reparse ancestor; nothing was created.'}
        }
        $bootstrapParent=[IO.Path]::GetDirectoryName($bootstrapPath.TrimEnd([char]'\'))
        if($bootstrapParent -eq $bootstrapPath){break}
        $bootstrapPath=$bootstrapParent
    }
    if($PinnedCoreSha256 -notmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath $corePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $PinnedCoreSha256){throw 'Root must pin the reviewed Core SHA-256 before bootstrap; no staging was created.'}
    . $corePath
    $coreLoaded=$true
    Assert-SafeLocalTree $PSScriptRoot -RequireExisting
    $tree=New-IsolatedRunDirectory ([IO.Path]::GetTempPath())
    $runRoot=$tree.run_root;$resultDir=$tree.results_dir;$receipt.run_root=$runRoot
    $receipt.destination_validation='VALIDATED_BEFORE_FIRST_WRITE_AND_AFTER_CREATE'
    $fixedIdentity=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'stoikus-1.22.3-interface.identity.json'))
    $identityPath=Select-File 'Selecione a identidade congelada entregue com ESTE kit' 'Identidade JSON (*.identity.json)|*.identity.json' $PSScriptRoot 'stoikus-1.22.3-interface.identity.json'
    if($identityPath -ine $fixedIdentity){throw 'A identidade deve ser stoikus-1.22.3-interface.identity.json na mesma pasta deste kit. Outro diretorio nao e aceito.'}
    if((Get-Item -LiteralPath $identityPath).Length -gt 1MB){throw 'Identity exceeds size cap.'}
    $identity=[IO.File]::ReadAllText($identityPath)|ConvertFrom-Json
    if($identity.schema_version -ne 1 -or $identity.kind -cne 'JPW_STOIKUS_UI_NATIVE_COMPILE_IDENTITY' -or $identity.candidate_version -cne '1.22.3-interface' -or $identity.frozen -isnot [bool] -or $identity.frozen -ne $true){throw 'Root-frozen 1.22.3-interface identity required; templates/pending identities cannot compile.'}
    if($identity.origin.generated_by -cne 'root' -or [string]::IsNullOrWhiteSpace($identity.origin.freeze_id)){throw 'Missing root freeze provenance.'}
    foreach($field in @('root_freeze_sha256','mql_source_fingerprint','interface_fingerprint','runtime_build_id')){
        if([string]$identity.origin.$field -notmatch '^[a-f0-9]{64}$'){throw "Unfilled/invalid origin field: $field"}
    }
    if([string]$identity.origin.baseline_commit -notmatch '^[a-f0-9]{40}$'){throw 'Invalid baseline commit in origin.'}
    if($identity.origin.calculation_version -cne '1.9.0'){throw 'Calculation version 1.9.0 required for this UI-only candidate.'}
    if($identity.origin.root_freeze_sha256 -cne $PinnedFreezeSha256 -or $identity.origin.mql_source_fingerprint -cne $PinnedMqlFingerprint -or $identity.origin.interface_fingerprint -cne $PinnedInterfaceFingerprint -or $identity.origin.runtime_build_id -cne $PinnedRuntimeBuildId){throw 'Identity does not match the independent R4 freeze pins.'}
    $freezePath=Join-Path $PSScriptRoot 'source-freeze-R4.json'
    Assert-NoReparsePath $freezePath
    if((Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $PinnedFreezeSha256){throw 'Source freeze bytes differ from R4 pin.'}
    $freeze=[IO.File]::ReadAllText($freezePath)|ConvertFrom-Json
    if($freeze.schema -cne 'JPW_STOIKUS_INTERFACE_FREEZE_V1' -or $freeze.candidate -cne '1.22.3-interface' -or $freeze.calculation_version -cne '1.9.0' -or $freeze.baseline_commit -cne $identity.origin.baseline_commit -or $freeze.mql_source_fingerprint -cne $PinnedMqlFingerprint -or $freeze.interface_fingerprint -cne $PinnedInterfaceFingerprint -or $freeze.runtime_build_id -cne $PinnedRuntimeBuildId){throw 'Source freeze content does not match R4 identity.'}
    $kitNames=@('Compile-Stoikus-UI.ps1','NativeKit.Core.ps1')
    if(@($identity.kit_files).Count -ne 2){throw 'Exactly two executable kit source hashes are required.'}
    foreach($name in $kitNames){
        $rows=@($identity.kit_files|Where-Object{$_.name -ceq $name})
        if($rows.Count -ne 1 -or [string]$rows[0].sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Missing/duplicate/invalid kit file hash.'}
        $actual=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -cne $rows[0].sha256){throw "Kit source SHA-256 differs from root freeze: $name"}
        if($name -ceq 'NativeKit.Core.ps1' -and ($PinnedCoreSha256 -notmatch '^[a-f0-9]{64}$' -or $actual -cne $PinnedCoreSha256)){throw 'Root must pin the reviewed Core SHA-256 in the runner before its functions can be loaded.'}
    }
    Assert-NoReparsePath $identityPath
    $receipt.origin=$identity.origin
    [IO.File]::Copy($identityPath,(Join-Path $resultDir 'input-identity.json'),$false)
    [IO.File]::Copy($freezePath,(Join-Path $resultDir 'input-source-freeze-R4.json'),$false)
    $fixedZip=Join-Path $PSScriptRoot 'JPW_Stoikus_Uso_Fontes_v1.22.3_interface.zip'
    if($identity.zip.filename -cne 'JPW_Stoikus_Uso_Fontes_v1.22.3_interface.zip' -or [string]$identity.zip.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Expected frozen UI usage ZIP name/SHA-256 required.'}
    if($PinnedZipSha256 -notmatch '^[a-f0-9]{64}$' -or $identity.zip.sha256 -cne $PinnedZipSha256){throw 'Root must pin this exact frozen ZIP digest in the reviewed runner. A self-reported sidecar is insufficient.'}
    $zipPath=Select-File 'Selecione o ZIP de interface 1.22.3 entregue com ESTE kit' 'Fontes ZIP (*.zip)|*.zip' $PSScriptRoot $identity.zip.filename
    if($zipPath -ine [IO.Path]::GetFullPath($fixedZip)){throw 'ZIP deve ficar na mesma pasta deste kit; outro diretorio nao e aceito.'}
    $payload=Open-ValidatedPayload $zipPath $identity
    $receipt.zip_validation=[ordered]@{status='VALIDATED_BEFORE_EXTRACTION';sha256=$payload.zip_sha256;bytes=$payload.stream.Length;inflate_bytes=$payload.inflate_bytes;entries=$payload.entries}
    foreach($entry in @($payload.entries|Where-Object{$_.path -clike 'MQL5/*'})){
        $freezeKey='mt5/jpw-alavancagem-atual/'+$entry.path
        $frozenEntry=$freeze.source_hashes.PSObject.Properties[$freezeKey]
        if($null -eq $frozenEntry -or [string]$frozenEntry.Value -cne [string]$entry.sha256){throw "Payload MQL5 bytes differ from the R4 source freeze: $freezeKey"}
    }
    if(@($identity.programs).Count -ne 4){throw 'Exactly four frozen usage programs are required.'}
    $actualPrograms=@($payload.entries|Where-Object{[IO.Path]::GetExtension($_.path) -ieq '.mq5'}|ForEach-Object{$_.path})
    if($actualPrograms.Count -ne 4){throw 'Source ZIP must contain exactly the four usage MQ5 programs.'}
    foreach($expected in $expectedPrograms){
        $p=@($identity.programs|Where-Object{$_.path -ceq $expected})
        $entry=@($payload.entries|Where-Object{$_.path -ceq $expected})
        if($p.Count -ne 1 -or $entry.Count -ne 1 -or [string]$p[0].sha256 -cne $entry[0].sha256){throw "Frozen program inventory differs: $expected"}
    }
    $payloadRoot=Join-Path $runRoot 'payload'
    Assert-SafeLocalTree $runRoot -RequireExisting
    Expand-ValidatedPayload $payload $payloadRoot
    Assert-SafeLocalTree $payloadRoot -RequireExisting
    $payload.archive.Dispose();$payload.stream.Dispose();$payload=$null
    $compilerPath=Select-File 'Escolha o MetaEditor JA INSTALADO (metaeditor64.exe)' 'MetaEditor executavel (*.exe)|*.exe' ([Environment]::GetFolderPath('ProgramFiles'))
    if([IO.Path]::GetFileName($compilerPath) -notin @('metaeditor64.exe','metaeditor.exe')){throw 'Choose the existing MetaEditor executable, not an installer.'}
    $compiler=Get-ExecutableIdentity $compilerPath
    if($compiler.company -notmatch 'MetaQuotes'){throw 'MetaEditor file metadata does not identify MetaQuotes; compiler not launched.'}
    $compilerBefore=$compiler.sha256;$receipt.compiler=$compiler
    Assert-NoRunningMetaEditor
    $terminalPath=Join-Path ([IO.Path]::GetDirectoryName($compilerPath)) 'terminal64.exe'
    if(-not (Test-Path -LiteralPath $terminalPath -PathType Leaf)){$terminalPath=Join-Path ([IO.Path]::GetDirectoryName($compilerPath)) 'terminal.exe'}
    if(-not (Test-Path -LiteralPath $terminalPath -PathType Leaf)){throw 'No terminal executable alongside selected MetaEditor. Choose the matching installed MetaEditor folder.'}
    $terminal=Get-ExecutableIdentity $terminalPath
    if($terminal.company -notmatch 'MetaQuotes'){throw 'Terminal metadata does not identify MetaQuotes; terminal is never launched.'}
    $terminalBefore=$terminal.sha256;$receipt.terminal=$terminal
    $os=Get-CimInstance Win32_OperatingSystem
    $computer=Get-CimInstance Win32_ComputerSystem
    $osMachine='UNKNOWN'
    if($computer.SystemType -match 'ARM64'){$osMachine='ARM64'}elseif($computer.SystemType -match 'x64'){$osMachine='X64'}elseif($computer.SystemType -match 'x86'){$osMachine='X86'}
    $emulation='UNKNOWN'
    if($osMachine -eq 'ARM64' -and $compiler.pe_machine -in @('X64','X86')){$emulation='INFERRED_FROM_ARM64_OS_AND_COMPILER_PE'}
    elseif($osMachine -ne 'UNKNOWN' -and $compiler.pe_machine -eq $osMachine){$emulation='NO_CROSS_ARCHITECTURE_INDICATED_BY_METADATA'}
    $receipt.os=[ordered]@{caption=$os.Caption;version=$os.Version;build=$os.BuildNumber;reported_os_architecture=$os.OSArchitecture;system_type=$computer.SystemType;manufacturer=$computer.Manufacturer;model=$computer.Model;os_machine=$osMachine;process_environment_architecture=$env:PROCESSOR_ARCHITECTURE;compiler_emulation=$emulation;process_emulation_observed='UNKNOWN';ex5_architecture='UNKNOWN';platforms_not_equivalent=$true}
    $selectedMql5=Select-Mql5Folder
    $stageMql5=Join-Path $payloadRoot 'MQL5'
    Copy-StandardClosure $stageMql5 $selectedMql5 $expectedPrograms $standard
    $receipt.standard_sources=$standard.ToArray()
    foreach($program in $expectedPrograms){
        Assert-SafeLocalTree $runRoot -RequireExisting
        Assert-SafeLocalTree $stageMql5 -RequireExisting
        Assert-NoRunningMetaEditor
        $source=Get-PathUnderRoot $payloadRoot $program.Replace('/','\')
        $ex5=[IO.Path]::ChangeExtension($source,'.ex5')
        $log=[IO.Path]::ChangeExtension($source,'.log')
        if((Test-Path -LiteralPath $ex5) -or (Test-Path -LiteralPath $log)){throw 'Compiler outputs must not preexist in fresh staging.'}
        $row=[ordered]@{path=$program;source_sha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant();status='NOT_RUN';started_utc=$null;spawned_pid=$null;exit_code=$null;timeout_action=$null;log_sha256=$null;log_result=$null;ex5_sha256=$null;ex5_bytes=$null;ex5_architecture='UNKNOWN';artifacts=$null;capture_error=$null}
        $programResults.Add($row)
        $receipt.programs=$programResults.ToArray()
        $start=[DateTime]::UtcNow;$row.started_utc=$start.ToString('o')
        $psi=[Diagnostics.ProcessStartInfo]::new()
        $psi.FileName=$compiler.path
        $psi.Arguments='/compile:"'+$source+'" /include:"'+$stageMql5+'" /log'
        $psi.UseShellExecute=$false;$psi.WorkingDirectory=$runRoot
        $process=[Diagnostics.Process]::new();$process.StartInfo=$psi
        $recordedStart=[DateTime]::MinValue
        try{
            if(-not $process.Start()){throw 'MetaEditor process could not start.'}
            $row.spawned_pid=$process.Id;$row.status='RUNNING'
            try{$recordedStart=$process.StartTime.ToUniversalTime()}catch{}
            if(-not $process.WaitForExit(240000)){
                $row.timeout_action=Stop-OwnedCompiler $process $compiler.path $recordedStart
                $row.status='FAIL_TIMEOUT'
                throw 'Compilation timeout. Only this spawned PID may be stopped after path/start-time identity verification; existing processes are never killed.'
            }
            $row.exit_code=$process.ExitCode;$row.status='EXITED_UNVERIFIED'
        }catch{
            if($row.status -ne 'FAIL_TIMEOUT'){$row.status='FAIL'}
            throw
        }finally{
            # Runs even when timeout/start/exit throws. Collection cannot promote status.
            $mayStillWrite=$true
            try{if($row.spawned_pid){$mayStillWrite=-not $process.HasExited}}catch{}
            try{
                Assert-SafeLocalTree $runRoot -RequireExisting
                Assert-SafeLocalTree $resultDir -RequireExisting
                $row.artifacts=Save-CompilerOutputs $log $ex5 $resultDir $mayStillWrite
                $row.log_sha256=$row.artifacts.log.sha256
                $row.ex5_sha256=$row.artifacts.ex5.sha256
                $row.ex5_bytes=$row.artifacts.ex5.captured_bytes
                if($row.artifacts.log.status -eq 'COPIED_STABLE'){
                    $row.log_result=Test-CompileLog ([IO.File]::ReadAllText($row.artifacts.log.result_path)) $source
                }
            }catch{
                $row.capture_error=$_.Exception.Message
                if($row.status -ne 'FAIL_TIMEOUT'){$row.status='FAIL'}
            }
            $process.Dispose();$receipt.programs=$programResults.ToArray()
        }
        $row.status='FAIL'
        if($row.exit_code -ne 0 -or $row.capture_error -or $null -eq $row.artifacts -or $row.artifacts.log.status -ne 'COPIED_STABLE' -or $row.artifacts.ex5.status -ne 'COPIED_STABLE' -or $null -eq $row.log_result -or -not $row.log_result.accepted -or $null -eq $row.ex5_sha256 -or $row.ex5_bytes -le 0){throw "Missing/failed/unknown native compile evidence for $program; no PASS."}
        if([DateTime]::Parse($row.artifacts.ex5.source_last_write_utc).ToUniversalTime() -lt $start.AddSeconds(-2)){throw 'EX5 does not have a fresh compiler-output timestamp.'}
        $row.status='COMPILED'
        $row.artifacts.log.evidence='COMPLETE_COMPILE_OUTPUT'
        $row.artifacts.ex5.evidence='COMPLETE_COMPILE_OUTPUT'
    }
    if($programResults.Count -ne 4 -or @($programResults|Where-Object{$_.status -ne 'COMPILED'}).Count -gt 0){throw 'Four complete fresh native compilation results required.'}
    $receipt.compilation_status='COMPILADO'
}catch{
    if($_.Exception -is [OperationCanceledException]){$receipt.compilation_status='CANCELADO'}
    else{$receipt.compilation_status='FAIL'}
    $receipt.error=$_.Exception.Message
    if($_.Exception.Data.Contains('candidate_run_root')){$receipt.rejected_destination=[string]$_.Exception.Data['candidate_run_root']}
}finally{
    if($payload){$payload.archive.Dispose();$payload.stream.Dispose()}
    $safeResults=$false
    if($coreLoaded -and $runRoot -and $resultDir){
        try{
            Assert-SafeLocalTree $runRoot -RequireExisting
            Assert-SafeLocalTree $resultDir -RequireExisting
            if($payloadRoot){Assert-SafeLocalTree $payloadRoot}
            $safeResults=$true
        }catch{$receipt.compilation_status='FAIL';$receipt.destination_validation='REVALIDATION_FAILED_NO_FURTHER_WRITES';$receipt.error='Destination no longer proved local/regular; no further writes. '+$_.Exception.Message}
    }
    $unchanged=$true
    if($safeResults -and $payloadRoot -and (Test-Path -LiteralPath $payloadRoot)){
        try{
            foreach($entry in @($identity.entries)){
                $file=Get-PathUnderRoot $payloadRoot (([string]$entry.path).Replace('/','\'))
                Assert-NoReparsePath $file
                if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$entry.sha256){$unchanged=$false}
            }
            foreach($header in $standard){
                Assert-LocalWindowsPath $header.source_path
                Assert-NoReparsePath $header.source_path
                Assert-NoReparsePath $header.stage_path
                $header.after_sha256=(Get-FileHash -LiteralPath $header.source_path -Algorithm SHA256).Hash.ToLowerInvariant()
                $stageHash=(Get-FileHash -LiteralPath $header.stage_path -Algorithm SHA256).Hash.ToLowerInvariant()
                if($header.after_sha256 -cne $header.before_sha256 -or $stageHash -cne $header.before_sha256){$unchanged=$false}
            }
            if($compilerBefore -and (Get-FileHash -LiteralPath $compiler.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $compilerBefore){$unchanged=$false}
            if($terminalBefore -and (Get-FileHash -LiteralPath $terminal.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $terminalBefore){$unchanged=$false}
            $receipt.unchanged_inputs=if($unchanged){'VERIFIED'}else{'FAIL'}
        }catch{$receipt.unchanged_inputs='INCONCLUSIVE';$unchanged=$false}
        if(-not $unchanged -and $receipt.compilation_status -eq 'COMPILADO'){$receipt.compilation_status='FAIL';$receipt.error='Inputs changed or final source/hash verification was inconclusive.'}
    }
    $receipt.standard_sources=$standard.ToArray();$receipt.programs=$programResults.ToArray()
    $receipt.finished_utc=[DateTime]::UtcNow.ToString('o')
    if($safeResults){try{
        $receiptPath=Join-Path $resultDir 'receipt.json'
        Assert-FlatResultsDirectory $resultDir
        $receipt.results_zip_status='CREATING'
        [IO.File]::WriteAllText($receiptPath,($receipt|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
        $zipResult=Join-Path $runRoot 'results.zip'
        [IO.Compression.ZipFile]::CreateFromDirectory($resultDir,$zipResult,[IO.Compression.CompressionLevel]::Optimal,$false)
        $receipt.results_zip_status='CREATED'
        [IO.File]::WriteAllText($receiptPath,($receipt|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
        # Rebuild once so the ZIP includes the final receipt; only our own fresh result ZIP is replaced.
        [IO.File]::Delete($zipResult)
        [IO.Compression.ZipFile]::CreateFromDirectory($resultDir,$zipResult,[IO.Compression.CompressionLevel]::Optimal,$false)
    }catch{
        $receipt.results_zip_status='FAIL'
        $receipt.compilation_status='FAIL'
        $receipt.error='Result packaging failed; diagnostic folder and raw outputs remain preserved. '+$_.Exception.Message
        try{Assert-FlatResultsDirectory $resultDir;Assert-NoReparsePath $receiptPath;[IO.File]::WriteAllText($receiptPath,($receipt|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))}catch{}
        Write-Host 'Results ZIP could not be completed. Diagnostic directory is preserved.'
    }}else{$receipt.results_zip_status='NOT_CREATED_NO_SAFE_DESTINATION'}
}
Write-Host ('Resultado: '+$receipt.compilation_status+' | NAO_INSTALADO | RUNTIME_NOT_RUN')
if($runRoot){
    Write-Host ('Pasta preservada: '+$runRoot)
    if($receipt.results_zip_status -eq 'CREATED'){Write-Host ('Para enviar o resultado: '+(Join-Path $runRoot 'results.zip'))}
    else{Write-Host 'ZIP indisponivel/incompleto. Envie a mensagem de falha; a pasta de diagnostico permanece preservada.'}
}else{Write-Host 'Nenhuma pasta de staging foi aprovada. Diagnostico somente nesta janela; nao foram gravados arquivos no TEMP recusado.'}
if($receipt.error){Write-Host ('Detalhe: '+$receipt.error)}
if($runRoot -and ('Windows.Forms.MessageBox' -as [type])){
    $handoff=if($receipt.results_zip_status -eq 'CREATED'){'Envie results.zip desta pasta:'}else{'ZIP indisponivel/incompleto; envie a mensagem de falha. Pasta preservada:'}
    [Windows.Forms.MessageBox]::Show(('Resultado: '+$receipt.compilation_status+[Environment]::NewLine+'NAO_INSTALADO; runtime nao executado.'+[Environment]::NewLine+$handoff+[Environment]::NewLine+$runRoot),'Stoikus 1.22.3-interface - compilacao isolada') | Out-Null
}
if($receipt.compilation_status -ne 'COMPILADO'){exit 1}

