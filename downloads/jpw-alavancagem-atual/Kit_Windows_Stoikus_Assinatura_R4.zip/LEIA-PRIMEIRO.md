# Stoikus 1.22.3-interface — kit R4 de compilação

**Fontes R4 seladas para compilação isolada.** O gate host desta revisão exige seu próprio recibo; PowerShell Windows, MetaEditor e MT5 continuam `NOT_RUN`. Este kit compila os quatro programas de uso diário em uma pasta temporária local. Ele não instala EX5, não abre o terminal e não envia ordens. O candidato é `1.22.3-interface`; cálculo `1.9.0`; `runtimeBuildId` `45beb82e9366197542bfa5c7084a28bc05dd6b155f5a3777fdaa95f15b67239d`; fingerprint da interface `ee9105007b390c05c51ca7165b86e4418662c062642063b65958bd454106349e`. O ZIP privado de fontes é `JPW_Stoikus_Uso_Fontes_v1.22.3_interface.zip`, SHA-256 `0b3d6b2ba9897a04262baf703282dfe84abdeb19ab26e39c3da21bf31e5855ef`. O prefácio do `LEIA_PRIMEIRO.md` **dentro desse ZIP** explica a sequência compilação temporária → revisão do recibo → ensaio demo; suas instruções de instalação padrão pertencem somente à etapa posterior em ambiente isolado. O pacote histórico 1.22.2/R3 não identifica esta assinatura R4.

## Antes de executar qualquer script

Receba `Kit_Windows_Stoikus_Assinatura_R4.zip` e, **separadamente**, `root-pin-R4.json`. Extraia o ZIP numa pasta local nova `sealed-R4` e copie o pin externo para **dentro dessa pasta extraída** antes da conferência. O pin não vem dentro do ZIP. O inventário completo de arquivos do kit, além do pin, é: `Compile-Stoikus-UI.ps1`, `NativeKit.Core.ps1`, `Test-NativeUI-Kit.ps1`, `stoikus-1.22.3-interface.identity.json`, `JPW_Stoikus_Uso_Fontes_v1.22.3_interface.zip`, `source-freeze-R4.json`, `identity.schema.json`, `LEIA-PRIMEIRO.md` e `verify_native_ui_kit.py`. Arquivos adicionais, ausentes ou com SHA-256 divergente exigem parar. O verificador Python é auxiliar para revisão local; **Python não é necessário no Windows**.

Abra `sealed-R4` no Explorador, clique na barra de endereço, digite `powershell.exe -NoProfile -STA` e Enter. Cole este bloco para conferir, com o `Get-FileHash` do próprio Windows, **todos** os arquivos contra o pin recebido separadamente. A última linha deve mostrar `PASS: inventario e SHA-256 ...`; se houver erro ou diferença, pare sem executar o runner.

```powershell
$kit = (Get-Location).ProviderPath
$pinPath = Join-Path $kit 'root-pin-R4.json'
$pin = Get-Content -LiteralPath $pinPath -Raw | ConvertFrom-Json
if ($pin.kind -cne 'JPW_STOIKUS_UI_NATIVE_KIT_ROOT_PIN' -or $pin.candidate -cne '1.22.3-interface' -or $pin.status -cne 'SEALED_SOURCE_ONLY') { throw 'Pin errado ou ainda nao selado.' }
$items = @(Get-ChildItem -LiteralPath $kit -Force)
if (@($items | Where-Object { $_.PSIsContainer }).Count -ne 0) { throw 'Pasta adicional no kit.' }
$expected = @($pin.files_sha256.PSObject.Properties.Name | Sort-Object)
$actual = @($items | Where-Object { $_.Name -cne 'root-pin-R4.json' } | ForEach-Object { $_.Name } | Sort-Object)
$difference = @(Compare-Object -ReferenceObject $expected -DifferenceObject $actual)
if ($difference.Count -ne 0) { $difference | Format-Table; throw 'Inventario do kit diferente do pin.' }
foreach ($entry in $pin.files_sha256.PSObject.Properties) {
    $file = Join-Path $kit $entry.Name
    if (((Get-Item -LiteralPath $file -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link recusado: $($entry.Name)" }
    $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLowerInvariant()
    if ($actualHash -cne [string]$entry.Value) { throw "SHA-256 diferente: $($entry.Name)" }
}
Write-Host 'PASS: inventario e SHA-256 de todos os arquivos conferidos.'
```

O root pin lista o novo `runtimeBuildId`, fingerprint da interface e hashes da identidade, freeze, ZIP e scripts. Ele é entregue fora do ZIP para evitar que o pacote se aprove sozinho; copiar o pin para a pasta extraída facilita a conferência local.

## Primeiro: fixtures PowerShell

Salve o trabalho e feche o MetaEditor, caso esteja aberto. O runner de fixtures usa apenas dados sintéticos e uma pasta temporária própria; não abre MetaEditor/MT5. Na mesma janela PowerShell, depois do `PASS` de hashes, execute:

```powershell
powershell.exe -NoProfile -STA -ExecutionPolicy RemoteSigned -File '.\Test-NativeUI-Kit.ps1' 2>&1 | Tee-Object -FilePath '..\fixture-R4.log'
if ($LASTEXITCODE -ne 0) { throw 'Fixtures falharam; preserve fixture-R4.log e pare.' }
```

Guarde `fixture-R4.log` e a pasta temporária indicada. Confira a linha final com passados, falhas e pulados. `FAIL` impede a compilação; `SKIP` exige registrar qual teste não rodou e seu efeito antes de seguir. Um resultado de fixtures não comprova compilação nem execução MT5. **Até executar no Windows, este gate é `NOT_RUN`.** Se a política local bloquear scripts, anote a mensagem; não altere a política global. `RemoteSigned` acima vale só para aquele processo.

## Depois: compilar sem instalar

Ainda na pasta `sealed-R4`, execute:

```powershell
powershell.exe -NoProfile -STA -ExecutionPolicy RemoteSigned -File '.\Compile-Stoikus-UI.ps1'
```

Escolha a identidade e o ZIP da própria pasta; depois o `metaeditor64.exe` já instalado e a pasta `MQL5` existente. Se não souber qual instalação está escolhendo, registre o ponto e pare. O kit lê apenas os Includes padrão necessários, grava em staging temporário novo e não lê `MQL5/Files` nem dados de conta. Guarde `results.zip` e o caminho da pasta diagnóstica, inclusive em falha. `COMPILADO` exige quatro EX5 novos e quatro logs completos com zero erros/avisos; antes do ensaio demo, confira o recibo e os hashes. Não copie EX5 para a instalação de uso.

## Ensaio posterior: demo isolada e igualdade dos EX5

O proprietário informou que possui MT5 de testes separado. Antes de instalar nele, registre os **caminhos exatos** do executável e da pasta de dados, o build em Ajuda → Sobre, a conta demo (sem expor login completo) e confirme que essa pasta de dados difere da instalação de uso. Uma troca de conta na instalação de uso não isola arquivos. Negociação algorítmica fica desabilitada; não envie ordens. Se a separação não for demonstrada, o ensaio permanece `NOT_RUN`.

Antes de copiar qualquer EX5, extraia `results.zip` em pasta local de leitura e execute o primeiro bloco **a partir da pasta `sealed-R4`**, na mesma janela PowerShell usada na conferência do pin. Substitua apenas os dois caminhos nas primeiras linhas. Ele exige que o recibo `COMPILADO` corresponda à identidade R4 verificada: origem completa, ZIP validado, quatro caminhos/hashes de fonte e entradas intactas. Campo ausente, entrada adicional ou outro freeze exigem parar sem copiar. Só após o `PASS: recibo R4` copie os quatro EX5 **somente** para a pasta demo isolada e execute o segundo bloco **na mesma janela PowerShell** para comparar os arquivos; qualquer diferença interrompe a abertura dos gráficos.

```powershell
$results = 'C:\CAMINHO\results-extraidos'
$demoMql5 = 'C:\CAMINHO\MT5-TESTE\MQL5'
$kit = (Get-Location).ProviderPath
$pin = Get-Content -LiteralPath (Join-Path $kit 'root-pin-R4.json') -Raw | ConvertFrom-Json
$identityPath = Join-Path $kit 'stoikus-1.22.3-interface.identity.json'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $identityPath).Hash.ToLowerInvariant() -cne [string]$pin.files_sha256.'stoikus-1.22.3-interface.identity.json') { throw 'Identidade R4 difere do pin externo; pare.' }
$identity = Get-Content -LiteralPath $identityPath -Raw | ConvertFrom-Json
$receipt = Get-Content -LiteralPath (Join-Path $results 'receipt.json') -Raw | ConvertFrom-Json
if ($identity.kind -cne 'JPW_STOIKUS_UI_NATIVE_COMPILE_IDENTITY' -or $identity.frozen -cne $true -or $identity.candidate_version -cne '1.22.3-interface') { throw 'Identidade selada R4 invalida; pare.' }
if ($receipt.schema_version -ne 1 -or $receipt.scope -cne 'COMPILE_ONLY_FOUR_DAILY_PROGRAMS' -or $receipt.compilation_status -cne 'COMPILADO' -or $receipt.candidate_version -cne $identity.candidate_version -or $receipt.unchanged_inputs -cne 'VERIFIED') { throw 'Recibo nao comprova compilacao completa com entradas intactas; pare.' }
$originFields = @('generated_by','freeze_id','root_freeze_sha256','mql_source_fingerprint','interface_fingerprint','runtime_build_id','calculation_version','baseline_commit')
if ($null -eq $receipt.origin -or @($receipt.origin.PSObject.Properties).Count -ne $originFields.Count) { throw 'Origem ausente/incompleta/adicional no recibo; pare.' }
foreach ($field in $originFields) {
    if ($null -eq $receipt.origin.PSObject.Properties[$field] -or [string]$receipt.origin.$field -cne [string]$identity.origin.$field) { throw "Origem de outro freeze ou divergente: $field; pare." }
}
if ($identity.origin.freeze_id -cne 'stoikus-interface-R4' -or $identity.origin.root_freeze_sha256 -cne [string]$pin.root_freeze_sha256 -or $identity.origin.mql_source_fingerprint -cne [string]$pin.mql_source_fingerprint -or $identity.origin.interface_fingerprint -cne [string]$pin.interface_fingerprint -or $identity.origin.runtime_build_id -cne [string]$pin.runtime_build_id -or $identity.origin.calculation_version -cne [string]$pin.calculation_version) { throw 'Identidade R4 e pin externo divergem; pare.' }
if ($receipt.zip_validation.status -cne 'VALIDATED_BEFORE_EXTRACTION' -or $receipt.zip_validation.sha256 -cne $identity.zip.sha256 -or $identity.zip.sha256 -cne [string]$pin.source_zip_sha256) { throw 'ZIP de fontes do recibo nao corresponde ao selo R4; pare.' }
$pairs = @(
    @{path='MQL5/Experts/JPWealth/JPW_Stoikus_Monitor.mq5'; name='JPW_Stoikus_Monitor.ex5'; target='Experts\JPWealth\JPW_Stoikus_Monitor.ex5'},
    @{path='MQL5/Indicators/JPWealth/JPW_Alavancagem_Atual.mq5'; name='JPW_Alavancagem_Atual.ex5'; target='Indicators\JPWealth\JPW_Alavancagem_Atual.ex5'},
    @{path='MQL5/Indicators/JPWealth/JPW_NoCuda_Channels.mq5'; name='JPW_NoCuda_Channels.ex5'; target='Indicators\JPWealth\JPW_NoCuda_Channels.ex5'},
    @{path='MQL5/Scripts/JPWealth/JPW_Stoikus_Abrir_Paineis.mq5'; name='JPW_Stoikus_Abrir_Paineis.ex5'; target='Scripts\JPWealth\JPW_Stoikus_Abrir_Paineis.ex5'}
)
if (@($identity.programs).Count -ne 4 -or @($receipt.programs).Count -ne 4) { throw 'Inventario de programas ausente ou adicional; pare.' }
foreach ($pair in $pairs) {
    $expected = @($identity.programs | Where-Object { $_.path -ceq $pair.path })
    $rows = @($receipt.programs | Where-Object { $_.path -ceq $pair.path })
    if ($expected.Count -ne 1 -or $rows.Count -ne 1 -or $rows[0].source_sha256 -cne $expected[0].sha256 -or $rows[0].status -cne 'COMPILED') { throw "Fonte, status ou inventario diferente: $($pair.path); pare." }
    $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $results $pair.name)).Hash.ToLowerInvariant()
    if ($rows[0].ex5_sha256 -cne $sourceHash) { throw "EX5 de origem nao corresponde ao recibo: $($pair.name); pare." }
}
Write-Host 'PASS: recibo R4 vinculado ao freeze, ZIP e quatro fontes. Agora copie os EX5 somente para a instalacao demo isolada.'
```

Depois da cópia para a pasta demo, ainda na **mesma janela PowerShell**, execute:

```powershell
foreach ($pair in $pairs) {
    $source = Join-Path $results $pair.name
    $destination = Join-Path $demoMql5 $pair.target
    $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash.ToLowerInvariant()
    $destinationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $destination).Hash.ToLowerInvariant()
    $row = @($receipt.programs | Where-Object { $_.path -ceq $pair.path })[0]
    if ($row.ex5_sha256 -cne $sourceHash -or $sourceHash -cne $destinationHash) { throw "EX5/recibo diferente; pare: $($pair.name)" }
    Write-Host "PASS $($pair.name) $sourceHash"
}
```

O recibo também deve registrar esses mesmos hashes de EX5. Após a igualdade e isolamento comprovados, siga o ensaio do plano em dois gráficos vazios: Monitor no gráfico de apoio; Conta + NoCuda no gráfico de trabalho pelo abridor. Registre logs/capturas datados de layout, texto/foco, teclado, sete métricas, Histórico e fluxo Selecionar canal → Conferir prévia → Confirmar vínculo, inclusive bloqueios sem dados suficientes. Use somente dados demo/sintéticos. Windows ARM sob emulação não substitui prova independente em Windows x64. Compilação, instalação, runtime e aceite são estados distintos.
