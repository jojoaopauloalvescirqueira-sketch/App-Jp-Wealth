#Requires -Version 5.1
# Stoikus 1.22.3-interface R4 Core/identity fixtures. Never opens MetaEditor or MT5.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$PinnedCoreSha256='2dba568c184e31f1e28814c706d3e6a9459fe4e45524e33b52db14c0776ed542'
$corePath=Join-Path $PSScriptRoot 'NativeKit.Core.ps1'
if($PinnedCoreSha256 -notmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath $corePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $PinnedCoreSha256){throw 'Reviewed Core SHA-256 required before loading fixtures.'}
. $corePath
Add-Type -AssemblyName System.IO.Compression
$fixtureTree=New-IsolatedRunDirectory ([IO.Path]::GetTempPath())
$root=$fixtureTree.run_root
$passed = 0
$failed = 0
$skipped = 0
function Check($Name, [scriptblock]$Body) {
    try { & $Body; $script:passed++; Write-Host "PASS $Name" }
    catch {
        if($_.Exception -is [NotSupportedException]){$script:skipped++;Write-Host "SKIP $Name : $($_.Exception.Message)"}
        else{$script:failed++;Write-Host "FAIL $Name : $($_.Exception.Message)"}
    }
}
function Must-Throw([scriptblock]$Body) {
    $caught = $false
    try { & $Body | Out-Null } catch { $caught = $true }
    if (-not $caught) { throw 'Expected rejection did not occur.' }
}
function Make-Zip($Name, $Items) {
    $path = Join-Path $root $Name
    $fs = [IO.File]::Open($path, [IO.FileMode]::CreateNew)
    $z = [IO.Compression.ZipArchive]::new($fs, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($item in $Items) {
            $e = $z.CreateEntry($item.name)
            if ($item.ContainsKey('attributes')) { $e.ExternalAttributes = [int]$item.attributes }
            $stream = $e.Open()
            try { $bytes = [Text.Encoding]::UTF8.GetBytes($item.text); $stream.Write($bytes,0,$bytes.Length) }
            finally { $stream.Dispose() }
        }
    } finally { $z.Dispose(); $fs.Dispose() }
    $entries = @($Items | ForEach-Object { [pscustomobject]@{path=$_.name;bytes=[Text.Encoding]::UTF8.GetByteCount($_.text);sha256=Get-BytesSha256 ([Text.Encoding]::UTF8.GetBytes($_.text))} })
    return [pscustomobject]@{path=$path;identity=[pscustomobject]@{zip=[pscustomobject]@{bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()};entries=$entries}}
}
Check 'R4 sealed identity and source ZIP match before synthetic fixtures' {
    $identityPath=Join-Path $PSScriptRoot 'stoikus-1.22.3-interface.identity.json'
    $freezePath=Join-Path $PSScriptRoot 'source-freeze-R4.json'
    $runnerPath=Join-Path $PSScriptRoot 'Compile-Stoikus-UI.ps1'
    $identity=Get-Content -LiteralPath $identityPath -Raw | ConvertFrom-Json
    $freeze=Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
    if($identity.kind -cne 'JPW_STOIKUS_UI_NATIVE_COMPILE_IDENTITY' -or $identity.candidate_version -cne '1.22.3-interface' -or $identity.frozen -ne $true){throw 'R4 identity is not frozen for this candidate.'}
    $freezeSha=(Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if($freezeSha -cne [string]$identity.origin.root_freeze_sha256 -or $freeze.interface_fingerprint -cne $identity.origin.interface_fingerprint -or $freeze.runtime_build_id -cne $identity.origin.runtime_build_id){throw 'R4 freeze, identity or build differs.'}
    $runner=[IO.File]::ReadAllText($runnerPath)
    foreach($pin in @(@('PinnedCoreSha256',$PinnedCoreSha256),@('PinnedZipSha256',[string]$identity.zip.sha256),@('PinnedFreezeSha256',$freezeSha),@('PinnedInterfaceFingerprint',[string]$identity.origin.interface_fingerprint),@('PinnedRuntimeBuildId',[string]$identity.origin.runtime_build_id))){
        if(-not $runner.Contains('$'+$pin[0]+"='"+$pin[1]+"'")){throw 'Runner R4 pin does not match identity: '+$pin[0]}
    }
    $zipPath=Join-Path $PSScriptRoot 'JPW_Stoikus_Uso_Fontes_v1.22.3_interface.zip'
    $validated=Open-ValidatedPayload $zipPath $identity
    try{if(@($validated.entries).Count -ne @($identity.entries).Count){throw 'R4 inventory count differs.'}}
    finally{$validated.archive.Dispose();$validated.stream.Dispose()}
}
Check 'Accept ordinary relative source path' { Assert-SafeRelativePath 'MQL5/Include/JPWealth/Value.mqh' | Out-Null }
foreach ($bad in @('../escape','/absolute','C:/drive','MQL5/a:ads','MQL5/CON.mqh','MQL5/trailing.','MQL5/trailing ','MQL5//empty','MQL5\backslash','MQL5/./dot')) {
    Check ("Reject unsafe path " + $bad) { Must-Throw { Assert-SafeRelativePath $bad } }
}
Check 'ZIP content accepted only after inventory hash verification' {
    $v=Make-Zip 'valid.zip' @(@{name='MQL5/Include/JPWealth/a.mqh';text='sample'})
    $p=Open-ValidatedPayload $v.path $v.identity
    try { if (@($p.entries).Count -ne 1) { throw 'Missing inventory.' } } finally { $p.archive.Dispose(); $p.stream.Dispose() }
}
Check 'ZIP traversal rejected before extraction' {
    $v=Make-Zip 'traversal.zip' @(@{name='../outside.mqh';text='x'})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Windows case-insensitive duplicate rejected' {
    $v=Make-Zip 'duplicate.zip' @(@{name='MQL5/Include/a.mqh';text='x'},@{name='mql5/include/A.mqh';text='y'})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Unix symlink entry rejected' {
    $v=Make-Zip 'symlink.zip' @(@{name='MQL5/link.mqh';text='target';attributes=-1610612736})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Prior compiled EX5 is rejected' {
    $v=Make-Zip 'prior-ex5.zip' @(@{name='MQL5/Experts/old.ex5';text='old'})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'MQL5 Files entries are never copied' {
    $v=Make-Zip 'mql-files.zip' @(@{name='MQL5/Files/bank.csv';text='not a compile input'})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Declared inventory mismatch rejected' {
    $v=Make-Zip 'wrong-sha.zip' @(@{name='MQL5/Include/a.mqh';text='x'})
    $v.identity.entries[0].sha256=('0'*64)
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Declared inflate length mismatch rejected' {
    $v=Make-Zip 'wrong-size.zip' @(@{name='MQL5/Include/a.mqh';text='x'})
    $v.identity.entries[0].bytes=2
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'File and ancestor collision rejected before extraction' {
    $v=Make-Zip 'ancestor.zip' @(@{name='MQL5/Include/a.mqh';text='x'},@{name='MQL5/Include/a.mqh/child.mqh';text='y'})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Inflate ratio above 1000:1 rejected' {
    $v=Make-Zip 'ratio.zip' @(@{name='MQL5/Include/bomb.mqh';text=('0'*2MB)})
    Must-Throw { Open-ValidatedPayload $v.path $v.identity }
}
Check 'Transitive standard quoted include copied without changing originals' {
    $selected=Join-Path $root 'selected\MQL5'
    $staged=Join-Path $root 'closure\MQL5'
    [IO.Directory]::CreateDirectory((Join-Path $selected 'Include\Canvas')) | Out-Null
    [IO.Directory]::CreateDirectory((Join-Path $staged 'Indicators\JPWealth')) | Out-Null
    [IO.Directory]::CreateDirectory((Join-Path $staged 'Include\JPWealth')) | Out-Null
    $object=Join-Path $selected 'Include\Object.mqh'
    [IO.File]::WriteAllText($object,'// selected standard base')
    [IO.File]::WriteAllText((Join-Path $selected 'Include\Canvas\Canvas.mqh'),'#include "..\Object.mqh"')
    [IO.File]::WriteAllText((Join-Path $staged 'Indicators\JPWealth\P.mq5'),'#include <Canvas\Canvas.mqh>')
    $before=(Get-FileHash -LiteralPath $object).Hash
    $records=[Collections.Generic.List[object]]::new()
    Copy-StandardClosure $staged $selected @('MQL5/Indicators/JPWealth/P.mq5') $records
    if($records.Count -ne 2 -or -not (Test-Path -LiteralPath (Join-Path $staged 'Include\Object.mqh'))){throw 'Transitive dependency missing.'}
    if((Get-FileHash -LiteralPath $object).Hash -cne $before){throw 'Original standard source changed.'}
}
Check 'Installed JPWealth never fills a missing frozen project include' {
    $selected=Join-Path $root 'selected\MQL5'
    $staged=Join-Path $root 'missing\MQL5'
    [IO.Directory]::CreateDirectory((Join-Path $selected 'Include\JPWealth')) | Out-Null
    [IO.Directory]::CreateDirectory((Join-Path $staged 'Indicators\JPWealth')) | Out-Null
    [IO.Directory]::CreateDirectory((Join-Path $staged 'Include\JPWealth')) | Out-Null
    [IO.File]::WriteAllText((Join-Path $selected 'Include\JPWealth\stale.mqh'),'// stale installed project')
    [IO.File]::WriteAllText((Join-Path $staged 'Indicators\JPWealth\Q.mq5'),'#include <JPWealth\stale.mqh>')
    $records=[Collections.Generic.List[object]]::new()
    Must-Throw {Copy-StandardClosure $staged $selected @('MQL5/Indicators/JPWealth/Q.mq5') $records}
    if(Test-Path -LiteralPath (Join-Path $staged 'Include\JPWealth\stale.mqh')){throw 'Installed project copied.'}
}
$source='C:\Isolated\MQL5\Indicators\JPWealth\JPW_NoCuda_Channels.mq5'
$header="$source : information: compiling $source"
$nl=[Environment]::NewLine
Check 'Complete exact-program zero-error zero-warning log accepted' {
    $result=Test-CompileLog ($header+$nl+"Result: 0 errors, 0 warnings, 123 ms elapsed, cpu='X64 Regular'"+$nl) $source
    if (-not $result.accepted) { throw 'Valid complete log rejected.' }
}
Check 'Wrong-program log rejected' {
    $result=Test-CompileLog (($header -replace 'JPW_NoCuda_Channels','Other')+$nl+"Result: 0 errors, 0 warnings, 123 ms elapsed"+$nl) $source
    if ($result.accepted) { throw 'Wrong program accepted.' }
}
Check 'Unknown incomplete log rejected' {
    if ((Test-CompileLog $header $source).accepted) { throw 'Incomplete log accepted.' }
}
Check 'Warning result rejected' {
    if ((Test-CompileLog ($header+$nl+"Result: 0 errors, 1 warnings, 1 ms elapsed") $source).accepted) { throw 'Warning accepted.' }
}
Check 'Multiple summaries rejected' {
    $summary=$nl+"Result: 0 errors, 0 warnings, 1 ms elapsed"
    if ((Test-CompileLog ($header+$summary+$summary) $source).accepted) { throw 'Ambiguous summaries accepted.' }
}

# R1 K1: production anchor policy plus filesystem fixtures; never replace TEMP.
Check 'Direct local Windows volume anchor accepted' {
    $anchor=[pscustomobject]@{path_root='C:\';drive_kind='Fixed';logical_count=1;logical_letter='C:';logical_type=3;provider_name='';volume_count=1;volume_letter='C:';volume_type=3;volume_device_id='\\?\Volume{11111111-2222-3333-4444-555555555555}\'}
    Assert-LocalDriveAnchor $anchor
}
Check 'Network root rejected before probing or writing' { Must-Throw {Assert-LocalWindowsPath '\\server\share\TEMP'} }
foreach($change in @(
@{field='drive_kind';value='Network'},
@{field='provider_name';value='\\server\share'},
@{field='volume_count';value=0},
@{field='volume_letter';value='D:'},
@{field='volume_device_id';value='\??\C:\mapped-directory'}
)){
    Check ('Mapped or unanchored drive rejected: '+$change.field) {
        $anchor=[pscustomobject]@{path_root='C:\';drive_kind='Fixed';logical_count=1;logical_letter='C:';logical_type=3;provider_name='';volume_count=1;volume_letter='C:';volume_type=3;volume_device_id='\\?\Volume{11111111-2222-3333-4444-555555555555}\'}
        $anchor.($change.field)=$change.value
        Must-Throw {Assert-LocalDriveAnchor $anchor}
    }
}
Check 'New regular local staging directory passes pre/post validation' {
    $parent=Join-Path $root 'regular-temp-parent'
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $tree=New-IsolatedRunDirectory $parent
    if(-not (Test-Path -LiteralPath $tree.results_dir -PathType Container)){throw 'Result directory missing.'}
    Assert-SafeLocalTree $tree.run_root -RequireExisting
}
Check 'TEMP junction ancestor refused before child creation' {
    $target=Join-Path $root 'junction-target'
    $junction=Join-Path $root 'junction-temp'
    [IO.Directory]::CreateDirectory($target) | Out-Null
    & $env:ComSpec /d /c ('mklink /J "'+$junction+'" "'+$target+'"') | Out-Null
    if($LASTEXITCODE -ne 0){throw [NotSupportedException]::new('Junction fixture could not be created; no privilege/config change requested.')}
    Must-Throw {New-IsolatedRunDirectory $junction}
    if(@(Get-ChildItem -LiteralPath $target -Force).Count -ne 0){throw 'A staging child was created through refused junction.'}
}
Check 'TEMP symbolic-link ancestor refused before child creation' {
    $target=Join-Path $root 'symlink-target'
    $link=Join-Path $root 'symlink-temp'
    [IO.Directory]::CreateDirectory($target) | Out-Null
    try {New-Item -ItemType SymbolicLink -Path $link -Target $target -ErrorAction Stop | Out-Null}
    catch {throw [NotSupportedException]::new('Symlink fixture unavailable without current privilege; no elevation/config change requested.')}
    Must-Throw {New-IsolatedRunDirectory $link}
    if(@(Get-ChildItem -LiteralPath $target -Force).Count -ne 0){throw 'A staging child was created through refused symbolic link.'}
}

# R1 K2: closure/exclusivity, including legal historical information lines.
Check 'Legal including/resource/code-generation lines and blank tail accepted' {
    $body='C:\Isolated\MQL5\Include\JPWealth\A.mqh : information: including C:\Isolated\MQL5\Include\JPWealth\B.mqh'+$nl
    $body+='C:\Isolated\MQL5\Images\JPWealth\Logo.bmp : information: resource '+[char]39+'Logo.bmp'+[char]39+' as resource "::Images\JPWealth\Logo.bmp"'+$nl
    $body+=' : information: generating code'+$nl+' : information: generating code 100%'+$nl+' : information: code generated'+$nl
    $text=$header+$nl+$body+"Result: 0 errors, 0 warnings, 123 ms elapsed, cpu='X64 Regular'"+$nl+'   '+$nl
    if(-not (Test-CompileLog $text $source).accepted){throw 'Legal historical grammar/blank tail rejected.'}
}
Check 'Expected summary followed by foreign compiling header rejected' {
    $text=$header+$nl+'Result: 0 errors, 0 warnings, 1 ms elapsed'+$nl+'C:\Isolated\Other.mq5 : information: compiling C:\Isolated\Other.mq5'
    if((Test-CompileLog $text $source).accepted){throw 'Concatenated foreign compilation accepted.'}
}
Check 'Foreign compiling header before one final summary rejected' {
    $text=$header+$nl+'C:\Isolated\Other.mq5 : information: compiling C:\Isolated\Other.mq5'+$nl+'Result: 0 errors, 0 warnings, 1 ms elapsed'
    if((Test-CompileLog $text $source).accepted){throw 'Second program opening accepted.'}
}
Check 'Summary before program opening rejected' {
    if((Test-CompileLog ('Result: 0 errors, 0 warnings, 1 ms elapsed'+$nl+$header) $source).accepted){throw 'Summary before opening accepted.'}
}
foreach($tail in @('garbage','Result: 0 errors,',' : information: generating code','C:\Isolated\Other.mq5 : information: compiling')){
    Check ('Trailing content/truncation rejected: '+$tail) {
        if((Test-CompileLog ($header+$nl+'Result: 0 errors, 0 warnings, 1 ms elapsed'+$nl+$tail) $source).accepted){throw 'Unclosed/trailing log accepted.'}
    }
}
Check 'Unrecognized middle line rejected despite final zero summary' {
    if((Test-CompileLog ($header+$nl+'unknown middle content'+$nl+'Result: 0 errors, 0 warnings, 1 ms elapsed') $source).accepted){throw 'Unknown middle content accepted.'}
}
Check 'Foreign MQ5 include parent rejected' {
    $text=$header+$nl+'C:\Isolated\Other.mq5 : information: including C:\Isolated\MQL5\Include\A.mqh'+$nl+'Result: 0 errors, 0 warnings, 1 ms elapsed'
    if((Test-CompileLog $text $source).accepted){throw 'Foreign MQ5 parent accepted.'}
}

# R1 K3: real filesystem snapshots, never a native process/kill claim.
Check 'Timeout snapshot preserves partial raw log and EX5 with hashes' {
    $stage=Join-Path $root 'partial-stage'
    $out=Join-Path $root 'partial-results'
    [IO.Directory]::CreateDirectory($stage)|Out-Null
    [IO.Directory]::CreateDirectory($out)|Out-Null
    $log=Join-Path $stage 'partial.log';$ex5=Join-Path $stage 'partial.ex5'
    [IO.File]::WriteAllText($log,$header)
    [IO.File]::WriteAllBytes($ex5,[Text.Encoding]::ASCII.GetBytes('partial ex5 fixture'))
    $artifacts=Save-CompilerOutputs $log $ex5 $out $true
    foreach($artifact in @($artifacts.log,$artifacts.ex5)){
        if($artifact.status -ne 'COPIED_PARTIAL_OR_UNVERIFIED' -or $artifact.evidence -ne 'PARTIAL_OR_UNVERIFIED' -or $artifact.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Partial artifact was lost or promoted.'}
        if(-not (Test-Path -LiteralPath $artifact.result_path -PathType Leaf)){throw 'Copied snapshot missing.'}
    }
    if((Test-CompileLog ([IO.File]::ReadAllText($artifacts.log.result_path)) $source).accepted){throw 'Incomplete log promoted to compilation.'}
}
Check 'Locked timeout log is reported and preserved without retry loop' {
    $stage=Join-Path $root 'locked-stage';$out=Join-Path $root 'locked-results'
    [IO.Directory]::CreateDirectory($stage)|Out-Null;[IO.Directory]::CreateDirectory($out)|Out-Null
    $log=Join-Path $stage 'locked.log';$ex5=Join-Path $stage 'absent.ex5'
    $locked=[IO.File]::Open($log,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try{
        $artifacts=Save-CompilerOutputs $log $ex5 $out $true
        if($artifacts.log.status -ne 'UNREADABLE_OR_LOCKED' -or [string]::IsNullOrWhiteSpace($artifacts.log.error) -or $null -ne $artifacts.log.sha256){throw 'Locked output did not remain explicitly unverified.'}
        if($artifacts.ex5.status -ne 'ABSENT'){throw 'Absent EX5 incorrectly recorded.'}
    }finally{$locked.Dispose()}
    if(-not (Test-Path -LiteralPath $log)){throw 'Original locked output was removed.'}
}
Check 'Oversized diagnostic is refused with source path retained' {
    $stage=Join-Path $root 'large-stage';$out=Join-Path $root 'large-results'
    [IO.Directory]::CreateDirectory($stage)|Out-Null;[IO.Directory]::CreateDirectory($out)|Out-Null
    $log=Join-Path $stage 'large.log'
    $file=[IO.File]::Open($log,[IO.FileMode]::CreateNew)
    try{$file.SetLength(16MB+1)}finally{$file.Dispose()}
    $artifacts=Save-CompilerOutputs $log (Join-Path $stage 'absent.ex5') $out $true
    if($artifacts.log.status -ne 'SIZE_CAP_EXCEEDED' -or $artifacts.log.source_path -ine $log -or $null -ne $artifacts.log.sha256){throw 'Size cap evidence is incorrect.'}
}

Write-Host "Core fixture result: $passed passed / $failed failed / $skipped skipped. Windows compilation/runtime are NOT_RUN."
Write-Host "Fixture directory preserved: $root"
if ($failed -gt 0) { exit 1 }

