#!/usr/bin/env python3
"""Read-only, independent byte check of the sealed Stoikus UI compile kit."""

import hashlib
import json
import re
import stat
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREFIX = "mt5/jpw-alavancagem-atual/"
PROGRAMS = {
    "MQL5/Experts/JPWealth/JPW_Stoikus_Monitor.mq5",
    "MQL5/Indicators/JPWealth/JPW_Alavancagem_Atual.mq5",
    "MQL5/Indicators/JPWealth/JPW_NoCuda_Channels.mq5",
    "MQL5/Scripts/JPWealth/JPW_Stoikus_Abrir_Paineis.mq5",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def validate_schema(data, spec, label="identity"):
    supported = {"$schema", "title", "description", "type", "const", "enum", "required", "additionalProperties", "properties", "items", "minItems", "maxItems", "minLength", "maxLength", "minimum", "maximum", "pattern"}
    check(set(spec) <= supported, f"{label}: unsupported schema keyword")
    types = {"object": dict, "array": list, "string": str, "integer": int}
    if "type" in spec:
        check(type(data) is types[spec["type"]], f"{label}: type")
    if "const" in spec:
        check(type(data) is type(spec["const"]) and data == spec["const"], f"{label}: const")
    if "enum" in spec:
        check(data in spec["enum"], f"{label}: enum")
    if isinstance(data, dict):
        check(set(spec.get("required", [])) <= set(data), f"{label}: required")
        properties = spec.get("properties", {})
        if spec.get("additionalProperties") is False:
            check(set(data) <= set(properties), f"{label}: additional property")
        for key, value in data.items():
            if key in properties:
                validate_schema(value, properties[key], f"{label}.{key}")
    if isinstance(data, list):
        check(len(data) >= spec.get("minItems", 0) and len(data) <= spec.get("maxItems", 2**31), f"{label}: item count")
        for index, value in enumerate(data):
            validate_schema(value, spec["items"], f"{label}[{index}]")
    if isinstance(data, str):
        check(len(data) >= spec.get("minLength", 0) and len(data) <= spec.get("maxLength", 2**31), f"{label}: length")
        if "pattern" in spec:
            check(re.search(spec["pattern"], data) is not None, f"{label}: pattern")
    if type(data) is int:
        check(data >= spec.get("minimum", -2**63) and data <= spec.get("maximum", 2**63), f"{label}: range")


def verify(pin_path=None):
    identity = load(ROOT / "stoikus-1.22.2-interface.identity.json")
    schema = load(ROOT / "identity.schema.json")
    freeze = load(ROOT / "source-freeze-R3.json")
    pin = load(pin_path or ROOT / "root-pin-R3.json")
    validate_schema(identity, schema)
    check(identity["origin"]["generated_by"] == "root", "origin must be root")
    check(identity["origin"]["freeze_id"] == pin["freeze_id"], "wrong freeze ID")
    check(identity["origin"]["root_freeze_sha256"] == digest(ROOT / "source-freeze-R3.json"), "freeze bytes")
    check(freeze["schema"] == "JPW_STOIKUS_INTERFACE_FREEZE_V1", "freeze schema")
    check(freeze["candidate"] == identity["candidate_version"], "candidate differs")
    for field in ("baseline_commit", "mql_source_fingerprint", "interface_fingerprint", "runtime_build_id", "calculation_version"):
        check(freeze[field] == identity["origin"][field], f"freeze {field} differs")
    check(freeze["runtime_build_id"] != "5a207fbd41e59c2d2544f94264105d45c69911518433d0d66176eb9c0c427a1b", "historical build reused")
    check(pin["kind"] == "JPW_STOIKUS_UI_NATIVE_KIT_ROOT_PIN" and pin["status"] == "SEALED_SOURCE_ONLY", "root pin not sealed")
    check(pin["candidate"] == identity["candidate_version"] and pin["freeze_id"] == identity["origin"]["freeze_id"], "pin candidate")
    for field in ("interface_fingerprint", "runtime_build_id", "calculation_version"):
        check(pin[field] == identity["origin"][field], f"pin {field}")
    for name, expected in pin["files_sha256"].items():
        check(name == Path(name).name and (ROOT / name).is_file(), f"unsafe/missing pinned file {name}")
        check(digest(ROOT / name) == expected, f"pinned file changed: {name}")
    check(set(pin["files_sha256"]) == {
        "Compile-Stoikus-UI.ps1", "NativeKit.Core.ps1", "stoikus-1.22.2-interface.identity.json",
        "JPW_Stoikus_Uso_Fontes_v1.22.2_interface.zip", "source-freeze-R3.json",
        "identity.schema.json", "LEIA-PRIMEIRO.md", "verify_native_ui_kit.py", "Test-NativeUI-Kit.ps1",
    }, "root pin inventory differs")
    kit_files = identity["kit_files"]
    check(len(kit_files) == 2 and {x["name"] for x in kit_files} == {"Compile-Stoikus-UI.ps1", "NativeKit.Core.ps1"}, "kit sources")
    for row in kit_files:
        check(row["sha256"] == digest(ROOT / row["name"]), f"identity kit hash {row['name']}")
    runner = (ROOT / "Compile-Stoikus-UI.ps1").read_text(encoding="utf-8")
    pins = {
        "PinnedZipSha256": identity["zip"]["sha256"],
        "PinnedCoreSha256": digest(ROOT / "NativeKit.Core.ps1"),
        "PinnedFreezeSha256": identity["origin"]["root_freeze_sha256"],
        "PinnedMqlFingerprint": identity["origin"]["mql_source_fingerprint"],
        "PinnedInterfaceFingerprint": identity["origin"]["interface_fingerprint"],
        "PinnedRuntimeBuildId": identity["origin"]["runtime_build_id"],
    }
    for key, value in pins.items():
        check(re.search(rf"^\${key}='{value}'$", runner, re.MULTILINE) is not None, f"runner pin {key}")
    fixture = (ROOT / "Test-NativeUI-Kit.ps1").read_text(encoding="utf-8")
    check(re.search(rf"^\$PinnedCoreSha256='{pins['PinnedCoreSha256']}'$", fixture, re.MULTILINE) is not None, "fixture Core pin")
    archive = ROOT / identity["zip"]["filename"]
    check(archive.name == "JPW_Stoikus_Uso_Fontes_v1.22.2_interface.zip", "ZIP name")
    check(archive.stat().st_size == identity["zip"]["bytes"] and digest(archive) == identity["zip"]["sha256"], "ZIP bytes/hash")
    expected = {row["path"]: row for row in identity["entries"]}
    check(len(expected) == len(identity["entries"]) and len(expected) > 0, "entry inventory duplicate/count")
    check({row["path"] for row in identity["programs"]} == PROGRAMS, "program set")
    check({row["path"] for row in identity["entries"] if row["path"].lower().endswith(".mq5")} == PROGRAMS, "extra MQ5")
    with zipfile.ZipFile(archive) as z:
        members = z.infolist()
        check(len(members) == len(expected), "ZIP count")
        seen = set()
        for member in members:
            name = member.filename
            parts = name.split("/")
            check(not member.is_dir() and name in expected and name not in seen, f"unexpected/duplicate ZIP path {name}")
            check(name.casefold() not in seen, f"case duplicate ZIP path {name}")
            check(name == "LEIA_PRIMEIRO.md" or name.startswith("MQL5/"), f"unexpected ZIP root {name}")
            check(name.isascii() and all(part not in ("", ".", "..") for part in parts) and "\\" not in name and ":" not in name, f"unsafe ZIP path {name}")
            check(not name.casefold().startswith("mql5/files/") and not name.casefold().endswith(".ex5"), f"data/binary ZIP path {name}")
            check(not member.flag_bits & 1 and stat.S_IFMT(member.external_attr >> 16) in (0, stat.S_IFREG), f"encrypted/link ZIP entry {name}")
            data = z.read(member)
            row = expected[name]
            check(len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], f"ZIP entry bytes {name}")
            if name.startswith("MQL5/"):
                check(freeze["source_hashes"].get(PREFIX + name) == row["sha256"], f"source freeze differs {name}")
            if name == "LEIA_PRIMEIRO.md":
                intro = data.decode("utf-8-sig").casefold()[:2500]
                check("candidato privado de interface" in intro and "jpw_stoikus_uso_fontes_v1.22.2_interface.zip" in intro, "inner guide private-candidate/ZIP mismatch")
                check("recibo" in intro and "demo" in intro, "inner guide missing receipt/demo preface")
            seen.add(name)
            seen.add(name.casefold())
    for row in identity["programs"]:
        check(row["sha256"] == expected[row["path"]]["sha256"], f"program hash {row['path']}")
    return {"candidate": identity["candidate_version"], "source_entries": len(expected), "programs": len(PROGRAMS), "source_zip_sha256": digest(archive), "identity_sha256": digest(ROOT / "stoikus-1.22.2-interface.identity.json"), "status": "STATIC_BYTES_PASS"}


if __name__ == "__main__":
    print(json.dumps(verify(sys.argv[1] if len(sys.argv) > 1 else None), sort_keys=True))
